"""
Fixes how the Obito-design Susanoo holds its Kamui shuriken (assets/shinobiarts/susanoo/weapons<stage>_obito.bin):
the shuriken (the "shadow" pieces on each hand) sat centred on the fist, so its blades stuck out through the fingers.
Now each one lies flat (like a disc ready to be thrown) with its near edge pinched in the fist and the rest of it out
in front of the hand. Run once: python3 tools/fix_obito_grip.py (it remembers what it did, so a second run is a no-op).
"""
import os
import struct

HERE = os.path.dirname(os.path.abspath(__file__))
DIR = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "susanoo")


def read(path):
    b = open(path, "rb").read()
    o = 4
    ver, n = struct.unpack_from(">ii", b, o)
    o += 8
    pieces = []
    for _ in range(n):
        L = struct.unpack_from(">H", b, o)[0]; bone = b[o + 2:o + 2 + L].decode(); o += 2 + L
        L = struct.unpack_from(">H", b, o)[0]; mat = b[o + 2:o + 2 + L].decode(); o += 2 + L
        nv, nt = struct.unpack_from(">ii", b, o); o += 8
        pos = list(struct.unpack_from(f">{nv * 3}f", b, o)); o += nv * 12
        nrm = list(struct.unpack_from(f">{nv * 3}b", b, o)); o += nv * 3
        uv = list(struct.unpack_from(f">{nv * 2}f", b, o)); o += nv * 8
        fmt = "H" if nv <= 65535 else "i"
        idx = list(struct.unpack_from(f">{nt * 3}{fmt}", b, o)); o += nt * 3 * struct.calcsize(fmt)
        pieces.append([bone, mat, nv, nt, pos, nrm, uv, idx])
    return b[:4], ver, pieces


def write(path, magic, ver, pieces):
    out = bytearray(magic)
    out += struct.pack(">ii", ver, len(pieces))
    for bone, mat, nv, nt, pos, nrm, uv, idx in pieces:
        for s in (bone, mat):
            e = s.encode()
            out += struct.pack(">H", len(e)) + e
        out += struct.pack(">ii", nv, nt)
        out += struct.pack(f">{nv * 3}f", *pos)
        out += struct.pack(f">{nv * 3}b", *nrm)
        out += struct.pack(f">{nv * 2}f", *uv)
        fmt = "H" if nv <= 65535 else "i"
        out += struct.pack(f">{nt * 3}{fmt}", *idx)
    open(path, "wb").write(bytes(out))


def bbox(pos):
    xs, ys, zs = pos[0::3], pos[1::3], pos[2::3]
    return (min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs))


def fix(stage):
    path = os.path.join(DIR, f"weapons{stage}_obito.bin")
    marker = os.path.join(HERE, f".gripfixed{stage}")
    if os.path.exists(marker):
        return
    magic, ver, pieces = read(path)
    for side in ("hand_r", "hand_l"):
        fingers = [p for p in pieces if p[0] == side and p[1] == "muscle"]
        held = [p for p in pieces if p[0] == side and p[1] == "shadow"]
        if not fingers or not held:
            continue
        fp = [v for p in fingers for v in p[4]]
        (fx0, fy0, fz0), (fx1, fy1, fz1) = bbox(fp)
        fist = ((fx0 + fx1) / 2, (fy0 + fy1) / 2, (fz0 + fz1) / 2)
        hp = [v for p in held for v in p[4]]
        (hx0, hy0, hz0), (hx1, hy1, hz1) = bbox(hp)
        c = ((hx0 + hx1) / 2, (hy0 + hy1) / 2, (hz0 + hz1) / 2)
        radius = max(hx1 - hx0, hy1 - hy0) / 2
        # lie it flat (turn its face from forward to up), then slide it forward so the fist grips its near edge
        target = (fist[0], fist[1], fist[2] + radius * 0.8)
        for p in held:
            pos, nrm = p[4], p[5]
            for i in range(0, len(pos), 3):
                x, y, z = pos[i] - c[0], pos[i + 1] - c[1], pos[i + 2] - c[2]
                y, z = -z, y
                pos[i], pos[i + 1], pos[i + 2] = x + target[0], y + target[1], z + target[2]
                nx, ny, nz = nrm[i], nrm[i + 1], nrm[i + 2]
                nrm[i], nrm[i + 1], nrm[i + 2] = nx, max(-127, min(127, -nz)), ny
    write(path, magic, ver, pieces)
    open(marker, "w").write("done\n")


if __name__ == "__main__":
    for s in (3, 4, 5):
        fix(s)
    print("fixed")
