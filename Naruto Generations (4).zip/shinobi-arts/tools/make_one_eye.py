"""Eye textures for the Level 1 curse mark (textures/models/eyes/, 64x32 layout like the dojutsu eyes):

  *_one.png            each dojutsu texture with only the right eye (the curse mark takes the left);
  curse_eye.png        the cursed left eye: the same eye shape and brow as the dojutsu eyes (traced from sharingan_3),
                       with the white turned black and a gold iris with a black pupil;
  curse_eye_glow.png   the gold iris alone, laid on glowing;
  eye_regular_1..8     ordinary eyes (white, a coloured iris, black pupil, a glint) in the same shape, one per natural
                       eye colour (NinjaData.EYE_COLORS, rolled on first spawn), each with its _one copy too.

Run from the project folder: python3 tools/make_one_eye.py"""
import glob, os
import numpy as np
from PIL import Image

EYES = 'src/main/resources/assets/shinobiarts/textures/models/eyes/'
for f in sorted(glob.glob(EYES + '*.png')):
    if f.endswith('_one.png') or os.path.basename(f).startswith(('curse_eye', 'eye_regular')): continue
    im = Image.open(f).convert('RGBA')
    a = np.asarray(im).copy()
    k = im.width // 64                                   # texture pixels per skin pixel
    a[8 * k:16 * k, 12 * k:16 * k] = 0                   # the left half of the face's front: the left eye
    Image.fromarray(a, 'RGBA').save(f[:-4] + '_one.png', optimize=True)
    print(os.path.basename(f))

# ---------------------------------------------------------------- the cursed eye
src = np.asarray(Image.open(EYES + 'sharingan_3.png').convert('RGBA')).astype(float)
k = src.shape[1] // 64
out = np.zeros_like(src)
x0, x1, y0, y1 = 12 * k, 16 * k, 8 * k, 16 * k                     # the left eye's square
eye = src[y0:y1, x0:x1]
rgb, alpha = eye[..., :3], eye[..., 3]
red = (alpha > 40) & (rgb[..., 0] > 120) & (rgb[..., 1] < 90)
ys, xs = np.nonzero(red)
cy, cx = ys.mean(), xs.mean()                                      # the iris: centre and size from the red
R = np.percentile(np.hypot(ys - cy, xs - cx), 97) + 1.5
Y, X = np.mgrid[:eye.shape[0], :eye.shape[1]]
r = np.hypot(Y - cy, X - cx) / R
res = eye.copy()
inside_eye = alpha > 40
light = inside_eye & (rgb.min(-1) > 110)                           # the whites (and the pink corner)
pink = inside_eye & (rgb[..., 0] > 180) & (rgb[..., 1] < 170) & (r > 1)
fringe = inside_eye & (r > 1) & (r < 1.25) & (rgb.max(-1) > 80)       # soft edges of the white round the iris
res[light | pink | fringe, :3] = (18, 10, 20)                      # the white turns black
iris = inside_eye & (r <= 1)
t = np.clip(r, 0, 1)
gold = np.stack([255 - 70 * t, 205 - 100 * t, 70 - 50 * t], -1)   # bright gold in the middle, deep amber outside
res[iris, :3] = gold[iris]
res[iris & (r > 0.9), :3] = (60, 30, 6)                            # a dark rim
res[iris & (r < 0.3), :3] = (8, 4, 6)                              # the pupil
hl = iris & (np.hypot(Y - (cy - 0.45 * R), X - (cx - 0.4 * R)) < 0.16 * R)
res[hl, :3] = (255, 250, 230)                                      # a glint
res[iris, 3] = 255
out[y0:y1, x0:x1] = res
# a skin's own eye is in row 12, pixels 13..14: fill any gap there (under the eye's tail) so it can't show through
gap = out[12 * k:13 * k, 12 * k + k // 2:15 * k + k // 4]
gap[gap[..., 3] < 128] = (18, 10, 20, 255)
Image.fromarray(out.astype(np.uint8), 'RGBA').save(EYES + 'curse_eye.png', optimize=True)

glow = np.zeros_like(out)
g = iris & (r >= 0.3) & (r <= 0.9)
glow[y0:y1, x0:x1][g] = (255, 205, 80, 230)
Image.fromarray(glow.astype(np.uint8), 'RGBA').save(EYES + 'curse_eye_glow.png', optimize=True)
print('curse eye ok')

# ---------------------------------------------------------------- ordinary eyes, one per natural eye colour
COLOURS = [(96, 60, 30),      # 1 brown
           (58, 36, 20),      # 2 dark brown
           (130, 104, 52),    # 3 hazel
           (64, 120, 70),     # 4 green
           (62, 112, 190),    # 5 blue
           (128, 138, 150),   # 6 grey
           (196, 136, 44),    # 7 amber
           (34, 28, 30)]      # 8 black

def ordinary(eye, colour):
    """One eye square of sharingan_3 with its red iris repainted: a coloured iris, lighter round the pupil, darker at
    the rim, a black pupil and a glint. The white, the outline and the brow stay as they are."""
    rgb, alpha = eye[..., :3], eye[..., 3]
    red = (alpha > 40) & (rgb[..., 0] > 120) & (rgb[..., 1] < 90)
    ys, xs = np.nonzero(red)
    cy, cx = ys.mean(), xs.mean()
    R = np.percentile(np.hypot(ys - cy, xs - cx), 97) + 1.5
    Y, X = np.mgrid[:eye.shape[0], :eye.shape[1]]
    r = np.hypot(Y - cy, X - cx) / R
    res = eye.copy()
    iris = (alpha > 40) & (r <= 1)
    c = np.array(colour, float)
    shade = np.clip(1.35 - 0.6 * r, 0.7, 1.3)[..., None]              # lighter inside, darker out
    res[..., :3] = np.where(iris[..., None], np.clip(c * shade, 0, 255), res[..., :3])
    res[iris & (r > 0.88), :3] = c * 0.45                              # the rim
    res[iris & (r < 0.36), :3] = (10, 8, 10)                           # the pupil
    hl = iris & (np.hypot(Y - (cy - 0.45 * R), X - (cx - 0.4 * R)) < 0.16 * R)
    res[hl, :3] = (255, 252, 245)
    res[iris, 3] = 255
    return res

for n, colour in enumerate(COLOURS, 1):
    out = np.zeros_like(src)
    for ex in (8, 12):                                                 # both eyes
        sq = (slice(8 * k, 16 * k), slice(ex * k, (ex + 4) * k))
        out[sq] = ordinary(src[sq], colour)
    Image.fromarray(out.astype(np.uint8), 'RGBA').save(EYES + f'eye_regular_{n}.png', optimize=True)
    out[8 * k:16 * k, 12 * k:16 * k] = 0
    Image.fromarray(out.astype(np.uint8), 'RGBA').save(EYES + f'eye_regular_{n}_one.png', optimize=True)
print('regular eyes ok')
