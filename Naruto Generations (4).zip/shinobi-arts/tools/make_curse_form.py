"""Paints the Level 2 curse form's texture (form.png, 128x64) and its glow (form_glow.png) for CurseFormModel.

Pixel art, one pixel per model pixel, laid out like a Blockbench box UV map:
  the hand-wings' bones (upper arm, forearm, spur) at the top left, the palm, fingers, joint knobs, thumb and claws
  at the top right;
  the hair (mane, cap, bangs, side locks) below the bones.
Run from the project folder: python3 tools/make_curse_form.py"""
import math
import numpy as np
from PIL import Image

OUT = 'src/main/resources/assets/shinobiarts/textures/entity/curse/'
W, H = 128, 64
rnd = np.random.default_rng(5)
tex = np.zeros((H, W, 4), dtype=np.uint8)
glow = np.zeros((H, W, 4), dtype=np.uint8)

SKIN = np.array((112, 116, 130))     # the grey of the form's skin
DARK = np.array((58, 56, 72))
CLAW = np.array((24, 18, 28))
HAIR = np.array((150, 160, 182))     # pale grey-blue hair


def fill(u, v, w, h, col, noise=8, alpha=255):
    n = rnd.integers(-noise, noise + 1, (h, w, 1)) if noise else 0
    tex[v:v + h, u:u + w, :3] = np.clip(col + n, 0, 255)
    tex[v:v + h, u:u + w, 3] = alpha


# ---------------------------------------------------------------- the hand-wings (see CurseFormModel for the boxes)
def bone(u, v, w, h, d, col):
    """A bone box: rough grey skin in 1-pixel speckles, lighter on top, a shadowed lower row, a darker underside."""
    w, h, d = math.ceil(w), math.ceil(h), math.ceil(d)
    fill(u + d, v, w, d, col + 16, noise=10)                  # top
    fill(u + d + w, v, w, d, col - 30, noise=6)               # underside
    fill(u, v + d, 2 * (w + d), h, col, noise=10)             # the four sides
    if h >= 2:
        tex[v + d + h - 1, u:u + 2 * (w + d), :3] = np.clip(col - 26, 0, 255)
        tex[v + d, u:u + 2 * (w + d), :3] = np.clip(col + 10, 0, 255)
    # a few creases across the bone
    for k in range(u + 3, u + 2 * (w + d) - 1, 5):
        tex[v + d:v + d + h, k, :3] = np.clip(tex[v + d:v + d + h, k, :3].astype(int) - 18, 0, 255)

bone(0, 0, 4, 3.5, 3.5, SKIN)                                # upper arm (three crossed boxes)
bone(0, 7, 4, 4, 3, SKIN)
bone(0, 14, 4, 3, 4, SKIN)
bone(30, 0, 5, 3, 2.5, SKIN - 6)                             # forearm
bone(30, 6, 5, 2.5, 3, SKIN - 6)
bone(30, 12, 1, 1, 4, DARK)                                  # the elbow spur
bone(64, 0, 10, 12, 3.5, SKIN - 4)                           # palm
bone(94, 0, 11, 9, 4, SKIN - 4)
for v in (7, 10, 13):                                        # lines across the palm
    tex[v, 64:91, :3] = np.clip(SKIN - 28, 0, 255)
bone(64, 16, 7, 4, 3, SKIN - 8)                              # finger, first segment
bone(64, 24, 7, 3, 4, SKIN - 8)
bone(86, 24, 5.5, 2.5, 2.5, SKIN - 14)                       # finger, second segment
bone(100, 16, 4, 4, 4, SKIN + 8)                             # the knobs at the joints, a little paler
bone(64, 32, 7, 3.5, 3.5, SKIN - 10)                         # thumb
# claws: near-black with a pale glint along the top, the tip region darkest
fill(86, 16, 12, 6, CLAW, noise=4)
tex[16:18, 88:92, :3] = (70, 60, 72)
glow[16:22, 86:98] = (190, 110, 255, 150)                    # the claws glow faintly
# veins of cursed chakra along the arm bones (glow)
for u in range(3, 20, 2):
    glow[3 + (u // 2) % 2, u] = (170, 90, 255, 200)
for u in range(32, 52, 3):
    glow[8, u] = (170, 90, 255, 170)

# ---------------------------------------------------------------- the hair
def hair_block(u, v, w, h, spiky_rows=0, seed=0):
    r = np.random.default_rng(seed)
    for x in range(w):
        shade = r.integers(-22, 10)                          # a strand per column
        for y in range(h):
            tex[v + y, u + x, :3] = np.clip(HAIR + shade + r.integers(-5, 6), 0, 255)
            tex[v + y, u + x, 3] = 255
        if spiky_rows:
            cut = r.integers(0, spiky_rows + 1) if x % 2 else r.integers(spiky_rows // 2, spiky_rows + 1)
            for y in range(h - cut, h):
                tex[v + y, u + x, 3] = 0
            if h - cut - 1 >= 0:
                tex[v + h - cut - 1, u + x, :3] = np.clip(HAIR - 30, 0, 255)


# mane 9x18x1 at (0, 26): top/bottom rows, then the sides with a ragged bottom
hair_block(1, 26, 18, 1, 0, 1)
hair_block(0, 27, 20, 18, 6, 2)
# cap 9x1x9 at (20, 26)
hair_block(29, 26, 18, 9, 0, 3)
hair_block(20, 35, 36, 1, 0, 4)
# bangs 9x4x0 at (20, 36): front and back, ragged
hair_block(20, 36, 18, 4, 3, 5)
# locks 0x10x6 at (40, 36): the two sides of each lock, ragged
hair_block(40, 42, 12, 10, 4, 6)

Image.fromarray(tex, 'RGBA').save(OUT + 'form.png')
Image.fromarray(glow, 'RGBA').save(OUT + 'form_glow.png')
print('form ok')
