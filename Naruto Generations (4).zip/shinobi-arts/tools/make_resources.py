"""Generates lang, models, recipes and damage types from Jutsus.java. Run: python3 tools/make_resources.py"""
import json
import math
import os
import shutil
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.join(HERE, "..")
RES = os.path.join(PROJECT, "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", "shinobiarts")
DATA = os.path.join(RES, "data", "shinobiarts")
MODID = "shinobiarts"

NATURES = ["fire", "water", "wind", "lightning", "earth", "yin_yang"]
CLAN_RELEASES = ["wood", "ice", "magnet", "bone", "sealing"]  # Senju, Yuki, Kazekage, Kaguya, Uzumaki
RELEASES = NATURES + ["ninjutsu"] + CLAN_RELEASES
NATURE_NAMES = {"fire": "Fire Release", "water": "Water Release", "wind": "Wind Release",
                "lightning": "Lightning Release", "earth": "Earth Release", "yin_yang": "Yin Yang Release",
                "ninjutsu": "Ninjutsu", "wood": "Wood Release", "ice": "Ice Release", "magnet": "Magnet Release",
                "bone": "Bone Release", "sealing": "Sealing Release"}
CATALYST = {"fire": "minecraft:blaze_powder", "water": "minecraft:prismarine_shard", "wind": "minecraft:feather",
            "lightning": "minecraft:copper_ingot", "earth": "minecraft:clay_ball",
            "yin_yang": "minecraft:amethyst_shard",
            "ninjutsu": "minecraft:lapis_lazuli",
            "wood": "minecraft:oak_sapling", "ice": "minecraft:packed_ice", "magnet": "minecraft:iron_nugget",
            "bone": "minecraft:bone", "sealing": "minecraft:chain"}
# Extra ingredient for elemental jutsu scrolls (unchanged from before jutsu had ranks, so recipes stay the same):
# the weakest jutsu of each element needs nothing extra, the middle one a gold ingot, the strongest a diamond.
RECIPE_EXTRA = {
    "fireball": None, "phoenix_flower": "minecraft:gold_ingot", "fire_annihilation": "minecraft:diamond",
    "water_bullet": None, "water_prison": "minecraft:gold_ingot", "water_dragon": "minecraft:diamond",
    "gale_palm": None, "vacuum_blade": "minecraft:gold_ingot", "great_breakthrough": "minecraft:diamond",
    "lightning_armor": None, "chidori": "minecraft:gold_ingot", "thunder_strike": "minecraft:diamond",
    "earth_wall": None, "rock_armor": "minecraft:gold_ingot", "earth_spikes": "minecraft:diamond",
    # clan releases: the first is given with the release, the scrolls are for relearning it and the other two
    "wood_binding": None, "wood_dome": "minecraft:gold_ingot", "deep_forest": "minecraft:diamond",
    "ice_needles": None, "ice_prison": "minecraft:gold_ingot", "ice_mirrors": "minecraft:diamond",
    "iron_sand_drizzle": None, "iron_sand_coffin": "minecraft:gold_ingot", "iron_sand_world": "minecraft:diamond",
    "finger_bullets": None, "willow_dance": "minecraft:gold_ingot", "seedling_fern": "minecraft:diamond",
    "barrier": None, "adamantine_chains": "minecraft:gold_ingot", "five_elements_seal": "minecraft:diamond",
}
RANK_NAMES = {"D": "D-Rank", "C": "C-Rank", "B": "B-Rank", "A": "A-Rank", "S": "S-Rank"}

JUTSU_TEXT = {
    "fireball": ("Fire Release: Great Fireball", "Launches a ball of fire that bursts into flames on impact. Charge it longer for a bigger fireball and blast."),
    "phoenix_flower": ("Fire Release: Phoenix Flower", "Fires a fan of five small fireballs that set targets ablaze."),
    "fire_annihilation": ("Fire Release: Great Fire Annihilation", "Breathes a sea of fire across a wide cone in front of you."),
    "water_bullet": ("Water Release: Water Bullet", "A fast, hard-hitting shot of water that knocks enemies back."),
    "water_prison": ("Water Release: Water Prison", "Traps the creature you're looking at in water, holding it nearly still."),
    "water_dragon": ("Water Release: Water Dragon", "A surging dragon of water that crashes down on everything near its impact."),
    "gale_palm": ("Wind Release: Gale Palm", "A blast of wind that throws enemies back and turns aside projectiles."),
    "vacuum_blade": ("Wind Release: Vacuum Blade", "An invisible blade of wind that cuts through every enemy in a line."),
    "great_breakthrough": ("Wind Release: Great Breakthrough", "A colossal gust that flattens plants and hurls everything in front of you away."),
    "lightning_armor": ("Lightning Release: Lightning Armor", "Coats your body in lightning: faster movement, attacks and mining for 20 seconds."),
    "chidori": ("Chidori", "Dash to the enemy you're looking at and strike with a crackling blade of lightning."),
    "thunder_strike": ("Lightning Release: Thunder Strike", "Calls down a lightning bolt where you're looking."),
    "earth_wall": ("Earth Release: Earth Wall", "Raises a wall of earth in front of you. It crumbles after about 15 seconds."),
    "rock_armor": ("Earth Release: Rock Armor", "Hardens your body like stone for 20 seconds: strong damage resistance, but slower."),
    "earth_spikes": ("Earth Release: Rising Spikes", "The ground erupts where you're looking, launching enemies into the air."),
    "substitution": ("Substitution Jutsu", "Switch it on and off with its key (K by default). While it's on, attacks hit a log instead: you jump back and up, leaving two logs behind. Each swap costs chakra and has a cooldown."),
    "body_flicker": ("Body Flicker", "Move in a blur to the spot you're looking at (up to 16 blocks)."),
    "shadow_clone": ("Shadow Clone Jutsu", "Creates solid copies of yourself that fight beside you for 30 seconds. Any hit dispels them."),
    "tengai_shinsei": ("Rinnegan: Tengai Shinsei", "Planetary Shower. Pull a meteor out of the sky onto where you look: its shadow spreads and the sky rumbles for a few seconds, then it lands in a huge blast. A second, bigger one follows. Needs the Rinnegan."),
    "edo_tensei": ("Summoning: Edo Tensei", "Impure World Reincarnation. Bring back the souls of the ninja you killed most recently in bodies of ash and dust: each needs a living sacrifice nearby. Coffins rise out of the ground and the dead step out to fight for you. They can't be killed, only broken apart for a few seconds. Right-click one (or cast again) to release them."),
    "rasengan": ("Rasengan", "Spin chakra into a sphere in your hand. Your next punch deals huge damage and sends the target flying."),
    "shadow_possession": ("Shadow Possession", "Stretches your shadow to bind a target in place for 6 seconds. You're slowed while holding it."),
    "palm_rotation": ("Eight Trigrams Palm Rotation", "Spin chakra around you to repel everything nearby and block all attacks for a moment."),
    "hell_viewing": ("Yin Release: Hell Viewing", "Traps the target you're looking at in a nightmare: blinded and staggering. Longer with Genjutsu."),
    "mind_fog": ("Yin Release: Mind Fog", "Casts an illusion on everything around you, leaving them lost and slowed. Longer with Genjutsu."),
    "mystical_palm": ("Yang Release: Mystical Palm", "Heals the player you're looking at, or yourself. Heals more with Medical."),
    "rasenshuriken": ("Wind Release: Rasenshuriken", "Throws a spinning shuriken of wind chakra that bursts into a sphere of blades, shredding everything around it."),
    "vitality_surge": ("Yang Release: Vitality Surge", "Floods your body with life: strong regeneration, extra hearts, and cures poison. Longer with Medical."),
    # Wood Release (Senju)
    "wood_binding": ("Wood Release: Wood Binding", "Roots race across the ground and coil around the creature you're looking at, holding it fast for 4 seconds."),
    "wood_dome": ("Wood Release: Wood Dome", "A dome of wood grows up around you, keeping out attacks and projectiles for 10 seconds."),
    "deep_forest": ("Wood Release: Deep Forest Emergence", "A forest bursts out of the ground where you look. The rising trees strike everything there, then their roots seize and crush whoever stays, for 20 seconds."),
    # Ice Release (Yuki)
    "ice_needles": ("Ice Release: Ice Needles", "Throws a fan of eight needles of ice. Each one stings, slows and chills."),
    "ice_prison": ("Ice Release: Ice Prison", "Freezes the creature you're looking at solid inside a block of ice for 3 seconds."),
    "ice_mirrors": ("Ice Release: Demonic Ice Mirrors", "A ring of ice mirrors closes around your target. For 6 seconds needles fly at it from the mirrors while it stays inside the ring."),
    # Magnet Release (Kazekage)
    "iron_sand_drizzle": ("Magnet Release: Iron Sand Drizzle", "Iron sand gathers overhead and rains down in hard pellets where you look."),
    "iron_sand_coffin": ("Magnet Release: Iron Sand Coffin", "Iron sand swallows the creature you're looking at, then crushes it shut a moment later."),
    "iron_sand_world": ("Magnet Release: Iron Sand World Method", "A mass of iron sand forms in front of you and bursts into spikes in every direction."),
    # Dead Bone Pulse (Kaguya)
    "finger_bullets": ("Dead Bone Pulse: Finger Bone Bullets", "Fires the bones of your fingertips, five in a row, wherever you're aiming."),
    "willow_dance": ("Dead Bone Pulse: Dance of the Willow", "Bones jut from your arms and body like blades and armor: stronger hits and less damage taken for 20 seconds."),
    "seedling_fern": ("Dead Bone Pulse: Dance of the Seedling Fern", "A forest of huge bone spikes erupts from the ground around you in waves, impaling and throwing up everything it catches."),
    # Sealing (Uzumaki)
    "barrier": ("Sealing Technique: Barrier", "A sealing barrier surrounds you for 8 seconds. Arrows, thrown weapons and projectile jutsu are stopped at its edge, and creatures that come at you are pushed back out."),
    "adamantine_chains": ("Sealing Technique: Adamantine Sealing Chains", "Chakra chains bind the creature you're looking at for 4 seconds. A ninja loses 30% of their chakra; a creature is left weakened."),
    "five_elements_seal": ("Sealing Technique: Five Elements Seal", "Strike with five burning fingertips up close to seal the target's chakra for 10 seconds: no jutsu, eye techniques or Eight Gates. Their eyes switch off and open gates close."),
}

# Shapeless recipe ingredients for each jutsu scroll (besides the blank scroll).
SPECIAL_RECIPES = {
    "substitution": [{"tag": "minecraft:logs"}, "minecraft:lapis_lazuli"],
    "body_flicker": ["minecraft:feather", "minecraft:sugar"],
    "shadow_clone": ["minecraft:lapis_lazuli", "minecraft:lapis_lazuli", "minecraft:gold_ingot"],
    "rasengan": ["minecraft:lapis_lazuli", "minecraft:lapis_lazuli", "minecraft:diamond"],
    "shadow_possession": ["minecraft:ink_sac", "minecraft:ink_sac", "minecraft:gold_ingot"],
    "palm_rotation": ["minecraft:quartz", "minecraft:quartz", "minecraft:gold_ingot"],
    # Yin Yang: Yin jutsu use fermented spider eyes, Yang jutsu use glistering melon
    "hell_viewing": ["minecraft:fermented_spider_eye", "minecraft:fermented_spider_eye"],
    "mind_fog": ["minecraft:fermented_spider_eye", "minecraft:fermented_spider_eye", "minecraft:gold_ingot"],
    "mystical_palm": ["minecraft:glistering_melon_slice", "minecraft:glistering_melon_slice"],
    "vitality_surge": ["minecraft:glistering_melon_slice", "minecraft:glistering_melon_slice", "minecraft:gold_ingot"],
    "rasenshuriken": ["minecraft:feather", "minecraft:feather", "minecraft:lapis_lazuli", "minecraft:diamond"],
}


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def parse_jutsus():
    src = open(os.path.join(PROJECT, "src", "main", "java", "com", "shinobiarts", "jutsu", "Jutsus.java")).read()
    out = []
    for m in re.finditer(r'reg\("(\w+)",\s*(\w+),\s*(null|Clan\.\w+),\s*([DCBAS]),', src):
        jid, nature, clan, rank = m.group(1), m.group(2).lower(), m.group(3), m.group(4)
        clan = None if clan == "null" else clan.split(".")[1].lower()
        out.append({"id": jid, "nature": nature, "clan": clan, "rank": rank})
    return out


def ingredient(spec):
    return spec if isinstance(spec, dict) else {"item": spec}


def shapeless(name, ingredients, result, count=1, category="misc"):
    write_json(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:crafting_shapeless",
        "category": category,
        "ingredients": [ingredient(i) for i in ingredients],
        "result": {"item": result, "count": count},
    })
    return tuple(sorted(json.dumps(ingredient(i), sort_keys=True) for i in ingredients))


def shaped(name, pattern, key, result, count=1, category="equipment"):
    write_json(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:crafting_shaped",
        "category": category,
        "pattern": pattern,
        "key": {k: ingredient(v) for k, v in key.items()},
        "result": {"item": result, "count": count},
    })


def item_model(name, texture, parent="minecraft:item/generated"):
    write_json(os.path.join(ASSETS, "models", "item", name + ".json"),
               {"parent": parent, "textures": {"layer0": MODID + ":item/" + texture}})


# Vanilla-style hand transforms, adjusted for each 3D model (see tools/convert_models.py for the layout).
HANDHELD = {
    "thirdperson_righthand": {"rotation": [0, -90, 55], "translation": [0, 4.0, 0.5], "scale": [0.85, 0.85, 0.85]},
    "thirdperson_lefthand": {"rotation": [0, 90, -55], "translation": [0, 4.0, 0.5], "scale": [0.85, 0.85, 0.85]},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "head": {"rotation": [0, 180, 0], "translation": [0, 13, 7], "scale": [1, 1, 1]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
}
HELD_ITEM = {
    "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "head": {"rotation": [0, 180, 0], "translation": [0, 13, 7], "scale": [1, 1, 1]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
}
KUNAI_DISPLAY = json.loads(json.dumps(HANDHELD))
for k in ("thirdperson_righthand", "thirdperson_lefthand"):
    KUNAI_DISPLAY[k]["scale"] = [0.7, 0.7, 0.7]
for k in ("firstperson_righthand", "firstperson_lefthand"):
    KUNAI_DISPLAY[k]["scale"] = [0.55, 0.55, 0.55]
VANILLA_GRIP = 0.16  # where the hand holds a vanilla sword sprite (x = y, in block units)


def _grip_offset(rotation, scale, grip):
    """Where a model point at (grip, grip, 0.5) ends up after an item transform (translation excluded)."""
    d = scale * (grip - 0.5)
    v = [d, d, 0.0]
    rx, ry, rz = (math.radians(a) for a in rotation)
    # Minecraft applies Quaternionf.rotationXYZ: Rz first, then Ry, then Rx.
    v = [v[0] * math.cos(rz) - v[1] * math.sin(rz), v[0] * math.sin(rz) + v[1] * math.cos(rz), v[2]]
    v = [v[0] * math.cos(ry) + v[2] * math.sin(ry), v[1], -v[0] * math.sin(ry) + v[2] * math.cos(ry)]
    v = [v[0], v[1] * math.cos(rx) - v[2] * math.sin(rx), v[1] * math.sin(rx) + v[2] * math.cos(rx)]
    return v


def _matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def _rot_matrix(rotation):
    """The matrix Minecraft builds from a display rotation [x, y, z] (Quaternionf.rotationXYZ = Rx * Ry * Rz)."""
    rx, ry, rz = (math.radians(a) for a in rotation)
    mx = [[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]]
    my = [[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]]
    mz = [[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]]
    return _matmul(mx, _matmul(my, mz))


def _euler_xyz(m):
    """Inverse of _rot_matrix: display rotation angles (degrees) for a rotation matrix."""
    b = math.asin(max(-1.0, min(1.0, m[0][2])))
    a = math.atan2(-m[1][2], m[2][2])
    c = math.atan2(-m[0][1], m[0][0])
    return [round(math.degrees(x), 2) for x in (a, b, c)]


def _apply(rotation, v):
    m = _rot_matrix(rotation)
    return [sum(m[i][k] * v[k] for k in range(3)) for i in range(3)]


def _spin_about_blade(rotation, degrees):
    """Adds a turn around the weapon's own long axis (the model's diagonal) before the display rotation."""
    u = [1 / math.sqrt(2), 1 / math.sqrt(2), 0.0]
    c, s_, t = math.cos(math.radians(degrees)), math.sin(math.radians(degrees)), 1 - math.cos(math.radians(degrees))
    x, y, z = u
    spin = [[c + x * x * t, x * y * t - z * s_, x * z * t + y * s_],
            [y * x * t + z * s_, c + y * y * t, y * z * t - x * s_],
            [z * x * t - y * s_, z * y * t + x * s_, c + z * z * t]]
    return _euler_xyz(_matmul(_rot_matrix(rotation), spin))


def weapon_display(grip, third_scale, first_scale, ground_scale, spin=0):
    """
    Hand transforms for a weapon laid out by tools/convert_models.py with its grip at (grip, grip).
    The translation is solved so the grip lands exactly where a vanilla sword's handle is held,
    whatever the weapon's size. `grip` must match the second "grip" number in convert_models.MODELS.
    `spin` turns the weapon around its own long axis in the hand (e.g. 180 to flip which way a scythe's blades face);
    the grip stays in place because it lies on that axis.
    """
    display = json.loads(json.dumps(HANDHELD))
    for view, scale in (("thirdperson", third_scale), ("firstperson", first_scale)):
        for hand, sign in (("righthand", 1), ("lefthand", -1)):
            t = display[f"{view}_{hand}"]
            rot = HANDHELD[f"{view}_righthand"]["rotation"]
            vanilla = HANDHELD[f"{view}_righthand"]
            want = [vanilla["translation"][i] / 16 + o for i, o in
                    enumerate(_grip_offset(rot, vanilla["scale"][0], VANILLA_GRIP))]
            got = _grip_offset(rot, scale, grip)
            t["translation"] = [round(vanilla["translation"][0], 2)] + [round((want[i] - got[i]) * 16, 2) for i in (1, 2)]
            t["scale"] = [scale] * 3
            if spin:
                r = _spin_about_blade(rot, spin)
                t["rotation"] = [r[0], r[1] * sign, r[2] * sign]
    display["ground"]["scale"] = [ground_scale] * 3
    return display


def vanilla_grip_point(view):
    """Where a vanilla sword's handle is held, in the item's frame for this view (block units)."""
    v = HANDHELD[f"{view}_righthand"]
    return [v["translation"][i] / 16 + o for i, o in enumerate(_grip_offset(v["rotation"], v["scale"][0], VANILLA_GRIP))]


def scroll_display():
    """
    Rolled scrolls are held in the fist, a little below their middle, so most of the scroll shows above the hand.
    Third person: the fist sits exactly where the hand grips a sword; the scroll points forward and up (so it is
    visible from the front and the side). First person: it rises out of the bottom-right of the screen.
    """
    display = json.loads(json.dumps(HELD_ITEM))
    diag = [1 / math.sqrt(2), 1 / math.sqrt(2), 0.0]
    for view, rot, scale, along in (("thirdperson", [55, 90, 45], 0.8, 0.12), ("firstperson", [0, -90, 25], 0.72, 0.15)):
        grip = vanilla_grip_point(view)
        axis = _apply(rot, diag)  # unit vector along the scroll, after rotation
        centre = [grip[i] + along * axis[i] for i in range(3)]
        x = HANDHELD[f"{view}_righthand"]["translation"][0] / 16 if view == "firstperson" else 0.0
        for hand, sign in (("righthand", 1), ("lefthand", -1)):
            display[f"{view}_{hand}"] = {"rotation": [rot[0], rot[1] * sign, rot[2] * sign],
                                         "translation": [round(x * 16, 2), round(centre[1] * 16, 2), round(centre[2] * 16, 2)],
                                         "scale": [scale] * 3}
    return display


SCROLL_DISPLAY = scroll_display()
# name: (grip, third-person scale, first-person scale, ground scale)
WEAPONS = {
    "zabuza_blade": (0.14, 0.9, 0.5, 0.3),
    "samehada": (0.14, 0.9, 0.5, 0.3),
    "hidan_scythe": (0.14, 0.85, 0.55, 0.35, 180),  # turned over so the blades hang down
    "shakujo": (0.2, 0.85, 0.55, 0.35),
    "sword_of_fire": (0.15, 0.85, 0.62, 0.45),
    "kusanagi": (0.16, 0.85, 0.68, 0.5),
    "katana": (0.16, 0.85, 0.68, 0.5),
    # smaller in first person than a vanilla sword's 0.68 so the blades don't fill the screen
    "kiba": (0.16, 0.85, 0.56, 0.5),
    "kabutowari": (0.16, 0.85, 0.5, 0.45),
    "gunbai": (0.16, 0.8, 0.36, 0.4),
}
# Models drawn in the off hand next to a weapon (dual wield): (grip, third, first, ground). Kiba's second blade is
# the Kiba model itself.
OFFHAND_MODELS = {"kabutowari_hammer": (0.16, 0.72, 0.42, 0.4)}


def gunbai_guard_display():
    """The Gunbai while guarding (right-click held): in first person it's raised upright in front of you, face on."""
    d = weapon_display(*WEAPONS["gunbai"])
    d["firstperson_righthand"] = {"rotation": [0, -10, 45], "translation": [-4, 3.5, 0], "scale": [0.55, 0.55, 0.55]}
    d["firstperson_lefthand"] = {"rotation": [0, 10, -45], "translation": [-4, 3.5, 0], "scale": [0.55, 0.55, 0.55]}
    return d


def obj_model(name, display, obj=None, textures=None):
    """
    models/item/3d/<name>.json: a converted OBJ with its textures and hand transforms.
    `obj` reuses another model's OBJ file, and `textures` replaces its textures (in material order).
    """
    obj = obj or name
    mtl = open(os.path.join(ASSETS, "models", "item", "obj", obj + ".mtl")).read()
    keys = re.findall(r"newmtl (\w+)", mtl)
    names = textures or [f"{obj}_{i}" for i in range(len(keys))]
    textures = {k: f"{MODID}:item/model/{names[i]}" for i, k in enumerate(keys)}
    textures["particle"] = textures[keys[0]]
    write_json(os.path.join(ASSETS, "models", "item", "3d", name + ".json"), {
        "loader": "forge:obj",
        "model": f"{MODID}:models/item/obj/{obj}.obj",
        "flip_v": False,
        "automatic_culling": False,
        "shade_quads": True,
        "emissive_ambient": True,
        "render_type": "minecraft:cutout",
        "textures": textures,
        "display": display,
    })


def icon_model(name, texture, parent="minecraft:item/generated"):
    """models/item/icon/<name>.json: a flat sprite used for the inventory icon."""
    write_json(os.path.join(ASSETS, "models", "item", "icon", name + ".json"),
               {"parent": parent, "textures": {"layer0": MODID + ":item/" + texture}})


def item_3d(item, model3d, icon_texture):
    """The item's model: 3D everywhere except the inventory/item frames, which show the flat icon."""
    icon_model(item, icon_texture)
    write_json(os.path.join(ASSETS, "models", "item", item + ".json"), {
        "loader": "forge:separate_transforms",
        "gui_light": "front",
        "base": {"parent": f"{MODID}:item/3d/{model3d}"},
        "perspectives": {
            "gui": {"parent": f"{MODID}:item/icon/{item}"},
            "fixed": {"parent": f"{MODID}:item/icon/{item}"},
        },
    })


def short_name(full):
    return full.split(": ", 1)[1] if ": " in full else full



# ---------------------------------------------------------------- advancements
# Handed out from code (ninja/Achievements.java), so every criterion is "minecraft:impossible".

CLAN_ICONS = {
    "uchiha": ("shinobiarts:active_eye", "{Eye:2}"), "hyuga": ("shinobiarts:active_eye", "{Eye:7}"),
    "senju": "minecraft:oak_sapling", "uzumaki": "minecraft:nautilus_shell", "kurama": "minecraft:ender_eye",
    "kaguya": "minecraft:bone", "yuki": "minecraft:ice", "kazekage": "minecraft:sand", "chinoike": "minecraft:redstone",
    "hagoromo": "minecraft:feather", "nara": "minecraft:black_dye", "akimichi": "minecraft:cooked_beef",
    "yamanaka": "minecraft:poppy", "aburame": "minecraft:spider_eye", "inuzuka": "minecraft:lead",
    "sarutobi": "minecraft:fire_charge", "hatake": "minecraft:iron_sword", "shimura": "minecraft:phantom_membrane",
    "fuma": "shinobiarts:shuriken", "hozuki": "minecraft:water_bucket", "hoshigaki": "minecraft:prismarine_shard",
    "karatachi": "minecraft:kelp", "shirogane": "minecraft:chain", "yotsuki": "minecraft:lightning_rod",
    "kamizuru": "minecraft:honeycomb", "iburi": "minecraft:campfire", "tsuchigumo": "minecraft:cobweb",
    "funato": "minecraft:oak_boat", "taketori": "minecraft:bamboo", "otsutsuki": "minecraft:nether_star",
}
RARITY_FRAME = {"common": "task", "uncommon": "goal", "rare": "challenge", "mythic": "challenge"}
RANK_FRAME = {"D": "task", "C": "task", "B": "goal", "A": "goal", "S": "challenge"}


def parse_clans():
    src = open(os.path.join(PROJECT, "src", "main", "java", "com", "shinobiarts", "ninja", "Clan.java")).read()
    out = []
    for m in re.finditer(r'^\s+([A-Z_]+)\("(\w+)", Rarity\.(\w+), ChatFormatting\.(\w+)', src, re.M):
        if m.group(2) != "none":
            out.append({"id": m.group(2), "rarity": m.group(3).lower(), "color": m.group(4).lower()})
    return out


def advancement(path, parent, icon, title, desc, frame="task", hidden=False, announce=True, toast=True, background=None):
    item, nbt = icon if isinstance(icon, tuple) else (icon, None)
    display = {"icon": {"item": item}, "title": title, "description": desc, "frame": frame,
               "show_toast": toast, "announce_to_chat": announce, "hidden": hidden}
    if nbt:
        display["icon"]["nbt"] = nbt
    if background:
        display["background"] = background
    adv = {"display": display}
    if parent:
        adv["parent"] = MODID + ":" + parent
        adv["criteria"] = {"unlocked": {"trigger": "minecraft:impossible"}}
    else:
        adv["criteria"] = {"joined": {"trigger": "minecraft:tick"}}  # a tab's root: everyone has it
    write_json(os.path.join(DATA, "advancements", path + ".json"), adv)


def make_advancements(jutsus, lang):
    out_dir = os.path.join(DATA, "advancements")
    if os.path.isdir(out_dir):
        shutil.rmtree(out_dir)
    T = lambda key, **kw: dict({"translate": key}, **kw)

    # tab 1: releases and their jutsu
    lang.update({
        "advancements.shinobiarts.root.title": "Naruto Generations",
        "advancements.shinobiarts.root.desc": "The path of the ninja: releases, jutsu and eyes",
        "advancements.shinobiarts.release.desc": "Unlock this release",
        "advancements.shinobiarts.release_ninjutsu.desc": "Every ninja starts here",
        "advancements.shinobiarts.jutsu.desc": "Learn this %s jutsu",
    })
    advancement("root", None, "shinobiarts:release_ninjutsu", T("advancements.shinobiarts.root.title"),
                T("advancements.shinobiarts.root.desc"), announce=False, toast=False,
                background="minecraft:textures/block/spruce_planks.png")
    lang["advancements.shinobiarts.release_clan.desc"] = "Awaken your clan's own release"
    for r in RELEASES:
        if r in CLAN_RELEASES:  # hidden: only the clan that owns it ever sees it
            advancement("release/" + r, "root", MODID + ":release_" + r, T("item.shinobiarts.release_" + r),
                        T("advancements.shinobiarts.release_clan.desc"), frame="goal", hidden=True)
            continue
        desc = T("advancements.shinobiarts.release_ninjutsu.desc") if r == "ninjutsu" else T("advancements.shinobiarts.release.desc")
        advancement("release/" + r, "root", MODID + ":release_" + r, T("item.shinobiarts.release_" + r), desc,
                    frame="goal" if r == "yin_yang" else "task")
    for j in jutsus:
        release = "ninjutsu" if j["clan"] or j["nature"] == "none" else j["nature"]
        advancement("jutsu/" + j["id"], "release/" + release, MODID + ":scroll_" + j["id"],
                    T("jutsu.shinobiarts." + j["id"]),
                    T("advancements.shinobiarts.jutsu.desc", **{"with": [T("jutsu_rank.shinobiarts." + j["rank"].lower())]}),
                    frame=RANK_FRAME[j["rank"]], hidden=release in CLAN_RELEASES)

    # dojutsu, in the same tab
    eyes = [
        ("sharingan_1", "root", 0, "Sharingan", "Awaken the Sharingan", "goal"),
        ("sharingan_2", "dojutsu/sharingan_1", 1, "Two Tomoe", "Your Sharingan grows a second tomoe", "task"),
        ("sharingan_3", "dojutsu/sharingan_2", 2, "Three Tomoe", "A fully matured Sharingan", "goal"),
        ("mangekyou", "dojutsu/sharingan_3", 3, "Mangekyou Sharingan", "Awaken the Mangekyou Sharingan", "challenge"),
        ("mangekyou_itachi", "dojutsu/mangekyou", 3, "Itachi's Mangekyou", "Wield Amaterasu's black flames", "goal"),
        ("mangekyou_sasuke", "dojutsu/mangekyou", 4, "Sasuke's Mangekyou", "Wield Amaterasu's black flames", "goal"),
        ("mangekyou_obito", "dojutsu/mangekyou", 5, "Obito's Mangekyou", "Slip through the world with Kamui", "goal"),
        ("mangekyou_eternal", "dojutsu/mangekyou", 6, "Eternal Mangekyou", "Take a second Mangekyou eye: no more eye strain", "challenge"),
        ("byakugan", "root", 7, "Byakugan", "See through walls with the Byakugan", "goal"),
        ("susanoo", "dojutsu/mangekyou", 3, "Susanoo", "Summon the Susanoo", "goal"),
        ("perfect_susanoo", "dojutsu/susanoo", 6, "Perfect Susanoo", "Ride in the forehead of the Perfect Susanoo", "challenge"),
    ]
    for eid, parent, variant, title, desc, frame in eyes:
        lang["advancements.shinobiarts.dojutsu." + eid + ".title"] = title
        lang["advancements.shinobiarts.dojutsu." + eid + ".desc"] = desc
        advancement("dojutsu/" + eid, parent, (MODID + ":active_eye", "{Eye:%d}" % variant),
                    T("advancements.shinobiarts.dojutsu." + eid + ".title"), T("advancements.shinobiarts.dojutsu." + eid + ".desc"),
                    frame=frame)

    # tab 2: clans (hidden until you belong to one; announced, so everyone sees your clan)
    lang.update({
        "advancements.shinobiarts.clans.title": "Shinobi Clans",
        "advancements.shinobiarts.clans.desc": "Lock your clan in with /clanroll claim",
        "advancements.shinobiarts.clan.title": "%s Clan",
        "advancements.shinobiarts.clan.desc": "A member of the %s clan",
    })
    advancement("clans", None, "minecraft:white_banner", T("advancements.shinobiarts.clans.title"),
                T("advancements.shinobiarts.clans.desc"), announce=False, toast=False,
                background="minecraft:textures/block/stripped_dark_oak_log.png")
    clans = parse_clans()
    assert len(clans) >= 25, len(clans)
    for c in clans:
        name = T("clan.shinobiarts." + c["id"])
        advancement("clan/" + c["id"], "clans", CLAN_ICONS.get(c["id"], "minecraft:name_tag"),
                    T("advancements.shinobiarts.clan.title", **{"with": [name], "color": c["color"]}),
                    T("advancements.shinobiarts.clan.desc", **{"with": [name]}),
                    frame=RARITY_FRAME.get(c["rarity"], "task"), hidden=True)
    return len(jutsus) + len(RELEASES) + len(eyes) + len(clans) + 2


def main():
    jutsus = parse_jutsus()
    assert len(jutsus) == len(JUTSU_TEXT), (len(jutsus), sorted(set(j["id"] for j in jutsus) ^ set(JUTSU_TEXT)))

    lang = {
        "itemGroup.shinobiarts": "Naruto Generations",
        "item.shinobiarts.kunai": "Kunai",
        "item.shinobiarts.shuriken": "Shuriken",
        "item.shinobiarts.explosive_tag": "Explosive Tag",
        "item.shinobiarts.chakra_pill": "Chakra Pill",
        "item.shinobiarts.chakra_paper": "Chakra Paper",
        "item.shinobiarts.blank_scroll": "Blank Scroll",
        "item.shinobiarts.forehead_protector": "Forehead Protector",
        "tooltip.shinobiarts.headband_unworn": "Shows the village of whoever wears it",
        "tooltip.shinobiarts.headband_rogue": "No village: the plate is scratched through",
        "tooltip.shinobiarts.headband_village": "Village: %s",
        "tooltip.shinobiarts.headband_dye": "Dye the band like leather armor",
        "item.shinobiarts.exp_bottle": "Ninja EXP Bottle",
        "item.shinobiarts.frog_wallet": "Frog Wallet",
        "item.shinobiarts.bronze_ryo": "Bronze Ryo",
        "item.shinobiarts.silver_ryo": "Silver Ryo",
        "item.shinobiarts.gold_ryo": "Gold Ryo",
        "item.shinobiarts.zabuza_blade": "Kubikiribocho",
        "item.shinobiarts.samehada": "Samehada",
        "item.shinobiarts.hidan_scythe": "Hidan's Triple-Bladed Scythe",
        "item.shinobiarts.sword_of_fire": "Sword of Fire",
        "item.shinobiarts.shakujo": "Shakujo Staff",
        "item.shinobiarts.kusanagi": "Kusanagi Sword",
        "item.shinobiarts.katana": "Katana",
        "item.shinobiarts.kiba": "Kiba Blades",
        "item.shinobiarts.kabutowari": "Kabutowari (Helmet Splitter)",
        "item.shinobiarts.gunbai": "Gunbai",
        "item.shinobiarts.sharingan": "Sharingan",
        "item.shinobiarts.sharingan_eye": "Sharingan Eye",
        "item.shinobiarts.xp_boost_1_5x_30m": "XP Boost Token (1.5x, 30 min)",
        "item.shinobiarts.xp_boost_1_5x_60m": "XP Boost Token (1.5x, 1 hour)",
        "item.shinobiarts.xp_boost_2_5x_30m": "XP Boost Token (2.5x, 30 min)",
        "item.shinobiarts.xp_boost_2_5x_60m": "XP Boost Token (2.5x, 1 hour)",
        "container.shinobiarts.vault": "Vault",
        "item.shinobiarts.ninja_bandit_spawn_egg": "Ninja Bandit Spawn Egg",
        "entity.shinobiarts.ninja_bandit": "Ninja Bandit",

        # ---- stats panel (restyle)
        "screen.shinobiarts.tab_stats": "Stats",
        "screen.shinobiarts.tab_team": "Team",
        "screen.shinobiarts.tab_jutsu": "Jutsu",
        "screen.shinobiarts.upgrade": "Upgrade",
        "screen.shinobiarts.upgrade_max": "Max",
        "screen.shinobiarts.jutsu_points": "Jutsu Points: %s",
        "screen.shinobiarts.jutsu_hint": "Upgrade: %s points for +%s%% damage (max %s)",
        "screen.shinobiarts.jutsu_none": "Learn jutsu that deal damage to upgrade them here.",
        "message.shinobiarts.jutsu_points": "+%s Jutsu Points! You now have %s.",
        "message.shinobiarts.jutsu_points_ready": "An upgrade costs %s Jutsu Points and you have enough! Open the stats menu's Jutsu tab.",
        "message.shinobiarts.jutsu_max": "%s is fully upgraded.",
        "message.shinobiarts.jutsu_points_short": "An upgrade costs %s Jutsu Points (you have %s).",
        "message.shinobiarts.jutsu_upgraded": "%s upgraded to level %s: +%s%% damage!",
        "message.shinobiarts.starter_kit": "Every ninja starts with a Frog Wallet and 3 kunai. Good luck!",
        "title.shinobiarts.kage": "Kage",
        "title.shinobiarts.advisor": "Advisor",
        "screen.shinobiarts.advisors": "Need help? Advisors:",
        "screen.shinobiarts.advisor_make": "Make Village Advisor",
        "screen.shinobiarts.advisor_remove": "Remove Village Advisor",
        "screen.shinobiarts.promote": "Promote",
        "screen.shinobiarts.demote": "Demote",
        "message.shinobiarts.advisor_appointed": "%s is now a Village Advisor.",
        "message.shinobiarts.advisor_removed": "%s is no longer a Village Advisor.",
        "message.shinobiarts.advisor_by_permission": "%s is an Advisor through server permissions; ask an admin to change it.",
        "message.shinobiarts.you_advisor": "You are now a Village Advisor of %s. Players will come to you for help!",
        "message.shinobiarts.you_not_advisor": "You are no longer a Village Advisor of %s.",
        "screen.shinobiarts.exp": "EXP %s / %s",
        "screen.shinobiarts.lvl": "Lvl %s",
        "screen.shinobiarts.skill": "Skill Points: %s",
        "screen.shinobiarts.total": "Total spent: %s",
        "screen.shinobiarts.clan": "Clan:",
        "screen.shinobiarts.affiliation": "Village:",
        "screen.shinobiarts.no_village": "None",
        "screen.shinobiarts.rank_line": "Rank:",
        "screen.shinobiarts.ryo_line": "Ryo:",
        "screen.shinobiarts.nature_release": "Nature Releases",
        "screen.shinobiarts.kekkei_genkai": "Kekkei Genkai",
        "screen.shinobiarts.team_max": "Teams hold up to %s players.",

        # ---- Update 2: villages, quest board, Kage menu
        "container.shinobiarts.village_storage": "%s Storage",
        "screen.shinobiarts.quest_board": "Quest Board",
        "screen.shinobiarts.board_title": "%s Quest Board",
        "screen.shinobiarts.tab.hourly": "Hourly",
        "screen.shinobiarts.tab.daily": "Daily",
        "screen.shinobiarts.tab.weekly": "Weekly",
        "screen.shinobiarts.tab.monthly": "Monthly",
        "screen.shinobiarts.tab.kage": "Kage",
        "screen.shinobiarts.accept": "Accept",
        "screen.shinobiarts.decline": "Decline",
        "screen.shinobiarts.claim": "Claim",
        "screen.shinobiarts.in_progress": "In progress",
        "screen.shinobiarts.claimed": "Claimed",
        "screen.shinobiarts.declined": "Declined",
        "screen.shinobiarts.reward": "Reward: %s EXP bottles + %s Ryo",
        "screen.shinobiarts.posted_by": "by %s",
        "screen.shinobiarts.resets_in": "New quests in %s",
        "screen.shinobiarts.no_quests": "No quests right now. Check back soon!",
        "screen.shinobiarts.no_kage_quests": "Your Kage hasn't posted any quests.",
        "screen.shinobiarts.kage_menu": "Kage Menu",
        "screen.shinobiarts.kage_title": "%s - Kage Menu",
        "screen.shinobiarts.post_header": "Post a quest for:",
        "screen.shinobiarts.hold_item": "Hold an item in your hand",
        "screen.shinobiarts.amount": "Amount",
        "screen.shinobiarts.exp_bottles": "Bottles",
        "screen.shinobiarts.ryo_reward": "Ryo",
        "screen.shinobiarts.max": "max %s",
        "screen.shinobiarts.posted_line": "%s: %s bottles, %s Ryo",
        "screen.shinobiarts.more": "+%s more",
        "screen.shinobiarts.none_posted": "None yet.",
        "screen.shinobiarts.post_quest": "Post Quest",
        "screen.shinobiarts.posted_quests": "Posted quests",
        "screen.shinobiarts.members_online": "Village members online",
        "screen.shinobiarts.village_storage": "Village Storage",
        "quest.shinobiarts.kill_bandits": "Defeat %s Ninja Bandits",
        "quest.shinobiarts.kill_mobs": "Defeat %s hostile mobs",
        "quest.shinobiarts.kill_players": "Defeat %s enemy ninja",
        "quest.shinobiarts.fish": "Catch %s fish",
        "quest.shinobiarts.gather": "Bring %s %s",
        "quest.shinobiarts.target.logs": "Logs",
        "message.shinobiarts.no_village": "You don't belong to a village yet. Ask a server admin to add you to one.",
        "message.shinobiarts.not_kage": "Only the Kage of %s can open the Kage menu.",
        "message.shinobiarts.not_member": "You're not a member of %s.",
        "message.shinobiarts.unknown_village": "There's no village called \"%s\". Try /village list.",
        "message.shinobiarts.village_list": "Villages:",
        "message.shinobiarts.quest_complete": "Quest complete: %s! Claim your reward on the quest board (/village).",
        "message.shinobiarts.quest_claimed": "Reward claimed: %s EXP bottles and %s Ryo.",
        "message.shinobiarts.quest_need_items": "You don't have all the items for this quest.",
        "message.shinobiarts.village_storage_full": "The village storage is full. Ask your Kage to empty it.",
        "message.shinobiarts.kage_hold_item": "Hold the item the quest should ask for.",
        "message.shinobiarts.kage_too_many": "Your village already has %s posted quests. Remove one first.",
        "message.shinobiarts.kage_posted": "Village quest posted: %s",
        "message.shinobiarts.kage_rank_limit": "That rank can't be given from the Kage menu.",
        "message.shinobiarts.kage_promoted": "%s is now %s.",
        "message.shinobiarts.you_were_ranked": "You are now %s (set by %s).",

        "sharingan.shinobiarts.stage1": "1-Tomoe Sharingan",
        "sharingan.shinobiarts.stage2": "2-Tomoe Sharingan",
        "sharingan.shinobiarts.stage3": "3-Tomoe Sharingan",
        "sharingan.shinobiarts.stage4": "Mangekyou Sharingan",
        "sharingan.shinobiarts.mangekyou_design": "%s (%s)",
        "mangekyou.shinobiarts.itachi": "Itachi",
        "mangekyou.shinobiarts.sasuke": "Sasuke",
        "mangekyou.shinobiarts.obito": "Obito",
        "mangekyou.shinobiarts.eternal": "Eternal",
        "message.shinobiarts.eternal_awakened": "The second eye fuses with your own: you awaken the %s! Your techniques no longer strain your eyes.",
        "message.shinobiarts.mangekyou_techniques.itachi": "Itachi's Mangekyou: Jutsu 1 (R) casts Amaterasu where you look (sneak with your eyes on to put the black flames out). Jutsu 2 (Y): Tsukuyomi. Jutsu 3 (U): Genjutsu.",
        "message.shinobiarts.mangekyou_techniques.sasuke": "Sasuke's Mangekyou: Jutsu 1 (R) casts Amaterasu where you look (sneak with your eyes on to put the black flames out). Jutsu 2 (Y): Blaze Release spikes; Sneak + Jutsu 2: a wall of black flames. Jutsu 3 (U): Genjutsu.",
        "message.shinobiarts.mangekyou_techniques.obito": "Obito's Mangekyou: hold Jutsu 2 (Y) for Kamui (you fly through blocks and attacks pass through you until you let go). Sneak + Jutsu 2 is the Kamui snap. Jutsu 3 (U): Genjutsu.",
        "message.shinobiarts.mangekyou_techniques.eternal": "Eternal Mangekyou: Amaterasu (R) and Blaze Release (Y; Sneak + Y for the flame wall) without straining your eyes. Sneak with your eyes on to put the black flames out. Jutsu 3 (U): Genjutsu.",
        "eye.shinobiarts.amaterasu": "Amaterasu",
        "eye.shinobiarts.kamui": "Kamui",
        "eye.shinobiarts.kamui_snap": "Kamui Snap",
        "eye.shinobiarts.genjutsu": "Genjutsu",
        "eye.shinobiarts.tsukuyomi": "Tsukuyomi",
        "eye.shinobiarts.blaze": "Blaze Release",
        "eye.shinobiarts.blaze_wall": "Blaze Release: Flame Wall",
        "eye.shinobiarts.palms_64": "Eight Trigrams 64 Palms",
        "eye.shinobiarts.air_palm": "Air Palm",
        "eye.shinobiarts.all_seeing": "All-Seeing Eye",
        "message.shinobiarts.caught_in_tsukuyomi": "You're trapped in %s's Tsukuyomi!",
        "message.shinobiarts.points_sealed_by": "%s sealed your chakra points!",
        "message.shinobiarts.stunned": "You can't move!",
        "message.shinobiarts.chakra_sealed": "Your chakra points are sealed (%ss).",
        "hud.shinobiarts.behind_you": "Byakugan: %s behind you!",
        "death.attack.shinobiarts.tsukuyomi": "%1$s's mind was broken",
        "death.attack.shinobiarts.tsukuyomi.player": "%1$s's mind was broken by %2$s's Tsukuyomi",
        "death.attack.shinobiarts.tsukuyomi.item": "%1$s's mind was broken by %2$s's Tsukuyomi",
        "message.shinobiarts.no_eye_technique": "Your eyes have no technique on Jutsu %s.",
        "message.shinobiarts.eyes_off": "Switch your eyes on (V) to use %s.",
        "message.shinobiarts.amaterasu_no_room": "The black flames need solid ground to burn on.",
        "message.shinobiarts.amaterasu_extinguished": "The black flames go out.",
        "message.shinobiarts.kamui_on": "Kamui: you're intangible while you hold the key.",
        "message.shinobiarts.kamui_off": "Kamui ended.",
        "message.shinobiarts.caught_in_genjutsu": "You're caught in %s's genjutsu!",
        "hud.shinobiarts.kamui": "Kamui",
        # eye item tooltips: what the eyes do and which key does it (%s = the key, in gold)
        "tooltip.shinobiarts.eye_abilities": "Abilities (with your eyes on):",
        "tooltip.shinobiarts.your_eyes": "Your eyes: %s",
        "tooltip.shinobiarts.eye_ability.amaterasu": "%s Amaterasu: black flames where you look",
        "tooltip.shinobiarts.eye_ability.amaterasu_out": "%s Put out every black flame around you",
        "tooltip.shinobiarts.eye_ability.kamui": "%s (hold) Kamui: fly through blocks, attacks pass through you",
        "tooltip.shinobiarts.eye_ability.kamui_snap": "%s Kamui Snap: tear at the creature you look at",
        "tooltip.shinobiarts.eye_ability.genjutsu": "%s Genjutsu: trap the creature you look at in an illusion",
        "tooltip.shinobiarts.eye_ability.tsukuyomi": "%s Tsukuyomi: freeze who you look at, then break their mind",
        "tooltip.shinobiarts.eye_ability.blaze": "%s Blaze Release: black flame spikes along the ground",
        "tooltip.shinobiarts.eye_ability.susanoo": "%s Susanoo: summon it, press again to grow it a stage",
        "tooltip.shinobiarts.eye_ability.susanoo_release": "%s Release the Susanoo",
        "tooltip.shinobiarts.eye_ability.blaze_wall": "%s Flame Wall: a wall of black flames in front of you",
        "tooltip.shinobiarts.eye_ability.palms_64": "%s 64 Palms: dash in, strike and seal their chakra",
        "tooltip.shinobiarts.eye_ability.air_palm": "%s Air Palm: a blast of air that throws the target",
        "tooltip.shinobiarts.eye_ability.all_seeing": "%s All-Seeing Eye: see everyone through walls",
        "tooltip.shinobiarts.eye_ability.sharingan_passive": "Passive: dodge some attacks, copy jutsu you see cast",
        "tooltip.shinobiarts.eye_ability.next_stage": "Evolves into stronger stages as you level up",
        "tooltip.shinobiarts.eye_ability.strain": "Mangekyou techniques strain your eyes (brief blindness, 1 heart)",
        "tooltip.shinobiarts.eye_ability.eternal": "No eye strain from Mangekyou techniques",
        "tooltip.shinobiarts.eye_ability.byakugan_sight": "Passive: see in the dark and see creatures through walls",
        "tooltip.shinobiarts.eye_ability.gentle_fist": "Gentle Fist: punches hit 40% harder, weaken and drain chakra",
        "tooltip.shinobiarts.eye_ability.toggle": "%s Switch your eyes on and off",
        # toggles
        "message.shinobiarts.substitution_on": "Substitution on: attacks will hit a log instead of you.",
        "message.shinobiarts.substitution_off": "Substitution off.",
        "message.shinobiarts.substitution_unknown": "Learn the Substitution Jutsu (from its scroll) first.",
        "message.shinobiarts.chakra_control_on": "Chakra Control on: look up against a tree to climb it, and walk on water. Sneak to drop down.",
        "message.shinobiarts.chakra_control_off": "Chakra Control off.",
        "hud.shinobiarts.chakra_control": "Chakra Control",
        "block.shinobiarts.amaterasu_fire": "Amaterasu Flames",
        "entity.shinobiarts.substitution_log": "Substitution Log",
        "death.attack.shinobiarts.kamui": "%1$s was torn into another dimension",
        "death.attack.shinobiarts.kamui.player": "%1$s was torn into another dimension by %2$s",
        "death.attack.shinobiarts.kamui.item": "%1$s was torn into another dimension by %2$s",
        "message.shinobiarts.sharingan_evolved": "Your Sharingan evolved: %s!",
        "message.shinobiarts.mangekyou_awakened": "Staring death in the face, your eyes awaken the %s!",
        "message.shinobiarts.eye_taken": "You took %s's eye (%s). Right-click it to implant it.",
        "message.shinobiarts.eye_lost": "%s took your Sharingan!",
        "message.shinobiarts.eye_no_better": "Your own eyes are already this strong.",
        "message.shinobiarts.eye_too_strong": "This eye is too strong for you yet: reach level %s first.",
        "message.shinobiarts.eye_implanted": "You implanted the eye: you now have the %s.",
        "message.shinobiarts.eye_limited": "It will grow stronger as you level up (next stage at level %s).",
        "message.shinobiarts.needs_mangekyou": "This needs an active Mangekyou Sharingan.",
        "message.shinobiarts.need_sharingan": "You need a Sharingan to learn this.",

        "message.shinobiarts.combat_start": "You're in combat with %s! Logging out in the next %s seconds will kill you.",
        "message.shinobiarts.combat_over": "You're no longer in combat.",
        "message.shinobiarts.combat_no_commands": "You can't use commands while in combat (%ss left).",
        "message.shinobiarts.combat_logged": "%s logged out during combat and was killed.",
        "hud.shinobiarts.combat": "In Combat (%s) - %s",

        "message.shinobiarts.boost_started": "XP boost active: x%s ninja XP for %s minutes.",
        "message.shinobiarts.boost_extended": "XP boost extended: x%s, %s minutes left.",
        "message.shinobiarts.boost_stronger": "A stronger boost (x%s) is already running.",
        "message.shinobiarts.boost_over": "Your XP boost ran out.",
        "hud.shinobiarts.boost": "XP x%s %s",

        "message.shinobiarts.team_already_in": "You're already in a team. Leave it first with /team leave.",
        "message.shinobiarts.team_bad_name": "Team names are 2-16 letters, numbers or _.",
        "message.shinobiarts.team_name_taken": "A team called %s already exists.",
        "message.shinobiarts.team_created": "Team %s created! Invite players with /team invite <player>.",
        "message.shinobiarts.team_none": "You're not in a team.",
        "message.shinobiarts.team_not_leader": "Only the team leader can do that.",
        "message.shinobiarts.team_invite_self": "You can't invite yourself.",
        "message.shinobiarts.team_target_in_team": "%s is already in a team.",
        "message.shinobiarts.team_full": "The team is full (%s players).",
        "message.shinobiarts.team_invited": "%s invited you to the team %s.",
        "message.shinobiarts.team_accept_button": "[Accept]",
        "message.shinobiarts.team_decline_button": "[Decline]",
        "message.shinobiarts.team_invite_sent": "Invite sent to %s.",
        "message.shinobiarts.team_no_invite": "You don't have a team invite.",
        "message.shinobiarts.team_joined": "%s joined %s!",
        "message.shinobiarts.team_declined": "Invite declined.",
        "message.shinobiarts.team_left": "%s left the team.",
        "message.shinobiarts.team_you_left": "You left %s.",
        "message.shinobiarts.team_no_member": "No member called %s.",
        "message.shinobiarts.team_kicked": "You were removed from %s.",
        "message.shinobiarts.team_disbanded": "Team %s was disbanded.",
        "message.shinobiarts.team_info": "Team %s (%s/%s):",
        "message.shinobiarts.team_new_leader": "%s is now the team leader.",
        "screen.shinobiarts.team": "Team",
        "screen.shinobiarts.team_members": "Members %s/%s",
        "screen.shinobiarts.team_none": "No team yet",
        "screen.shinobiarts.team_invite": "Invite from %s",
        "screen.shinobiarts.team_leave": "Leave Team",
        "itemGroup.shinobiarts.ninja_tools": "Naruto Generations: Ninja Tools",
        "block.shinobiarts.earth_wall": "Earth Wall",
        "block.shinobiarts.wood_wall": "Wood Release Wood",
        "block.shinobiarts.ice_wall": "Ice Release Ice",
        "block.shinobiarts.iron_sand": "Iron Sand",
        "block.shinobiarts.bone_spike": "Bone Spike",
        "entity.shinobiarts.jutsu_projectile": "Jutsu",
        "entity.shinobiarts.thrown_tool": "Thrown Weapon",
        "entity.shinobiarts.explosive_tag": "Explosive Tag",
        "entity.shinobiarts.shadow_clone": "Shadow Clone",
        "effect.shinobiarts.amaterasu": "Amaterasu",

        "clan.shinobiarts.none": "None yet",
        "clan.shinobiarts.uchiha": "Uchiha",
        "clan.shinobiarts.senju": "Senju",
        "clan.shinobiarts.uzumaki": "Uzumaki",
        "clan.shinobiarts.hyuga": "Hyūga",
        "clan.shinobiarts.kurama": "Kurama",
        "clan.shinobiarts.kaguya": "Kaguya",
        "clan.shinobiarts.yuki": "Yuki",
        "clan.shinobiarts.kazekage": "Kazekage",
        "clan.shinobiarts.chinoike": "Chinoike",
        "clan.shinobiarts.hagoromo": "Hagoromo",
        "clan.shinobiarts.nara": "Nara",
        "clan.shinobiarts.akimichi": "Akimichi",
        "clan.shinobiarts.yamanaka": "Yamanaka",
        "clan.shinobiarts.aburame": "Aburame",
        "clan.shinobiarts.inuzuka": "Inuzuka",
        "clan.shinobiarts.sarutobi": "Sarutobi",
        "clan.shinobiarts.hatake": "Hatake",
        "clan.shinobiarts.shimura": "Shimura",
        "clan.shinobiarts.fuma": "Fūma",
        "clan.shinobiarts.hozuki": "Hōzuki",
        "clan.shinobiarts.hoshigaki": "Hoshigaki",
        "clan.shinobiarts.karatachi": "Karatachi",
        "clan.shinobiarts.shirogane": "Shirogane",
        "clan.shinobiarts.yotsuki": "Yotsuki",
        "clan.shinobiarts.kamizuru": "Kamizuru",
        "clan.shinobiarts.iburi": "Iburi",
        "clan.shinobiarts.tsuchigumo": "Tsuchigumo",
        "clan.shinobiarts.funato": "Funato",
        "clan.shinobiarts.taketori": "Taketori",
        "clan.shinobiarts.otsutsuki": "Ōtsutsuki",
        "clan.shinobiarts.uchiha.note": "Can awaken the Mangekyō Sharingan and learn Amaterasu",
        "clan.shinobiarts.senju.note": "Wood Release blood: stronger Earth and Water jutsu",
        "clan.shinobiarts.uzumaki.note": "Twice as many shadow clones; sealing chains can slow foes",
        "clan.shinobiarts.hyuga.note": "Gentle Fist; can learn Eight Trigrams Palm Rotation",
        "clan.shinobiarts.nara.note": "Can learn Shadow Possession",
        "rarity.shinobiarts.clanless": "No clan",
        "rarity.shinobiarts.common": "Common",
        "rarity.shinobiarts.uncommon": "Uncommon",
        "rarity.shinobiarts.rare": "Rare",
        "rarity.shinobiarts.mythic": "Mythic",
        "clanbuff.shinobiarts.sharingan": "Born with the Sharingan (1 tomoe)",
        "clanbuff.shinobiarts.byakugan": "Byakugan (press V)",
        "clanbuff.shinobiarts.affinity": "Always born with a %s affinity",
        "clanbuff.shinobiarts.chakra": "+%s%% max chakra",
        "clanbuff.shinobiarts.chakra_regen": "+%s%% chakra regeneration",
        "clanbuff.shinobiarts.health": "+%s max health",
        "clanbuff.shinobiarts.regen": "Heals %s health every 5 seconds",
        "clanbuff.shinobiarts.speed": "+%s%% movement speed",
        "clanbuff.shinobiarts.armor": "+%s armor",
        "clanbuff.shinobiarts.knockback": "+%s%% knockback resistance",
        "clanbuff.shinobiarts.melee": "+%s%% melee damage",
        "clanbuff.shinobiarts.fist": "+%s%% bare-hand damage",
        "clanbuff.shinobiarts.sword": "+%s%% sword damage",
        "clanbuff.shinobiarts.thrown": "+%s%% kunai and shuriken damage",
        "clanbuff.shinobiarts.jutsu": "+%s%% damage with every jutsu",
        "clanbuff.shinobiarts.nature": "+%s%% %s jutsu damage",
        "clanbuff.shinobiarts.genjutsu": "+%s%% genjutsu power",
        "clanbuff.shinobiarts.cooldown": "%s%% shorter jutsu cooldowns",
        "clanbuff.shinobiarts.drain": "Hits drain %s chakra from enemy ninja",
        "clanbuff.shinobiarts.on_hit.poison": "%s%% chance for hits to poison",
        "clanbuff.shinobiarts.on_hit.slow": "%s%% chance for hits to slow",
        "clanbuff.shinobiarts.on_hit.confuse": "%s%% chance for hits to confuse",
        "clanbuff.shinobiarts.on_hit.blind": "%s%% chance for hits to blind",
        "clanbuff.shinobiarts.dodge": "%s%% chance to dodge attacks",
        "clanbuff.shinobiarts.projectile": "%s%% less damage from projectiles",
        "clanbuff.shinobiarts.fall": "%s%% less fall damage",
        "clanbuff.shinobiarts.drain_resist": "%s%% resistance to chakra drain",
        "clanbuff.shinobiarts.xp": "+%s%% XP earned",
        "clanbuff.shinobiarts.night_vision": "Night vision",
        "clanbuff.shinobiarts.water_breathing": "Breathes underwater",
        "clanbuff.shinobiarts.swimming": "Swims much faster",
        "clanbuff.shinobiarts.sense": "Sneak to sense creatures nearby (they glow)",
        "message.shinobiarts.clanroll_intro": "Roll your clan with /clanroll! You get %s rolls, and /clanroll claim keeps the one you like. ",
        "message.shinobiarts.clanroll_intro_button": "[Roll my clan]",
        "message.shinobiarts.clanroll_result": "You rolled the %s clan! %s",
        "message.shinobiarts.clanroll_left": "Rolls left: %s. ",
        "message.shinobiarts.clanroll_claim_button": "[Claim]",
        "message.shinobiarts.clanroll_again_button": "[Roll again]",
        "message.shinobiarts.clanroll_last": "That was your last roll, so the %s clan is yours!",
        "message.shinobiarts.clanroll_claimed": "Sorry, you already claimed your clan.",
        "message.shinobiarts.clanroll_none_left": "You have used all of your rerolls!",
        "message.shinobiarts.clanroll_claim_done": "You claimed the %s clan! It's yours for good.",
        "message.shinobiarts.clanroll_claim_first": "You don't have a clan to claim yet. Use /clanroll first.",
        "message.shinobiarts.clan_none": "You don't have a clan yet. Use /clanroll to roll one!",
        "screen.shinobiarts.clan_roll_hint": "Use /clanroll to roll your clan (%s rolls left)",
        "screen.shinobiarts.clan_unclaimed": "Not claimed yet: /clanroll claim keeps it (%s rolls left)",
        "message.shinobiarts.clan_born": "%s rolled the %s clan! (%s)",
        "message.shinobiarts.clan_born_mythic": "The sky trembles... %s rolled the %s clan! (%s)",
        "message.shinobiarts.clan_dodged": "Evaded!",
        "message.shinobiarts.clan_yours": "Your clan: %s, %s",
        "message.shinobiarts.clan_info": "%s clan, %s",
        "message.shinobiarts.clan_list": "Clans (click one to see its bonuses):",
        "message.shinobiarts.clan_each": " (%s each)",
        "message.shinobiarts.clan_click": "Click to see this clan's bonuses",
        "message.shinobiarts.unknown_clan": "There's no clan with that name. Try /clan list.",
        "dojutsu.shinobiarts.uchiha": "Sharingan",
        "dojutsu.shinobiarts.hyuga": "Byakugan",
        "dojutsu.shinobiarts.none": "Dojutsu",
        "dojutsu.shinobiarts.uzumaki": "Dojutsu",
        "dojutsu.shinobiarts.nara": "Dojutsu",

        "key.categories.shinobiarts": "Naruto Generations",
        "key.shinobiarts.next": "Move jutsu arrow right",
        "key.shinobiarts.prev": "Move jutsu arrow left",
        "key.shinobiarts.dojutsu": "Toggle eye technique",
        "key.shinobiarts.charge": "Charge chakra (hold)",
        "key.shinobiarts.sage": "Toggle Sage Mode",
        "key.shinobiarts.stats": "Stats menu",
        "key.shinobiarts.jutsu_1": "Jutsu 1 (eye technique)",
        "key.shinobiarts.jutsu_2": "Jutsu 2 (eye technique)",
        "key.shinobiarts.jutsu_3": "Jutsu 3 (eye technique)",
        "key.shinobiarts.substitution": "Toggle Substitution (auto-dodge)",
        "key.shinobiarts.chakra_control": "Toggle Chakra Control (climb trees, walk on water)",
        "key.shinobiarts.eight_gates": "Eight Inner Gates (open the next; sneak to close)",
        "gate.shinobiarts.opening": "Gate of Opening",
        "gate.shinobiarts.healing": "Gate of Healing",
        "gate.shinobiarts.life": "Gate of Life",
        "gate.shinobiarts.pain": "Gate of Pain",
        "gate.shinobiarts.limit": "Gate of Limit",
        "gate.shinobiarts.view": "Gate of View",
        "gate.shinobiarts.wonder": "Gate of Wonder",
        "gate.shinobiarts.death": "Gate of Death",
        "message.shinobiarts.gate_open": "%s open! (gate %s)",
        "message.shinobiarts.gate8_open": "%s open! Press the Eight Gates key again for Night Guy.",
        "message.shinobiarts.gate8_end": "The Gate of Death closes. Your body is broken; the gates are locked for a while.",
        "message.shinobiarts.gates_closed": "The gates close.",
        "message.shinobiarts.gates_locked": "Your gates are locked for %s:%s more.",
        "message.shinobiarts.gates_need_taijutsu": "The %s needs %s Taijutsu points (you have %s).",
        "message.shinobiarts.night_guy": "Night Guy!",
        "hud.shinobiarts.gates": "Gate %s",

        "hud.shinobiarts.ready": "  Ready",
        "hud.shinobiarts.low_chakra": "  Low chakra",
        "hud.shinobiarts.charging": "Charging",
        "hud.shinobiarts.rasengan": "Rasengan",
        "hud.shinobiarts.substitution": "Substitution",
        "hud.shinobiarts.charge_max": "MAX",
        "hud.shinobiarts.charge_low": "Low",
        "hud.shinobiarts.charge_power": "x%s damage - let go to cast",
        "hud.shinobiarts.charge_cooldown": "On cooldown",
        "hud.shinobiarts.charge_no_chakra": "Not enough chakra",
        "hud.shinobiarts.sage": "Sage Mode",
        "hud.shinobiarts.hold_release": "Hold a release (e.g. Fire Release) to use jutsu",
        "hud.shinobiarts.release_locked": "You can't use this release yet",
        "hud.shinobiarts.release_empty": "No jutsu learned in this release",

        "screen.shinobiarts.stats": "Ninja Stats",
        "screen.shinobiarts.level": "Level %s",
        "screen.shinobiarts.xp": "%s / %s XP",
        "screen.shinobiarts.max_level": "Max level",
        "screen.shinobiarts.points": "Stat points: %s",
        "screen.shinobiarts.ryo": "Ryo: %s",
        "screen.shinobiarts.shift_add": "Shift-click to add 5 points",
        "screen.shinobiarts.reset_button": "Reset Stats (%s Ryo)",
        "screen.shinobiarts.reset_title": "Reset Stats?",
        "screen.shinobiarts.reset_text": "All %s spent points will be refunded.",
        "screen.shinobiarts.reset_price": "Price: %s Ryo",
        "screen.shinobiarts.reset_balance": "You have: %s Ryo",
        "screen.shinobiarts.reset_confirm": "Reset",
        "screen.shinobiarts.wallet": "Frog Wallet",
        "screen.shinobiarts.deposit": "Deposit",
        "screen.shinobiarts.deposit_all": "Deposit All Coins",
        "screen.shinobiarts.coin_row": "x%s · %s each",
        "screen.shinobiarts.close": "Close",
        "screen.shinobiarts.rank": "%s (level cap %s)",
        "screen.shinobiarts.rank_capped": "Level cap reached: needs a promotion",
        "rank.shinobiarts.genin": "Genin",
        "rank.shinobiarts.chunin": "Chunin",
        "rank.shinobiarts.jonin": "Jonin",
        "rank.shinobiarts.anbu": "Anbu",
        "rank.shinobiarts.sannin": "Sannin",
        "message.shinobiarts.rank_cap": "You've reached the %s level cap (%s). XP is saved until you're promoted.",
        "message.shinobiarts.promoted": "Promoted to %s! Your level cap is now %s.",
        "message.shinobiarts.pvp_reward": "Defeated %s: +%s XP, +%s Ryo",
        "message.shinobiarts.pvp_too_weak": "No reward: %s is far weaker than you.",
        "message.shinobiarts.pvp_too_strong": "No reward: %s is far stronger than you.",
        "message.shinobiarts.pvp_recent": "No reward: you defeated %s recently.",
        "message.shinobiarts.pvp_inactive": "No reward: %s wasn't moving or fighting back.",

        "stat.shinobiarts.taijutsu": "Taijutsu",
        "stat.shinobiarts.taijutsu.desc": "Stronger punches (bare hands or holding a release). Does not affect swords.",
        "stat.shinobiarts.kenjutsu": "Kenjutsu",
        "stat.shinobiarts.kenjutsu.desc": "More damage with swords, including Kubikiribocho.",
        "stat.shinobiarts.genjutsu": "Genjutsu",
        "stat.shinobiarts.genjutsu.desc": "Stronger Sharingan, Amaterasu, Shadow Possession and Yin illusions.",
        "stat.shinobiarts.medical": "Medical",
        "stat.shinobiarts.medical.desc": "More max health, and stronger Yang healing.",
        "stat.shinobiarts.speed": "Speed",
        "stat.shinobiarts.speed.desc": "Faster movement. The only stat with a cap (50 points).",
        "stat.shinobiarts.ninjutsu": "Ninjutsu",
        "stat.shinobiarts.ninjutsu.desc": "+5 max chakra per point, and slightly faster chakra regeneration.",
        "stat.shinobiarts.senjutsu": "Senjutsu",
        "stat.shinobiarts.senjutsu.desc": "Natural energy for Sage Mode (B). Gather it by charging chakra (Z) while standing still.",
        "stat.shinobiarts.effect.taijutsu": "+%s fist damage",
        "stat.shinobiarts.effect.kenjutsu": "+%s sword damage",
        "stat.shinobiarts.effect.genjutsu": "+%s%% genjutsu power",
        "stat.shinobiarts.effect.medical": "+%s max health",
        "stat.shinobiarts.effect.speed": "+%s%% speed",
        "stat.shinobiarts.effect.ninjutsu": "%s max chakra",
        "stat.shinobiarts.effect.senjutsu": "%s max senjutsu",

        "tooltip.shinobiarts.clan_only": "Clan technique: %s",
        "tooltip.shinobiarts.nature": "Nature: %s",
        "tooltip.shinobiarts.cost": "Chakra: %s  Cooldown: %ss",
        "tooltip.shinobiarts.requires_level": "Requires level %s",
        "tooltip.shinobiarts.rank": "%s Jutsu",
        "tooltip.shinobiarts.goes_to_release": "Goes into your %s slots",
        "tooltip.shinobiarts.release_hold": "Hold to equip this release's jutsu (right-click to cast, G/H move the arrow)",
        "tooltip.shinobiarts.release_locked": "You haven't unlocked this nature yet",
        "tooltip.shinobiarts.release_clan": "Clan release of the %s clan",
        "tooltip.shinobiarts.release_clan_locked": "Only its clan can use this, once their clan is claimed",
        "tooltip.shinobiarts.release_empty": "No jutsu learned yet: read jutsu scrolls to fill it",
        "tooltip.shinobiarts.coin": "Worth %s Ryo",
        "tooltip.shinobiarts.coin_stack": "Stack worth %s Ryo",
        "tooltip.shinobiarts.coin_hint": "Deposit with a Frog Wallet",
        "tooltip.shinobiarts.wallet": "Right-click to deposit or withdraw Ryo. Your Ryo stays safe even if you lose the wallet.",
        "tooltip.shinobiarts.exp_bottle": "Right-click for %s ninja XP (sneak to use the whole stack)",
        "tooltip.shinobiarts.weapon.self_repair": "Repairs itself with every hit",
        "tooltip.shinobiarts.weapon.chakra_drain": "Eats chakra: steals it from players and feeds you on every hit",
        "tooltip.shinobiarts.weapon.chidori_flow": "Chidori Flow: hits spend a little chakra to paralyse the target",
        "tooltip.shinobiarts.weapon.lifesteal": "Jashin's Ritual: heals you for part of the damage you deal",
        "tooltip.shinobiarts.weapon.burn": "Sets targets ablaze",
        "tooltip.shinobiarts.weapon.knockback": "Heavy strikes knock targets far back",
        "tooltip.shinobiarts.weapon.kenjutsu": "Boosted by Kenjutsu",
        "tooltip.shinobiarts.weapon.armor_break": "Breaks any defence: armor stops 40% less, and it knocks shields (and a guarding Gunbai) out of use for 5 s",
        "tooltip.shinobiarts.weapon.reflect": "Hold right-click to guard: blocks hits from the front, and jutsu and arrows fly back at whoever threw them",
        "tooltip.shinobiarts.weapon.lightning": "Hits spark lightning onto up to 2 nearby enemies (3 chakra)",
        "tooltip.shinobiarts.weapon.lightning_strike": "Right-click: call down lightning where you look (%s chakra, %s s cooldown)",
        "tooltip.shinobiarts.weapon.dual": "Held in both hands: keep your off hand empty",
        "tooltip.shinobiarts.sharingan": "Shows the Sharingan in your eyes",
        "tooltip.shinobiarts.sharingan_slot": "Goes in the dojutsu slot (above your off-hand) while your eyes are off. Right-click to put it on.",
        "item.shinobiarts.active_eye": "Active Eyes",
        "tooltip.shinobiarts.active_eye": "Your eyes are switched on. Press V to switch them off.",
        "message.shinobiarts.eyes_in_slot": "Your switched-on eyes are in the dojutsu slot. Switch them off (V) first.",
        "tooltip.shinobiarts.needs_dojutsu": "Learn: needs a Sharingan. Cast: needs an active Mangekyou Sharingan",
        "tooltip.shinobiarts.eye_from": "Taken from %s",
        "tooltip.shinobiarts.eye_implant": "Right-click to implant it",
        "tooltip.shinobiarts.xp_boost": "Right-click: x%s ninja XP from mobs and PvP for %s minutes (only counts down while you're online)",
        "tooltip.shinobiarts.known": "Already learned",
        "tooltip.shinobiarts.right_click_learn": "Right-click to learn",
        "tooltip.shinobiarts.nature_scroll": "Unlocks %s jutsu",
        "tooltip.shinobiarts.nature_scroll_req": "You must know your affinity first (use Chakra Paper).",
        "tooltip.shinobiarts.chakra_paper": "Right-click to discover your nature affinity.",
        "tooltip.shinobiarts.chakra_pill": "Restores %s chakra",
        "tooltip.shinobiarts.throwable": "Right-click to throw",
        "tooltip.shinobiarts.explosive_tag": "Throw it: sticks to blocks and explodes after 2 seconds.",

        "message.shinobiarts.no_target": "No target in sight.",
        "message.shinobiarts.no_room": "There's no room for that here.",
        "message.shinobiarts.hold_release": "Hold a release (e.g. Fire Release) to use its jutsu.",
        "message.shinobiarts.release_locked": "You haven't unlocked %s yet.",
        "message.shinobiarts.release_empty": "No jutsu in %s yet. Read a jutsu scroll to add one.",
        "message.shinobiarts.release_given": "You received the %s scroll.",
        "message.shinobiarts.cooldown": "%s is recharging (%ss)",
        "message.shinobiarts.needs_dojutsu": "This jutsu needs your %s active.",
        "message.shinobiarts.not_enough_chakra": "Not enough chakra (%s / %s)",
        "message.shinobiarts.sharingan_copy": "Your Sharingan copied %s!",
        "message.shinobiarts.already_known": "You already know %s.",
        "message.shinobiarts.wrong_clan": "Only the %s clan can learn this jutsu.",
        # Susanoo
        "key.shinobiarts.susanoo": "Susanoo (Sneak: release)",
        "entity.shinobiarts.susanoo": "Susanoo",
        "susanoo.shinobiarts.none": "None",
        "susanoo.shinobiarts.ribcage": "Ribcage",
        "susanoo.shinobiarts.skeletal": "Skeletal",
        "susanoo.shinobiarts.humanoid": "Humanoid",
        "susanoo.shinobiarts.armored": "Armored",
        "susanoo.shinobiarts.perfect": "Perfect",
        "message.shinobiarts.susanoo_eyes_off": "Switch your Mangekyou Sharingan on first.",
        "message.shinobiarts.susanoo_need_mangekyou": "Only the Mangekyou Sharingan can summon the Susanoo.",
        "message.shinobiarts.susanoo_gates": "The Susanoo can't stand while the Eight Gates are open.",
        "message.shinobiarts.susanoo_cooldown": "You can summon the Susanoo again in %ss.",
        "message.shinobiarts.susanoo_full": "Your Susanoo is already perfect.",
        "message.shinobiarts.susanoo_need_eternal": "The Perfect Susanoo needs the Eternal Mangekyou Sharingan.",
        "message.shinobiarts.susanoo_need_level": "The %s Susanoo needs level %s.",
        "message.shinobiarts.susanoo_no_room": "No room above you for the Perfect Susanoo.",
        "message.shinobiarts.susanoo_stage": "Susanoo: %s",
        "message.shinobiarts.susanoo_shattered": "Your Susanoo shattered! You can't summon it for %s seconds.",
        "message.shinobiarts.susanoo_no_chakra": "Your Susanoo fades: not enough chakra.",
        "message.shinobiarts.susanoo_faded_eyes": "Your Susanoo fades as your eyes close.",
        "message.shinobiarts.susanoo_faded_sealed": "Your chakra is sealed: the Susanoo fades.",
        "message.shinobiarts.susanoo_special_cooldown": "Special ready in %ss",
        "message.shinobiarts.gates_susanoo": "The gates can't be opened inside a Susanoo.",
        "hud.shinobiarts.susanoo": "Susanoo: %s",
        "hud.shinobiarts.susanoo_cooldown": "Susanoo ready in %ss",
        "hud.shinobiarts.susanoo_burning": "Amaterasu!",
        "hud.shinobiarts.susanoo_blocking": "Blocking",
        "hud.shinobiarts.susanoo_special": "Special %ss",
        "command.shinobiarts.susanoo_part": "Unknown part. Parts: %s, all",
        "command.shinobiarts.susanoo_color": "Unknown colour. Use #RRGGBB or one of: %s",
        "command.shinobiarts.susanoo_colors": "Your Susanoo's colours:",
        "message.shinobiarts.clan_release_unclaimed": "Claim your clan first (/clanroll claim) to learn %s jutsu.",
        "message.shinobiarts.clan_release_awakened": "Your %s blood awakens: %s!",
        "message.shinobiarts.need_affinity": "Discover your nature affinity with Chakra Paper first.",
        "message.shinobiarts.need_nature": "You need %s to learn this. Train it with a Training Scroll.",
        "message.shinobiarts.need_level": "You must be level %s to learn this (you are level %s).",
        "message.shinobiarts.level_up": "Level up! You are now level %s: +%s stat points and %s Ryo. Press J to spend them.",
        "message.shinobiarts.xp_gained": "+%s XP",
        "message.shinobiarts.no_points": "You have no stat points left.",
        "message.shinobiarts.stat_capped": "That stat is already maxed.",
        "message.shinobiarts.nothing_to_reset": "You haven't spent any stat points.",
        "message.shinobiarts.not_enough_ryo": "Not enough Ryo (needs %s, you have %s).",
        "message.shinobiarts.stats_reset": "Your stats were reset for %s Ryo.",
        "message.shinobiarts.no_coins": "You have no coins to deposit.",
        "message.shinobiarts.deposited": "Deposited %s Ryo",
        "message.shinobiarts.full_health": "Already at full health.",
        "message.shinobiarts.sage_on": "Sage Mode!",
        "message.shinobiarts.sage_off": "Sage Mode ended",
        "message.shinobiarts.no_senjutsu": "Put points into Senjutsu (J) to use Sage Mode.",
        "message.shinobiarts.low_senjutsu": "Not enough natural energy (%s / %s). Hold Z while standing still to gather it.",
        "message.shinobiarts.learned": "You learned %s!",
        "message.shinobiarts.already_have_nature": "You already have %s.",
        "message.shinobiarts.nature_unlocked": "You can now learn %s jutsu!",
        "message.shinobiarts.affinity_known": "Your affinity is %s.",
        "message.shinobiarts.affinity_revealed": "Your nature affinity is %s! You can now learn its jutsu.",
        "message.shinobiarts.paper.fire": "The paper ignites and burns to ash...",
        "message.shinobiarts.paper.water": "The paper turns damp...",
        "message.shinobiarts.paper.wind": "The paper splits cleanly in two...",
        "message.shinobiarts.paper.lightning": "The paper wrinkles and crackles...",
        "message.shinobiarts.paper.earth": "The paper crumbles into dirt...",
        "message.shinobiarts.pill": "+%s chakra",
        "message.shinobiarts.substitution_ready": "Substitution set: the next hit will miss you.",
        "message.shinobiarts.substitution_used": "Substitution!",
        "message.shinobiarts.rasengan_ready": "Rasengan formed: punch something!",
        "message.shinobiarts.rasengan_forming": "Your clones are shaping the Rasengan...",
        "message.shinobiarts.dodged": "Sharingan: dodged!",
        "message.shinobiarts.no_dojutsu": "Your clan has no eye technique.",
        "message.shinobiarts.dojutsu_on": "%s activated",
        "message.shinobiarts.dojutsu_off": "%s deactivated",
        "message.shinobiarts.welcome.dojutsu": "Your bloodline carries the %s. Press V to activate it.",
        "message.shinobiarts.welcome.paper": "Craft Chakra Paper (paper + lapis lazuli) to discover your nature affinity.",
        "message.shinobiarts.welcome.keys": "Hold a release, right-click to cast and press G/H to move the jutsu arrow. J opens your stats, hold Z to charge chakra, Shift+Space to Ninja Jump.",

        "death.attack.shinobiarts.jutsu": "%1$s was struck down by a jutsu",
        "death.attack.shinobiarts.jutsu.player": "%1$s was struck down by %2$s's jutsu",
        "death.attack.shinobiarts.jutsu.item": "%1$s was struck down by %2$s's jutsu using %3$s",
        "death.attack.shinobiarts.amaterasu": "%1$s was consumed by black flames",
        "death.attack.shinobiarts.amaterasu.player": "%1$s was consumed by black flames while fighting %2$s",
        "death.attack.shinobiarts.amaterasu.item": "%1$s was consumed by black flames while fighting %2$s",
    }
    for n, name in NATURE_NAMES.items():
        lang["nature.shinobiarts." + n] = name
    for r, name in RANK_NAMES.items():
        lang["jutsu_rank.shinobiarts." + r.lower()] = name
    for n in NATURES:
        lang["item.shinobiarts.nature_scroll_" + n] = NATURE_NAMES[n] + " Training Scroll"
        item_3d("nature_scroll_" + n, "scroll_training_" + n, "scroll_training_" + n + "_icon")
    for r in RELEASES:
        # named after the release itself ("Fire Release"); the Ninjutsu one follows the same pattern
        lang["item.shinobiarts.release_" + r] = NATURE_NAMES[r] if r != "ninjutsu" else "Ninjutsu Release"
        item_model("release_" + r, "release_" + r)  # held as its octagon emblem

    seen_recipes = {}

    def track(name, key):
        assert key not in seen_recipes, f"recipe {name} has the same ingredients as {seen_recipes[key]}"
        seen_recipes[key] = name

    for j in jutsus:
        jid = j["id"]
        full, desc = JUTSU_TEXT[jid]
        lang["jutsu.shinobiarts." + jid] = full
        lang["jutsu.shinobiarts." + jid + ".desc"] = desc
        lang["item.shinobiarts.scroll_" + jid] = "Jutsu Scroll: " + short_name(full)
        release = "ninjutsu" if j["clan"] or j["nature"] == "none" else j["nature"]
        item_3d("scroll_" + jid, "scroll_jutsu_" + release, "scroll_jutsu_" + release + "_icon")
        # Jutsu scrolls can't be crafted (SPECIAL_RECIPES / RECIPE_EXTRA are kept for reference only).

    for n in NATURES:
        track("nature_scroll_" + n, shapeless("nature_scroll_" + n,
                  [MODID + ":blank_scroll"] + [CATALYST[n]] * 3 + ["minecraft:emerald"], MODID + ":nature_scroll_" + n))
    # Releases can't be crafted either: they're handed over when the nature or kekkei genkai is unlocked.

    # Forehead protector: the band (layer 0, dyed) and the plate (layer 1), one plate per village
    plates = ["blank", "rogue", "leaf", "sand", "mist", "cloud", "stone"]
    for pl in plates:
        name = "forehead_protector" if pl == "blank" else "forehead_protector_" + pl
        model = {"parent": "minecraft:item/generated",
                 "textures": {"layer0": MODID + ":item/forehead_protector_band", "layer1": MODID + ":item/forehead_protector_plate_" + pl}}
        if pl == "blank":
            model["overrides"] = [{"predicate": {MODID + ":village": v}, "model": MODID + ":item/forehead_protector_" + p}
                                  for v, p in ((0.1, "rogue"), (0.2, "leaf"), (0.3, "sand"), (0.4, "mist"), (0.5, "cloud"), (0.6, "stone"))]
            model["overrides"].append({"predicate": {MODID + ":village": 0.7}, "model": MODID + ":item/forehead_protector_other"})
        write_json(os.path.join(ASSETS, "models", "item", name + ".json"), model)
    write_json(os.path.join(ASSETS, "models", "item", "forehead_protector_other.json"),
               {"parent": "minecraft:item/generated", "textures": {"layer0": MODID + ":item/forehead_protector_band",
                                                                    "layer1": MODID + ":item/forehead_protector_plate_blank"}})
    track("forehead_protector", shapeless("forehead_protector", ["minecraft:iron_ingot", {"tag": "minecraft:wool"}, {"tag": "minecraft:wool"}],
                                          MODID + ":forehead_protector", category="equipment"))

    # Basic items
    track("blank_scroll", shapeless("blank_scroll", ["minecraft:paper"] * 3 + ["minecraft:stick"], MODID + ":blank_scroll"))
    track("chakra_paper", shapeless("chakra_paper", ["minecraft:paper", "minecraft:lapis_lazuli"], MODID + ":chakra_paper", 2))
    track("chakra_pill", shapeless("chakra_pill", ["minecraft:sugar", "minecraft:sweet_berries", "minecraft:glowstone_dust"],
                                   MODID + ":chakra_pill", 2))
    track("explosive_tag", shapeless("explosive_tag", ["minecraft:paper", "minecraft:gunpowder", "minecraft:redstone"],
                                     MODID + ":explosive_tag", 2, "equipment"))
    shaped("kunai", [" I", "S "], {"I": "minecraft:iron_ingot", "S": "minecraft:stick"}, MODID + ":kunai", 3)
    shaped("shuriken", [" N ", "NIN", " N "], {"N": "minecraft:iron_nugget", "I": "minecraft:iron_ingot"}, MODID + ":shuriken", 4)

    track("frog_wallet", shapeless("frog_wallet", ["minecraft:leather", "minecraft:leather", "minecraft:slime_ball",
                                                    "minecraft:lime_dye", "minecraft:string"], MODID + ":frog_wallet"))
    shaped("zabuza_blade", ["  B", " B ", "N  "], {"B": "minecraft:iron_block", "N": "minecraft:netherite_ingot"}, MODID + ":zabuza_blade")
    shaped("samehada", ["  H", " P ", "N  "], {"H": "minecraft:heart_of_the_sea", "P": "minecraft:prismarine",
                                               "N": "minecraft:netherite_ingot"}, MODID + ":samehada")
    shaped("hidan_scythe", ["III", " N ", "S  "], {"I": "minecraft:iron_block", "N": "minecraft:netherite_ingot",
                                                   "S": "minecraft:stick"}, MODID + ":hidan_scythe")
    shaped("sword_of_fire", ["  G", " N ", "R  "], {"G": "minecraft:gold_block", "N": "minecraft:netherite_ingot",
                                                    "R": "minecraft:blaze_rod"}, MODID + ":sword_of_fire")
    shaped("shakujo", ["  B", " G ", "G  "], {"B": "minecraft:bell", "G": "minecraft:gold_block"}, MODID + ":shakujo")
    shaped("kusanagi", ["  D", " D ", "S  "], {"D": "minecraft:diamond", "S": "minecraft:stick"}, MODID + ":kusanagi")
    shaped("sharingan", ["ERE"], {"E": "minecraft:ender_eye", "R": "minecraft:redstone_block"}, MODID + ":sharingan")
    shaped("katana", ["  I", " I ", "S  "], {"I": "minecraft:iron_ingot", "S": "minecraft:stick"}, MODID + ":katana")
    shaped("kiba", ["  R", " D ", "S  "], {"R": "minecraft:lightning_rod", "D": "minecraft:diamond_block", "S": "minecraft:stick"},
           MODID + ":kiba")
    shaped("kabutowari", ["  X", " N ", "A  "], {"X": "minecraft:iron_axe", "N": "minecraft:netherite_ingot", "A": "minecraft:anvil"},
           MODID + ":kabutowari")
    shaped("gunbai", ["  H", " N ", "S  "], {"H": "minecraft:shield", "N": "minecraft:netherite_ingot", "S": "minecraft:stick"},
           MODID + ":gunbai")

    # 3D models (OBJ files come from tools/convert_models.py)
    obj_model("kunai", KUNAI_DISPLAY)
    for weapon, params in WEAPONS.items():
        obj_model(weapon, weapon_display(*params))
        item_3d(weapon, weapon, weapon + "_icon")
    for name, params in OFFHAND_MODELS.items():
        obj_model(name, weapon_display(*params))
    # Gunbai: a second model while guarding, picked by the "guarding" item property
    obj_model("gunbai_guard", gunbai_guard_display(), obj="gunbai")
    item_3d("gunbai_guarding", "gunbai_guard", "gunbai_icon")
    gunbai_path = os.path.join(ASSETS, "models", "item", "gunbai.json")
    gunbai = json.load(open(gunbai_path))
    gunbai["overrides"] = [{"predicate": {MODID + ":guarding": 1}, "model": MODID + ":item/gunbai_guarding"}]
    write_json(gunbai_path, gunbai)
    obj_model("scroll_blank", SCROLL_DISPLAY)
    for n in NATURES:  # training scroll colors (textures and icons from tools/recolor_scrolls.py)
        obj_model("scroll_training_" + n, SCROLL_DISPLAY, obj="scroll_training", textures=[f"scroll_training_{n}"])
    for r in RELEASES:  # one color of jutsu scroll per release (textures from tools/recolor_scrolls.py)
        obj_model("scroll_jutsu_" + r, SCROLL_DISPLAY, obj="scroll_jutsu", textures=[f"scroll_jutsu_{r}"])
    item_3d("kunai", "kunai", "kunai_icon")
    obj_model("shuriken", HELD_ITEM)
    item_3d("shuriken", "shuriken", "shuriken_icon")
    item_3d("blank_scroll", "scroll_blank", "scroll_blank_icon")
    for name in ("sharingan", "sharingan_eye", "xp_boost_1_5x_30m", "xp_boost_1_5x_60m", "xp_boost_2_5x_30m",
                 "xp_boost_2_5x_60m", "explosive_tag", "chakra_pill", "chakra_paper", "exp_bottle", "frog_wallet",
                 "bronze_ryo", "silver_ryo", "gold_ryo"):
        item_model(name, name)
    write_json(os.path.join(ASSETS, "models", "item", "ninja_bandit_spawn_egg.json"), {"parent": "minecraft:item/template_spawn_egg"})
    # Switched-on eyes in the dojutsu slot: one picture per stage / Mangekyou pattern / Byakugan, picked by the
    # "shinobiarts:eye" item property (client/ClientSetup), which is the variant / 10 + 0.05.
    for i in range(8):
        item_model(f"active_eye_{i}", f"active_eye_{i}")
    write_json(os.path.join(ASSETS, "models", "item", "active_eye.json"),
               {"parent": "minecraft:item/generated", "textures": {"layer0": MODID + ":item/active_eye_2"},
                "overrides": [{"predicate": {MODID + ":eye": round(i / 10, 2)}, "model": f"{MODID}:item/active_eye_{i}"}
                              for i in range(8)]})

    # Earth wall block
    write_json(os.path.join(ASSETS, "blockstates", "earth_wall.json"), {"variants": {"": {"model": MODID + ":block/earth_wall"}}})
    write_json(os.path.join(ASSETS, "models", "block", "earth_wall.json"),
               {"parent": "minecraft:block/cube_all", "textures": {"all": MODID + ":block/earth_wall"}})
    # Clan release blocks (temporary): they reuse vanilla textures, so nothing new to draw
    clan_blocks = {
        "wood_wall": {"parent": "minecraft:block/cube_column",
                      "textures": {"side": "minecraft:block/oak_log", "end": "minecraft:block/oak_log_top"}},
        "ice_wall": {"parent": "minecraft:block/cube_all", "textures": {"all": "minecraft:block/packed_ice"}},
        "iron_sand": {"parent": "minecraft:block/cube_all", "textures": {"all": "minecraft:block/black_concrete_powder"}},
        "bone_spike": {"parent": "minecraft:block/cube_column",
                       "textures": {"side": "minecraft:block/bone_block_side", "end": "minecraft:block/bone_block_top"}},
    }
    for name, model in clan_blocks.items():
        write_json(os.path.join(ASSETS, "blockstates", name + ".json"), {"variants": {"": {"model": MODID + ":block/" + name}}})
        write_json(os.path.join(ASSETS, "models", "block", name + ".json"), model)

    # Amaterasu's black flames: vanilla fire models with the black flame textures (animated, from textures/block)
    flame = MODID + ":block/amaterasu_fire"
    for i in (0, 1):
        tex = f"{MODID}:block/fire_black_layer_{i}"
        for part in ("floor", "side", "side_alt"):
            write_json(os.path.join(ASSETS, "models", "block", f"amaterasu_fire_{part}{i}.json"),
                       {"parent": f"minecraft:block/template_fire_{part}", "render_type": "minecraft:cutout",
                        "textures": {"particle": tex, "fire": tex}})
    sides = [{"model": f"{flame}_{part}{i}"} for part in ("side", "side_alt") for i in (0, 1)]
    multipart = [{"apply": [{"model": f"{flame}_floor0"}, {"model": f"{flame}_floor1"}]}, {"apply": sides}]
    for y in (90, 180, 270):
        multipart.append({"apply": [dict(s, y=y) for s in sides]})
    write_json(os.path.join(ASSETS, "blockstates", "amaterasu_fire.json"), {"multipart": multipart})

    # Damage types (for death messages)
    write_json(os.path.join(DATA, "damage_type", "jutsu.json"),
               {"exhaustion": 0.1, "message_id": "shinobiarts.jutsu", "scaling": "when_caused_by_living_non_player"})
    write_json(os.path.join(DATA, "damage_type", "amaterasu.json"),
               {"effects": "burning", "exhaustion": 0.0, "message_id": "shinobiarts.amaterasu", "scaling": "never"})
    write_json(os.path.join(DATA, "damage_type", "kamui.json"),
               {"exhaustion": 0.0, "message_id": "shinobiarts.kamui", "scaling": "never"})
    write_json(os.path.join(DATA, "damage_type", "tsukuyomi.json"),
               {"exhaustion": 0.0, "message_id": "shinobiarts.tsukuyomi", "scaling": "never"})
    # the Kamui snap and Tsukuyomi ignore armor, shields and protection enchantments
    for tag in ("bypasses_armor", "bypasses_shield", "bypasses_enchantments"):
        write_json(os.path.join(RES, "data", "minecraft", "tags", "damage_type", tag + ".json"),
                   {"replace": False, "values": [MODID + ":kamui", MODID + ":tsukuyomi"]})

    n_adv = make_advancements(jutsus, lang)
    write_json(os.path.join(ASSETS, "lang", "en_us.json"), dict(sorted(lang.items())))
    print(f"{n_adv} advancements")
    print(f"{len(jutsus)} jutsu, {len(lang)} lang keys, {len(seen_recipes) + 4 + len(WEAPONS)} recipes")


if __name__ == "__main__":
    main()
