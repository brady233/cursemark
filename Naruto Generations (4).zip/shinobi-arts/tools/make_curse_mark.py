"""Makes the Heaven curse mark overlays (player-skin layout, 256x256 = 4 pixels per skin pixel, crisp pixel art).

The seal sits on the left shoulder. When released, jagged black strokes branch out of it like cracks of black fire,
each with flame-like barbs licking off both sides, plus small flame flecks along them: first round the shoulder, then
down the upper arm and over the shoulder top, then across the left of the chest and back and on down the arm, and
finally down the ribs to the forearm and up the side of the neck onto the jaw.

The strokes are grown over the body in 3D (they bend round the corners of the arm and body as they go) and laid onto the
skin like decals, so none is cut off at an edge.

curse_l1_0..3.png  Level 1, spreading out stage by stage;
curse_seal.png     the seal (from tools/curse_src/seal.png) on the left shoulder, and curse_seal_glow.png its burning;
curse_l1_0..3      512x512; the last stages climb the left of the face round the cursed eye (drawn by the eye layer);
curse_glow_0..3    a violet outline round the marks (laid on glowing);
curse_l2.png       Level 2: grey skin, the marks sunk into it, black eyes with amber irises, a dark band over the nose;
curse_l2_glow.png  its glow.
The Level 2 wings and hair are drawn by tools/make_curse_form.py."""
import math, random
import numpy as np
from PIL import Image, ImageDraw
OUT = 'src/main/resources/assets/shinobiarts/textures/entity/curse/'
S, BIG = 4, 32
random.seed(23)

# ---------------------------------------------------------------- stencils: branching strokes and flame flecks
M = 512
SIZE, BX, BY = 440, M / 2, 476           # a stencil's base at (BX, BY), SIZE pixels long, pointing up

def bez(p0, p1, p2, t):
    return ((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0], (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1])

def stroke(d, pts_or_bez, w0, w1=0.0, n=24):
    """A tapering stroke along a quadratic curve (3 points) or a polyline (more)."""
    if len(pts_or_bez) == 3:
        pts = [bez(*pts_or_bez, i / n) for i in range(n + 1)]
    else:
        pts = pts_or_bez
    L, R = [], []
    for i, (x, y) in enumerate(pts):
        a = pts[max(0, i - 1)]; b = pts[min(len(pts) - 1, i + 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]; l = math.hypot(dx, dy) or 1
        t = i / (len(pts) - 1)
        w = w0 + (w1 - w0) * t ** 0.8
        L.append((x - dy / l * w, y + dx / l * w)); R.append((x + dy / l * w, y - dx / l * w))
    d.polygon(L + R[::-1], fill=255)

def P(x, y):
    return (BX + x * SIZE, BY - y * SIZE)

def branch_stencil(seed):
    rnd = random.Random(seed)
    img = Image.new('L', (M, M), 0)
    d = ImageDraw.Draw(img)
    phase = rnd.uniform(0, 6.28)
    main = []
    for i in range(26):
        t = i / 25
        x = math.sin(t * 7 + phase) * 0.025 + rnd.uniform(-0.012, 0.012)
        main.append((x, t * 0.98))
    stroke(d, [P(*p) for p in main], 0.12 * SIZE, 0.01 * SIZE)
    side = rnd.choice((-1, 1))
    t = 0.1
    while t < 0.86:
        i = int(t * 25)
        bx, by = main[i]
        length = rnd.uniform(0.26, 0.4) * (1 - t * 0.45)
        ang = math.radians(rnd.uniform(28, 50))
        ex, ey = bx + side * math.sin(ang) * length, by + math.cos(ang) * length
        mx, my = bx + side * math.sin(ang) * length * 0.6, by + math.cos(ang) * length * 0.35
        stroke(d, [P(bx, by), P(mx, my), P(ex, ey)], 0.065 * SIZE * (1 - t * 0.4), 0.0)
        if rnd.random() < 0.45:                                  # a smaller barb off the barb
            fx, fy = bez((bx, by), (mx, my), (ex, ey), 0.55)
            stroke(d, [P(fx, fy), P(fx + side * 0.07, fy + 0.04), P(fx + side * 0.09, fy + 0.14)], 0.03 * SIZE, 0.0)
        side = -side
        t += rnd.uniform(0.11, 0.17)
    return np.asarray(img).astype(np.float32) / 255

def flame_stencil(seed):
    rnd = random.Random(seed)
    img = Image.new('L', (M, M), 0)
    d = ImageDraw.Draw(img)
    r = 0.16 * SIZE
    cx, cy = P(0, 0.16)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
    tips = rnd.randint(3, 4)
    for k in range(tips):
        a = -0.6 + 1.2 * k / (tips - 1)
        h = 0.65 + rnd.uniform(0, 0.35) - abs(a) * 0.25
        stroke(d, [P(a * 0.12, 0.2), P(a * 0.45 + rnd.uniform(-0.08, 0.08), h * 0.55), P(a * 0.35, h)], 0.1 * SIZE, 0.0)
    return np.asarray(img).astype(np.float32) / 255

BRANCHES = [branch_stencil(s) for s in range(5)]
FLAMES = [flame_stencil(100 + s) for s in range(3)]

# ---------------------------------------------------------------- the body (model pixels: y down, -z front, +x the left)
BOXES = {'head': ((-4, -8, -4), (4, 0, 4), (0, 0), (8, 8, 8)),
         'body': ((-4, 0, -2), (4, 12, 2), (16, 16), (8, 12, 4)),
         'larm': ((4, 0, -2), (8, 12, 2), (32, 48), (4, 12, 4))}

def box_faces(part):
    (x0, y0, z0), (x1, y1, z1), (u, v), (w, h, d) = BOXES[part]
    return [
        (part, (u + d, v + d, w, h), lambda U, V, x0=x0, y0=y0, z0=z0: (x0 + U, y0 + V, z0 + 0 * U), (0, 0, -1)),
        (part, (u + 2 * d + w, v + d, w, h), lambda U, V, x1=x1, y0=y0, z1=z1: (x1 - U, y0 + V, z1 + 0 * U), (0, 0, 1)),
        (part, (u, v + d, d, h), lambda U, V, x0=x0, y0=y0, z1=z1: (x0 + 0 * U, y0 + V, z1 - U), (-1, 0, 0)),
        (part, (u + d + w, v + d, d, h), lambda U, V, x1=x1, y0=y0, z0=z0: (x1 + 0 * U, y0 + V, z0 + U), (1, 0, 0)),
        (part, (u + d, v, w, d), lambda U, V, x0=x0, y0=y0, z1=z1: (x0 + U, y0 + 0 * U, z1 - V), (0, -1, 0)),
    ]
FACES = box_faces('head') + box_faces('body') + box_faces('larm')

def allowed(part, q):
    x, y, z = q
    if part == 'body': return x > -1.2
    if part == 'head': return y > -7.2 and x > -0.8           # the left of the face, up round the eye to the temple
    return True

# ---------------------------------------------------------------- growing the strokes over the body
marks = []

def place(kind, part, c, n, up, size, plen):
    n = np.array(n, float); up = np.array(up, float)
    up = up - n * up.dot(n); up /= np.linalg.norm(up)
    across = np.cross(n, up)
    marks.append({'kind': kind, 'part': part, 'c': np.array(c, float), 'n': n, 'up': up, 'across': across, 'size': size,
                  'flip': random.random() < 0.5, 'plen': plen,
                  'sten': random.randrange(len(BRANCHES)) if kind == 'branch' else random.randrange(len(FLAMES))})

def fold(part, q, n, dirv):
    """Keeps a point on the box's skin: if it ran off the edge of its face, fold it round onto the next face."""
    lo, hi = np.array(BOXES[part][0], float), np.array(BOXES[part][1], float)
    for a in range(3):
        if abs(n[a]) > 0.5: continue
        over = q[a] - hi[a] if q[a] > hi[a] else (lo[a] - q[a] if q[a] < lo[a] else 0)
        if over <= 0: continue
        sgn = 1 if q[a] > hi[a] else -1
        q = q.copy(); q[a] = hi[a] if sgn > 0 else lo[a]
        q = q - n * over
        if np.any(q < lo - 0.01) or np.any(q > hi + 0.01): return None
        axis = np.zeros(3); axis[a] = sgn
        newdir = dirv - axis * dirv[a] + (-n) * abs(dirv[a])
        return q, axis, newdir / np.linalg.norm(newdir)
    return q, n, dirv

def turn(dirv, n, ang):
    across = np.cross(n, dirv)
    v = dirv * math.cos(ang) + across * math.sin(ang)
    return v / np.linalg.norm(v)

def grow(part, start, n, dirv, total, plen0, seg=(2.6, 3.6), width_shrink=0.93):
    q, n, dirv = np.array(start, float), np.array(n, float), np.array(dirv, float)
    dirv = dirv - n * dirv.dot(n); dirv /= np.linalg.norm(dirv)
    plen, size = plen0, seg[1]
    while plen - plen0 < total:
        L = random.uniform(*seg) * (size / seg[1])
        if not allowed(part, q): return
        place('branch', part, q, n, dirv, L, plen)
        if random.random() < 0.55:                               # a fleck of flame beside the stroke
            off = np.cross(n, dirv) * random.choice((-1, 1)) * random.uniform(0.9, 1.6)
            fq = q + dirv * L * random.uniform(0.3, 0.7) + off
            r = fold(part, fq, n, dirv)
            if r is not None and allowed(part, r[0]):
                place('flame', part, r[0], r[1], turn(r[2], r[1], random.uniform(-0.4, 0.4)), random.uniform(1.3, 1.8), plen + L * 0.5)
        if random.random() < 0.3 and plen - plen0 < total * 0.6:  # it forks
            grow(part, q + dirv * L * 0.5, n, turn(dirv, n, random.choice((-1, 1)) * random.uniform(0.5, 0.8)),
                 (total - (plen - plen0)) * 0.55, plen + L * 0.5, seg, width_shrink)
        r = fold(part, q + dirv * L * 0.9, n, dirv)
        if r is None: return
        q, n, dirv = r
        dirv = turn(dirv, n, random.uniform(-0.3, 0.3))
        plen += L * 0.9
        size *= width_shrink

SEAL = np.array([8.0, 3.0, 0.0])          # on the outside of the left shoulder (left arm, outer face)
SEAL_N = np.array([1.0, 0, 0])
# out of the seal itself: flecks all round it, then strokes in every direction over the shoulder
for k in range(8):
    a = k * math.pi / 4 + 0.3
    d = np.array([0, math.sin(a), math.cos(a)])
    place('flame', 'larm', SEAL + d * 1.75, SEAL_N, d, 1.35, 0.5)
for a, total in [(-1.57, 6), (-0.9, 7), (-2.3, 7), (0.35, 16), (0.95, 16), (1.57, 18), (2.2, 16), (2.8, 14)]:
    d = np.array([0, -math.cos(a), math.sin(a)])                 # a = 0 is straight up the arm
    grow('larm', SEAL + d * 1.3, SEAL_N, d, total, 1.0)
# down the front and back of the arm too
for start, n, d, total, p0 in [((6, 1.0, -2), (0, 0, -1), (0, 1, 0), 14, 2.5), ((6, 1.0, 2), (0, 0, 1), (0, 1, 0), 14, 2.5),
                               ((6, 0, 0), (0, -1, 0), (-0.2, 0, 1), 3, 2.0)]:
    grow('larm', start, n, d, total, p0)
# over the shoulder onto the chest and back, and down the ribs
for start, n, d, total, p0 in [
        ((3.6, 0.6, -2), (0, 0, -1), (-0.8, 0.6, 0), 9, 4.0), ((3.6, 2.5, -2), (0, 0, -1), (-0.6, 0.8, 0), 12, 5.0), ((3.6, 5.0, -2), (0, 0, -1), (-0.2, 1, 0), 10, 7.0),
        ((3.6, 0.6, 2), (0, 0, 1), (-0.8, 0.6, 0), 9, 4.0), ((3.6, 2.5, 2), (0, 0, 1), (-0.5, 0.85, 0), 12, 5.0), ((3.6, 5.0, 2), (0, 0, 1), (-0.2, 1, 0), 10, 7.0),
        ((3.0, 0.0, -1), (0, -1, 0), (-1, 0, -0.3), 4, 4.0)]:
    grow('body', start, n, d, total, p0)
# and finally up the side of the neck, over the jaw and cheek, round the cursed (left) eye and up to the temple
for start, n, d, total, p0 in [((4, -0.2, 1.0), (1, 0, 0), (0, -1, -0.5), 6.0, 11.0), ((4, -0.2, -2.5), (1, 0, 0), (0, -1, -0.2), 5.0, 11.5),
                               ((2.8, -0.2, -4), (0, 0, -1), (0.15, -1, 0), 5.5, 12.0), ((1.0, -0.2, -4), (0, 0, -1), (-0.25, -1, 0), 3.2, 12.5)]:
    grow('head', start, n, d, total, p0, seg=(1.6, 2.2))
print(len(marks), 'marks')

# ---------------------------------------------------------------- lay them onto the skin
def stamp(plen_max):
    img = np.zeros((64 * BIG, 64 * BIG), dtype=np.float32)
    for part, (fu, fv, fw, fh), pos, n in FACES:
        nb = int(fw * BIG), int(fh * BIG)
        Ug, Vg = np.meshgrid((np.arange(nb[0]) + 0.5) / BIG, (np.arange(nb[1]) + 0.5) / BIG)
        X, Y, Z = pos(Ug, Vg)
        pts = np.stack([np.broadcast_to(X, Ug.shape), np.broadcast_to(Y, Ug.shape), np.broadcast_to(Z, Ug.shape)], -1).astype(float)
        nf = np.array(n, float)
        acc = np.zeros(Ug.shape, dtype=np.float32)
        for m in marks:
            if m['plen'] > plen_max or m['part'] != part: continue
            rel = pts - m['c']
            if np.min(np.abs(rel).sum(-1)) > m['size'] * 2.0: continue
            facing = float(nf @ m['n'])
            if facing > 0.5:
                pass
            elif abs(facing) < 0.5:
                h = -(rel @ m['n'])
                if np.max(h) < -0.01: continue
                rel = rel + (m['n'] + nf)[None, None, :] * h[..., None]
            else:
                continue
            sten = BRANCHES[m['sten']] if m['kind'] == 'branch' else FLAMES[m['sten']]
            lx = rel @ m['across'] * (-1 if m['flip'] else 1)
            ly = -(rel @ m['up'])
            sx = BX + lx / m['size'] * SIZE
            sy = BY + ly / m['size'] * SIZE
            ok = (sx >= 0) & (sx < M) & (sy >= 0) & (sy < M)
            val = np.zeros(Ug.shape, dtype=np.float32)
            val[ok] = sten[sy[ok].astype(int), sx[ok].astype(int)]
            acc = np.maximum(acc, val)
        x0, y0 = int(fu * BIG), int(fv * BIG)
        img[y0:y0 + nb[1], x0:x0 + nb[0]] = np.maximum(img[y0:y0 + nb[1], x0:x0 + nb[0]], acc)
    return img

# ---------------------------------------------------------------- pixel art: 4 texture pixels per skin pixel, hard edges
def crisp(field, cut=0.42):
    """Down to 4 pixels per skin pixel by averaging, then a hard edge: each pixel is either mark or not."""
    k = BIG // S
    small = field.reshape(64 * S, k, 64 * S, k).mean(axis=(1, 3))
    return small > cut

def to_img(mask, rgb, alpha=255):
    a = np.zeros(mask.shape + (4,), dtype=np.uint8)
    a[..., 0], a[..., 1], a[..., 2] = rgb
    a[..., 3] = np.where(mask, alpha, 0)
    return Image.fromarray(a, 'RGBA')

def dilate(mask, r=1):
    out = mask.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if abs(dx) + abs(dy) > r: continue
            out |= np.roll(np.roll(mask, dy, 0), dx, 1)
    return out

def shaded(mask, base, seed, dark=0.78):
    """Mark pixels in near-black with a little purple, darker towards the middle of each stroke (like painted skin)."""
    rnd = np.random.default_rng(seed)
    core = mask & ~(dilate(~mask, 1))
    a = np.zeros(mask.shape + (4,), dtype=np.uint8)
    col = np.array(base, float)
    n = rnd.integers(-6, 7, mask.shape)
    for c in range(3):
        v = np.where(core, col[c] * dark, col[c]) + n
        a[..., c] = np.clip(v, 0, 255).astype(np.uint8)
    a[..., 3] = np.where(mask, 255, 0)
    a[~mask] = 0
    return Image.fromarray(a, 'RGBA')

# the seal, from the art in tools/curse_src/:
#   seal.png                the seal (three commas in a cracked ring), 64x64, laid 1:1 on the outside of the left
#                           shoulder (skin pixels 40..44 x 53..57) in a 1024x1024 texture, 16 pixels per skin pixel;

SRC = 'tools/curse_src/'
INK = (20, 12, 26)
VIOLET = (176, 92, 255)
EMBER = (255, 86, 34)

seal = Image.open(SRC + 'seal.png').convert('RGBA')
SEAL_TEX = Image.new('RGBA', (1024, 1024), (0, 0, 0, 0))
SEAL_TEX.alpha_composite(seal, (40 * 16, 53 * 16))
SEAL_TEX.save(OUT + 'curse_seal.png')
sm = np.asarray(SEAL_TEX)[..., 3] > 0
sg = np.zeros(sm.shape + (4,), dtype=np.uint8)
sg[sm] = (255, 140, 60, 210)                                     # the seal burns ember-orange,
sg[dilate(sm, 1) & ~sm] = EMBER + (255,)                         # with a hot rim
sg[dilate(sm, 2) & ~dilate(sm, 1)] = EMBER + (110,)
Image.fromarray(sg, 'RGBA').save(OUT + 'curse_seal_glow.png')

FS = 8                                                            # the Level 1 textures: 8 pixels per skin pixel
# the cursed eye (drawn by the eye layer, see tools/make_one_eye.py) sits in skin pixels 12.2..15.4 x 11..13.3:
# the marks keep clear of it
EYE_BOX = (int(12.2 * FS), int(11.0 * FS), int(15.4 * FS), int(13.3 * FS))

full = None
for stage, th in enumerate([3.5, 8.0, 13.0, 99.0]):
    m = crisp(stamp(th))
    full = m
    k = FS // S
    big = np.repeat(np.repeat(m, k, 0), k, 1)                     # the pixel marks, blown up without smoothing
    img = shaded(m, INK, 10 + stage).resize((64 * FS, 64 * FS), Image.NEAREST)
    # leave a clear space round the seal so its ring reads; the marks start from its edge
    yy, xx = np.mgrid[:64 * FS, :64 * FS]
    around_seal = (xx - 42 * FS) ** 2 + (yy - 55 * FS) ** 2 < (1.75 * FS) ** 2
    arr = np.asarray(img).copy()
    arr[around_seal] = 0
    ex0, ey0, ex1, ey1 = EYE_BOX                                  # and none over the cursed eye
    arr[ey0:ey1, ex0:ex1] = 0
    img = Image.fromarray(arr, 'RGBA')
    big &= ~around_seal
    big[ey0:ey1, ex0:ex1] = False
    img.save(OUT + f'curse_l1_{stage}.png')
    # glow: a violet rim round the marks
    allm = big
    g = np.zeros(big.shape + (4,), dtype=np.uint8)
    g[dilate(allm, 1) & ~allm] = VIOLET + (255,)
    g[dilate(allm, 3) & ~dilate(allm, 1)] = VIOLET + (80,)
    Image.fromarray(g, 'RGBA').save(OUT + f'curse_glow_{stage}.png')

# ---------------------------------------------------------------- Level 2: grey skin, black eyes with amber irises
rnd = np.random.default_rng(7)
N = 64 * S
l2 = np.zeros((N, N, 4), dtype=np.uint8)
def grey_rect(x, y, w, h):
    sh = rnd.integers(-7, 8, (h * S, w * S))
    # Minecraft-style shading: 2x2 blocks of slightly different grey
    sh = np.repeat(np.repeat(sh[::2, ::2], 2, 0), 2, 1)[:h * S, :w * S]
    for c, v in enumerate((118, 124, 138)):
        l2[y * S:(y + h) * S, x * S:(x + w) * S, c] = np.clip(v + sh, 0, 255)
    l2[y * S:(y + h) * S, x * S:(x + w) * S, 3] = 242
grey_rect(0, 0, 32, 16)                                          # head
grey_rect(16, 16, 24, 16)                                        # body
for (x, y) in [(40, 20), (44, 20), (48, 20), (52, 20), (32, 52), (36, 52), (40, 52), (44, 52)]:
    grey_rect(x, y, 4, 12)                                       # both arms
for (x, y) in [(44, 16), (48, 16), (36, 48), (40, 48)]:
    grey_rect(x, y, 4, 4)
# the marks sink into it as dark slate
l2[full, 0], l2[full, 1], l2[full, 2], l2[full, 3] = 44, 40, 58, 255
# face: rows of skin pixels 12 (eyes) and 13 (the band across the nose)
def px(x, y, rgba, w=1, h=1):
    l2[int(y * S):int((y + h) * S), int(x * S):int((x + w) * S)] = rgba
BLACK = (14, 10, 16, 255)
px(9, 12, BLACK, 2, 1); px(13, 12, BLACK, 2, 1)
AMBER = (255, 196, 40, 255)
# irises on the inner pixels, each with a black slit
px(10, 12.25, AMBER, 0.75, 0.75); px(13.25, 12.25, AMBER, 0.75, 0.75)
px(10.25, 12.25, BLACK, 0.25, 0.75); px(13.5, 12.25, BLACK, 0.25, 0.75)
px(9, 13, (36, 30, 44, 255), 6, 0.5)                             # the dark band over the nose
Image.fromarray(l2, 'RGBA').save(OUT + 'curse_l2.png')
# its glow: the marks' edges and the eyes
g = np.zeros((N, N, 4), dtype=np.uint8)
g[dilate(full, 1) & ~full] = VIOLET + (150,)
def gpx(x, y, rgba, w, h):
    g[int(y * S):int((y + h) * S), int(x * S):int((x + w) * S)] = rgba
gpx(10, 12.25, (255, 210, 70, 255), 0.75, 0.75); gpx(13.25, 12.25, (255, 210, 70, 255), 0.75, 0.75)
Image.fromarray(g, 'RGBA').save(OUT + 'curse_l2_glow.png')
print('skin textures ok')
