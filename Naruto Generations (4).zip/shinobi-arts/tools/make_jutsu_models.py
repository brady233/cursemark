"""
Jutsu models drawn in game from the models you made (not item models):
  Rasengan (OPREXT's "Partical rasengan"): its three shells of crossed, textured planes, plus a soft core and halo.
      assets/shinobiarts/meshes/rasengan.bin, textures/entity/rasengan/shell_0.png, shell_1.png, core.png, halo.png
  Rising Spikes (the "Earth Flow Spike Cluster" Blockbench model):
      assets/shinobiarts/meshes/earth_spikes.bin, textures/entity/earth_spikes.png
Mesh files (big-endian, read by client/JutsuMesh.java):
  int groups; per group: int texture index, float opacity, int triangles, then per corner x y z u v nx ny nz (floats).
  Rasengan units: the shells span about -0.71..0.71. Spikes: blocks, centred on the cluster's base (y = 0 at the ground).
Run: python3 tools/make_jutsu_models.py      Needs: pip install trimesh pygltflib pillow numpy
"""
import base64
import io
import json
import math
import os
import struct

import numpy as np
import pygltflib
import trimesh
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source_art")
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")


def out(*parts):
    p = os.path.join(ASSETS, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def write_mesh(path, groups):
    """groups: [(texture index, opacity, [(xyz[3], uv[3], normal[3]) per triangle])]"""
    with open(path, "wb") as f:
        f.write(struct.pack(">i", len(groups)))
        for tex, opacity, tris in groups:
            f.write(struct.pack(">ifi", tex, opacity, len(tris)))
            for P, UV, N in tris:
                for k in range(3):
                    f.write(struct.pack(">8f", *P[k], *UV[k], *N[k]))


def radial(size, stops):
    """A round gradient: stops are (radius 0..1, (r, g, b, a))."""
    img = Image.new("RGBA", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            r = math.hypot(x + 0.5 - size / 2, y + 0.5 - size / 2) / (size / 2)
            c = stops[-1][1]
            for (r0, c0), (r1, c1) in zip(stops, stops[1:]):
                if r0 <= r <= r1:
                    t = (r - r0) / max(1e-6, r1 - r0)
                    c = tuple(c0[i] + (c1[i] - c0[i]) * t for i in range(4))
                    break
            px[x, y] = tuple(int(round(v)) for v in c)
    return img


def rasengan():
    path = os.path.join(SRC, "rasengan.glb")
    g = pygltflib.GLTF2().load(path)
    blob = g.binary_blob()
    images = []
    for im in g.images:
        bv = g.bufferViews[im.bufferView]
        images.append(Image.open(io.BytesIO(blob[bv.byteOffset:bv.byteOffset + bv.byteLength])).convert("RGBA"))
    for i, im in enumerate(images):
        im.resize((256, 256), Image.LANCZOS).save(out("textures", "entity", "rasengan", f"shell_{i}.png"))
    # which image and opacity each mesh's material uses (the model's own BLEND materials)
    mesh_mat = {}
    for mi, mesh in enumerate(g.meshes):
        mat = g.materials[mesh.primitives[0].material]
        pbr = mat.pbrMetallicRoughness
        mesh_mat["Object_%d" % mi] = (g.textures[pbr.baseColorTexture.index].source, pbr.baseColorFactor[3])
    scene = trimesh.load(path, force="scene")
    groups = []
    for node in sorted(scene.graph.nodes_geometry):
        T, name = scene.graph[node]
        m = scene.geometry[name].copy()
        m.apply_transform(T)
        uv = np.asarray(m.visual.uv, dtype=float)
        tex, opacity = mesh_mat[name]
        tris = []
        for f in m.faces:
            P = [m.vertices[k].tolist() for k in f]
            UV = [[uv[k][0], 1.0 - uv[k][1]] for k in f]           # Minecraft textures run top-down
            n = np.cross(np.subtract(P[1], P[0]), np.subtract(P[2], P[0]))
            n = (n / (np.linalg.norm(n) + 1e-12)).tolist()
            tris.append((P, UV, [n, n, n]))
        groups.append((tex, float(opacity), tris))
    write_mesh(out("meshes", "rasengan.bin"), groups)
    radial(64, [(0, (255, 255, 255, 255)), (0.55, (232, 246, 255, 240)), (0.85, (190, 225, 255, 120)), (1, (160, 210, 255, 0))]
           ).save(out("textures", "entity", "rasengan", "core.png"))
    # the glow is drawn additively (RenderType.eyes ignores alpha), so its colour is premultiplied by its alpha
    halo = radial(64, [(0, (120, 190, 255, 230)), (0.45, (60, 140, 255, 90)), (1, (30, 90, 255, 0))])
    px = np.asarray(halo).astype(np.float64)
    px[..., :3] *= px[..., 3:4] / 255.0
    Image.fromarray(px.round().astype(np.uint8), "RGBA").save(out("textures", "entity", "rasengan", "halo.png"))
    print("rasengan:", [(t, round(o, 3), len(tr)) for t, o, tr in groups])


def rot_matrix(rx, ry, rz):
    x, y, z = map(math.radians, (rx, ry, rz))
    Rx = np.array([[1, 0, 0], [0, math.cos(x), -math.sin(x)], [0, math.sin(x), math.cos(x)]])
    Ry = np.array([[math.cos(y), 0, math.sin(y)], [0, 1, 0], [-math.sin(y), 0, math.cos(y)]])
    Rz = np.array([[math.cos(z), -math.sin(z), 0], [math.sin(z), math.cos(z), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def stone_recolour(tex):
    """Earth Flow Spikes are stone, not dirt: keep the texture's light and shade, but in stone greys (with a little
    speckle so it reads like rough rock)."""
    px = np.asarray(tex).astype(np.float64)
    lum = px[..., 0] * 0.3 + px[..., 1] * 0.59 + px[..., 2] * 0.11
    lo, hi = np.percentile(lum[px[..., 3] > 0], 3), np.percentile(lum[px[..., 3] > 0], 97)
    t = np.clip((lum - lo) / max(1.0, hi - lo), 0, 1)
    grey = 78 + t * 92 + np.random.default_rng(5).normal(0, 6, lum.shape)
    out_px = px.copy()
    out_px[..., 0] = grey
    out_px[..., 1] = grey
    out_px[..., 2] = grey * 1.02
    return Image.fromarray(np.clip(out_px, 0, 255).astype(np.uint8), "RGBA")


def earth_spikes():
    d = json.load(open(os.path.join(SRC, "earth_spike_cluster.bbmodel")))
    res = d.get("resolution", {"width": 16, "height": 16})
    tex = Image.open(io.BytesIO(base64.b64decode(d["textures"][0]["source"].split(",", 1)[1]))).convert("RGBA")
    tex = stone_recolour(tex)
    tex.save(out("textures", "entity", "earth_spikes.png"))
    tris = []
    for e in d["elements"]:
        if e.get("type") != "mesh" or e.get("visibility") is False:
            continue
        o = np.array(e.get("origin", [0, 0, 0]), float)
        R = rot_matrix(*e.get("rotation", [0, 0, 0]))
        verts = {k: R @ np.array(v, float) + o for k, v in e["vertices"].items()}
        centroid = np.mean(list(verts.values()), axis=0)
        for f in e["faces"].values():
            ks = f["vertices"]
            if len(ks) < 3:
                continue
            P = [verts[k] for k in ks]
            uv = [np.array(f["uv"][k], float) / [res["width"], res["height"]] for k in ks]
            if len(ks) == 4:                                       # put the quad's corners in order around it
                c = np.mean(P, 0)
                n = np.cross(P[1] - P[0], P[2] - P[0])
                if np.linalg.norm(n) < 1e-9:
                    n = np.cross(P[2] - P[0], P[3] - P[0])
                n /= np.linalg.norm(n) + 1e-12
                ax = P[0] - c
                ax /= np.linalg.norm(ax) + 1e-12
                ay = np.cross(n, ax)
                order = sorted(range(4), key=lambda i: math.atan2((P[i] - c) @ ay, (P[i] - c) @ ax))
                P = [P[i] for i in order]
                uv = [uv[i] for i in order]
                faces = [(0, 1, 2), (0, 2, 3)]
            else:
                faces = [(0, 1, 2)]
            for a, b, cc in faces:
                tri, tuv = [P[a], P[b], P[cc]], [uv[a], uv[b], uv[cc]]
                n = np.cross(tri[1] - tri[0], tri[2] - tri[0])
                if np.linalg.norm(n) < 1e-12:
                    continue
                if n @ (np.mean(tri, 0) - centroid) < 0:            # face outward from the spike's middle
                    tri, tuv = [tri[0], tri[2], tri[1]], [tuv[0], tuv[2], tuv[1]]
                    n = -n
                tris.append((tri, tuv, n / np.linalg.norm(n)))
    allp = np.vstack([t[0] for t in tris])
    lo, hi = allp.min(0), allp.max(0)
    base = np.array([(lo[0] + hi[0]) / 2, lo[1], (lo[2] + hi[2]) / 2])
    out_tris = []
    for tri, tuv, n in tris:
        P = [((p - base) / 16.0).tolist() for p in tri]
        out_tris.append((P, [list(u) for u in tuv], [n.tolist()] * 3))
    write_mesh(out("meshes", "earth_spikes.bin"), [(0, 1.0, out_tris)])
    print("earth spikes:", len(out_tris), "triangles, size (blocks)", ((hi - lo) / 16).round(2).tolist())


if __name__ == "__main__":
    rasengan()
    earth_spikes()
