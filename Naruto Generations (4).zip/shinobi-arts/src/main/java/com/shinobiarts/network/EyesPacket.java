package com.shinobiarts.network;

import com.shinobiarts.client.ClientEyes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> client: how a player looks right now: the Sharingan on their face (stage and Mangekyou pattern),
 * Lightning Armor's glow and Kamui. Packed as in SharinganManager.look.
 */
public class EyesPacket {
    private final int entityId;
    private final int look, look2;

    public EyesPacket(int entityId, int look) {
        this(entityId, look, 0);
    }

    public EyesPacket(int entityId, int look, int look2) {
        this.entityId = entityId;
        this.look = look;
        this.look2 = look2;
    }

    public EyesPacket(FriendlyByteBuf buf) {
        this.entityId = buf.readVarInt();
        this.look = buf.readInt();
        this.look2 = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(entityId);
        buf.writeInt(look);
        buf.writeVarInt(look2);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientEyes.set(entityId, look, look2));
    }
}
