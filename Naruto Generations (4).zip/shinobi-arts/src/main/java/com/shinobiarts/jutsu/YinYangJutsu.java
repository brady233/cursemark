package com.shinobiarts.jutsu;

import com.shinobiarts.fx.Fx;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Yin-Yang Release's fighting techniques (in place of the old healing ones):
 * <ul>
 *   <li><b>Yin Blades</b>: blades of black Yin chakra form in the air round you and cut three times across the front,
 *       left, right and down the middle; each cut hurts and saps the will to fight (weakness).</li>
 *   <li><b>Yang Burst</b>: all your Yang (life) force let go at once: a dome of white-gold light swells out from you,
 *       hurling everything around away and leaving them dazed.</li>
 * </ul>
 */
public final class YinYangJutsu {
    private YinYangJutsu() {}

    public static boolean yinBlades(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        float damage = JutsuUtil.dmg(8f);
        float[] angles = {-40f, 40f, 0f};                             // left-to-right, right-to-left, then straight down
        for (int i = 0; i < 3; i++) {
            float tilt = angles[i];
            Scheduler.later(i * 5, () -> {
                if (!p.isAlive() || p.hasDisconnected()) return;
                Vec3 eye = p.getEyePosition();
                Vec3 look = p.getLookAngle();
                Fx.line(p.serverLevel(), Fx.Visual.YIN_SLASH, eye.add(0, -0.3, 0), eye.add(look.scale(7)), tilt, 12);
                for (LivingEntity e : JutsuUtil.inCone(p, 7, 55)) {
                    e.invulnerableTime = 0;
                    e.hurt(ModDamage.jutsu(level, p, p), damage);
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
                    JutsuUtil.push(e, look.scale(0.5).add(0, 0.15, 0));
                }
                level.sendParticles(ParticleTypes.SQUID_INK, eye.x + look.x * 3, eye.y + look.y * 3 - 0.3, eye.z + look.z * 3, 20, 1.2, 0.5, 1.2, 0.02);
                JutsuUtil.sound(level, eye, SoundEvents.PLAYER_ATTACK_SWEEP, 1.4f, 0.5f);
                JutsuUtil.sound(level, eye, SoundEvents.WARDEN_ATTACK_IMPACT, 0.5f, 1.5f);
            });
        }
        return true;
    }

    public static boolean yangBurst(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position().add(0, 1, 0);
        final double radius = 10;
        float damage = JutsuUtil.dmg(20f);
        Fx.at(level, Fx.Visual.YANG_BURST, c, (float) radius, 24);
        for (LivingEntity e : JutsuUtil.inRadius(level, p, c, radius)) {
            if (e == p) continue;
            double dist = e.position().distanceTo(c);
            float falloff = (float) Math.max(0.4, 1 - dist / radius);
            e.invulnerableTime = 0;
            e.hurt(ModDamage.jutsu(level, p, p), damage * falloff);
            Vec3 away = e.position().subtract(p.position());
            away = away.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : away.normalize();
            JutsuUtil.push(e, away.scale(2.6 * falloff).add(0, 0.7, 0));
            e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
        }
        level.sendParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 160, radius * 0.4, 1.0, radius * 0.4, 0.3);
        JutsuUtil.sound(level, c, SoundEvents.BEACON_ACTIVATE, 2.0f, 1.6f);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 1.6f, 1.3f);
        return true;
    }
}
