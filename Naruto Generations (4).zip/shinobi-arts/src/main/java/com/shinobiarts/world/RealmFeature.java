package com.shinobiarts.world;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.world.realm.RealmShape;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** The Sage realms' block palette ({@link RealmShape#PALETTE}) as block states, read once. */
public final class RealmFeature {
    private RealmFeature() {}

    private static volatile BlockState[] states;

    public static BlockState[] states() {
        BlockState[] s = states;
        if (s == null) {
            s = new BlockState[RealmShape.PALETTE.length];
            for (int i = 0; i < s.length; i++) {
                try {
                    s[i] = BlockStateParser.parseForBlock(BuiltInRegistries.BLOCK.asLookup(), RealmShape.PALETTE[i], false).blockState();
                } catch (Exception e) {
                    ShinobiArts.LOGGER.warn("Sage realm block {} could not be read, using stone", RealmShape.PALETTE[i]);
                    s[i] = Blocks.STONE.defaultBlockState();
                }
            }
            states = s;
        }
        return s;
    }
}
