package com.shinobiarts.world.realm;

/**
 * The shape of one of the Sage realms (Mount Myoboku, Ryuchi Cave, Shikkotsu Forest): what block goes where. Plain Java,
 * no Minecraft classes, so the same code that builds the world in game can be run on its own (tools/realm_preview) to
 * check it and draw pictures of it.
 * <p>
 * Each realm fills one chunk at a time ({@link #fill}): first the terrain, column by column, then every structure that
 * reaches into the chunk (only the part inside it is written, so a temple spanning four chunks comes out whole). All of it
 * is a pure function of the block position, so it's endless and seamless in every direction.
 */
public abstract class RealmShape {
    // ---------------------------------------------------------------- the blocks (one palette for all three realms)

    public static final String[] PALETTE = {
            "minecraft:air",                                  // 0
            "minecraft:stone",                                // 1
            "minecraft:andesite",                             // 2
            "minecraft:mossy_cobblestone",                    // 3
            "minecraft:mossy_stone_bricks",                   // 4
            "minecraft:stone_bricks",                         // 5
            "minecraft:grass_block",                          // 6
            "minecraft:dirt",                                 // 7
            "minecraft:coarse_dirt",                          // 8
            "minecraft:podzol",                               // 9
            "minecraft:moss_block",                           // 10
            "minecraft:water",                                // 11
            "minecraft:spruce_log",                           // 12
            "minecraft:spruce_leaves[persistent=true]",       // 13
            "minecraft:dark_oak_log",                         // 14
            "minecraft:dark_oak_leaves[persistent=true]",     // 15
            "minecraft:red_terracotta",                       // 16
            "minecraft:red_concrete",                         // 17
            "minecraft:white_concrete",                       // 18
            "minecraft:deepslate_tiles",                      // 19
            "minecraft:red_nether_bricks",                    // 20
            "minecraft:spruce_planks",                        // 21
            "minecraft:crimson_planks",                       // 22
            "minecraft:lantern",                              // 23
            "minecraft:brown_terracotta",                     // 24
            "minecraft:terracotta",                           // 25
            "minecraft:orange_terracotta",                    // 26
            "minecraft:black_concrete",                       // 27
            "minecraft:deepslate",                            // 28
            "minecraft:cobbled_deepslate",                    // 29
            "minecraft:tuff",                                 // 30
            "minecraft:calcite",                              // 31
            "minecraft:bone_block",                           // 32
            "minecraft:smooth_quartz",                        // 33
            "minecraft:smooth_sandstone",                     // 34
            "minecraft:sea_lantern",                          // 35
            "minecraft:shroomlight",                          // 36
            "minecraft:fern",                                 // 37
            "minecraft:moss_carpet",                          // 38
            "minecraft:gravel",                               // 39
            "minecraft:polished_andesite",                    // 40
            "minecraft:ochre_froglight",                      // 41
            "minecraft:stripped_spruce_log",                  // 42
            "minecraft:polished_blackstone",                  // 43
            "minecraft:white_terracotta",                     // 44
            "minecraft:cyan_terracotta",                      // 45
            "minecraft:mud_bricks",                           // 46
            "minecraft:packed_mud",                           // 47
            "minecraft:oak_leaves[persistent=true]",          // 48
            "minecraft:jungle_log",                           // 49
            "minecraft:mangrove_roots",                       // 50
            "minecraft:yellow_terracotta",                    // 51
            "minecraft:light_gray_concrete",                  // 52
            "minecraft:dripstone_block",                      // 53
            "minecraft:smooth_stone",                         // 54
            "minecraft:barrier",                              // 55 (the bottom of the world in the cave, so nobody falls out)
            "minecraft:light[level=15]",                      // 56 (hidden light)
    };
    public static final int AIR = 0, STONE = 1, ANDESITE = 2, MOSSY_COBBLE = 3, MOSSY_BRICKS = 4, BRICKS = 5, GRASS = 6, DIRT = 7,
            COARSE = 8, PODZOL = 9, MOSS = 10, WATER = 11, SPRUCE_LOG = 12, SPRUCE_LEAVES = 13, DARK_LOG = 14, DARK_LEAVES = 15,
            RED_CLAY = 16, RED = 17, WHITE = 18, ROOF = 19, TRIM = 20, PLANKS = 21, BRIDGE = 22, LANTERN = 23, TOAD = 24,
            TOAD_DARK = 25, TOAD_BELLY = 26, BLACK = 27, DEEPSLATE = 28, COBBLED_DEEPSLATE = 29, TUFF = 30, CALCITE = 31,
            BONE = 32, QUARTZ = 33, SANDSTONE = 34, SEA_LANTERN = 35, SHROOMLIGHT = 36, FERN = 37, MOSS_CARPET = 38,
            GRAVEL = 39, POLISHED = 40, WINDOW = 41, STRIPPED = 42, BLACKSTONE = 43, PALE = 44, CYAN_CLAY = 45, MUD_BRICKS = 46,
            PACKED_MUD = 47, OAK_LEAVES = 48, JUNGLE_LOG = 49, ROOTS = 50, YELLOW_CLAY = 51, LIGHT_GRAY = 52, DRIPSTONE = 53,
            SMOOTH_STONE = 54, BARRIER = 55, LIGHT = 56;

    /** How many blocks tall the realm is (y from 0). */
    public final int height;

    protected RealmShape(int height) {
        this.height = height;
    }

    /** Fills the chunk at chunk coordinates (cx, cz). */
    public final void fill(int cx, int cz, Chunk out) {
        out.reset(cx, cz);
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) column(out.x0 + lx, out.z0 + lz, out);
        }
        structures(out);
    }

    /** The terrain of one column (world x, z). */
    protected abstract void column(int x, int z, Chunk out);

    /** Everything built on the terrain that reaches into this chunk. */
    protected abstract void structures(Chunk out);

    /** Where players arrive (x, y, z), on solid ground near the realm's landmark. */
    public abstract int[] arrival();

    // ---------------------------------------------------------------- the chunk being filled

    public static final class Chunk {
        public int x0, z0;
        public final int height;
        public final byte[] blocks;

        public Chunk(int height) {
            this.height = height;
            this.blocks = new byte[16 * 16 * height];
        }

        void reset(int cx, int cz) {
            x0 = cx << 4;
            z0 = cz << 4;
            java.util.Arrays.fill(blocks, (byte) 0);
        }

        public boolean inside(int x, int y, int z) {
            return x >= x0 && x < x0 + 16 && z >= z0 && z < z0 + 16 && y >= 0 && y < height;
        }

        public void set(int x, int y, int z, int id) {
            if (inside(x, y, z)) blocks[((y << 4) | (z - z0)) << 4 | (x - x0)] = (byte) id;
        }

        public int get(int x, int y, int z) {
            return inside(x, y, z) ? blocks[((y << 4) | (z - z0)) << 4 | (x - x0)] & 0xFF : AIR;
        }

        /** Sets only where it's air now (so decoration never cuts into what's there). */
        public void setIfAir(int x, int y, int z, int id) {
            if (inside(x, y, z) && get(x, y, z) == AIR) set(x, y, z, id);
        }

        /** Does any of the box (inclusive) reach into this chunk? */
        public boolean touches(int xa, int za, int xb, int zb) {
            return xb >= x0 && xa < x0 + 16 && zb >= z0 && za < z0 + 16;
        }

        public void box(int xa, int ya, int za, int xb, int yb, int zb, int id) {
            int lx = Math.max(xa, x0), hx = Math.min(xb, x0 + 15), lz = Math.max(za, z0), hz = Math.min(zb, z0 + 15);
            int ly = Math.max(0, ya), hy = Math.min(height - 1, yb);
            for (int y = ly; y <= hy; y++) for (int z = lz; z <= hz; z++) for (int x = lx; x <= hx; x++) set(x, y, z, id);
        }

        /** A hollow box: walls (and floor/ceiling) of {@code id}, air inside. */
        public void shell(int xa, int ya, int za, int xb, int yb, int zb, int id) {
            box(xa, ya, za, xb, yb, zb, id);
            box(xa + 1, ya + 1, za + 1, xb - 1, yb - 1, zb - 1, AIR);
        }

        /** An upright cylinder. */
        public void cylinder(double cx, double cz, int ya, int yb, double r, int id) {
            int lx = (int) Math.floor(cx - r), hx = (int) Math.ceil(cx + r), lz = (int) Math.floor(cz - r), hz = (int) Math.ceil(cz + r);
            if (!touches(lx, lz, hx, hz)) return;
            for (int x = Math.max(lx, x0); x <= Math.min(hx, x0 + 15); x++) {
                for (int z = Math.max(lz, z0); z <= Math.min(hz, z0 + 15); z++) {
                    double dx = x + 0.5 - cx, dz = z + 0.5 - cz;
                    if (dx * dx + dz * dz <= r * r) for (int y = Math.max(0, ya); y <= Math.min(height - 1, yb); y++) set(x, y, z, id);
                }
            }
        }

        /** A solid ellipsoid. */
        public void ellipsoid(double cx, double cy, double cz, double rx, double ry, double rz, int id) {
            int lx = (int) Math.floor(cx - rx), hx = (int) Math.ceil(cx + rx), lz = (int) Math.floor(cz - rz), hz = (int) Math.ceil(cz + rz);
            if (!touches(lx, lz, hx, hz)) return;
            int ly = (int) Math.floor(cy - ry), hy = (int) Math.ceil(cy + ry);
            for (int x = Math.max(lx, x0); x <= Math.min(hx, x0 + 15); x++) {
                for (int z = Math.max(lz, z0); z <= Math.min(hz, z0 + 15); z++) {
                    for (int y = Math.max(0, ly); y <= Math.min(height - 1, hy); y++) {
                        double dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry, dz = (z + 0.5 - cz) / rz;
                        if (dx * dx + dy * dy + dz * dz <= 1) set(x, y, z, id);
                    }
                }
            }
        }

        /** An ellipsoid that only fills air, with a few gaps ({@code holes} 0..1), for leaves. */
        public void blob(double cx, double cy, double cz, double rx, double ry, double rz, int id, double holes) {
            int lx = (int) Math.floor(cx - rx), hx = (int) Math.ceil(cx + rx), lz = (int) Math.floor(cz - rz), hz = (int) Math.ceil(cz + rz);
            if (!touches(lx, lz, hx, hz)) return;
            int ly = (int) Math.floor(cy - ry), hy = (int) Math.ceil(cy + ry);
            for (int x = Math.max(lx, x0); x <= Math.min(hx, x0 + 15); x++) {
                for (int z = Math.max(lz, z0); z <= Math.min(hz, z0 + 15); z++) {
                    for (int y = Math.max(0, ly); y <= Math.min(height - 1, hy); y++) {
                        double dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry, dz = (z + 0.5 - cz) / rz;
                        double d = dx * dx + dy * dy + dz * dz;
                        if (d <= 1 && !(d > 0.55 && RealmNoise.hash(x * 7 + y, z * 13 - y, 404) < holes)) setIfAir(x, y, z, id);
                    }
                }
            }
        }

        /** A ball along a path segment: a tube from a to b with radius r (for serpents, roots, bridges' arches). */
        public void tube(double ax, double ay, double az, double bx, double by, double bz, double r, int id) {
            int lx = (int) Math.floor(Math.min(ax, bx) - r), hx = (int) Math.ceil(Math.max(ax, bx) + r);
            int lz = (int) Math.floor(Math.min(az, bz) - r), hz = (int) Math.ceil(Math.max(az, bz) + r);
            if (!touches(lx, lz, hx, hz)) return;
            int ly = (int) Math.floor(Math.min(ay, by) - r), hy = (int) Math.ceil(Math.max(ay, by) + r);
            double vx = bx - ax, vy = by - ay, vz = bz - az, len2 = vx * vx + vy * vy + vz * vz;
            for (int x = Math.max(lx, x0); x <= Math.min(hx, x0 + 15); x++) {
                for (int z = Math.max(lz, z0); z <= Math.min(hz, z0 + 15); z++) {
                    for (int y = Math.max(0, ly); y <= Math.min(height - 1, hy); y++) {
                        double px = x + 0.5 - ax, py = y + 0.5 - ay, pz = z + 0.5 - az;
                        double t = len2 < 1e-9 ? 0 : Math.max(0, Math.min(1, (px * vx + py * vy + pz * vz) / len2));
                        double dx = px - vx * t, dy = py - vy * t, dz = pz - vz * t;
                        if (dx * dx + dy * dy + dz * dz <= r * r) set(x, y, z, id);
                    }
                }
            }
        }

        /** A downward cone (a stalactite) from (cx, top, cz), {@code len} long, radius {@code r} at the top. */
        public void stalactite(double cx, int top, double cz, int len, double r, int id) {
            for (int i = 0; i < len; i++) {
                double rr = r * (1 - i / (double) len);
                if (rr < 0.35) rr = 0.35;
                cylinder(cx, cz, top - i, top - i, rr, id);
            }
        }

        /** An upward cone (a spire or stalagmite). */
        public void spire(double cx, int base, double cz, int len, double r, int id) {
            for (int i = 0; i < len; i++) {
                double rr = r * (1 - i / (double) len);
                if (rr < 0.35) rr = 0.35;
                cylinder(cx, cz, base + i, base + i, rr, id);
            }
        }
    }

    // ---------------------------------------------------------------- shared building blocks

    /**
     * A pagoda: {@code tiers} storeys, each a white-walled hall with red posts at the corners, glowing windows, and a dark
     * tiled roof that overhangs and flares up at the corners, each storey a little narrower; a red spire on top.
     * Centred on (cx, cz), standing on y = base. {@code half} is half the width of the bottom storey.
     */
    protected static void pagoda(Chunk c, int cx, int base, int cz, int half, int tiers) {
        pagoda(c, cx, base, cz, half, tiers, WHITE);
    }

    /** A pagoda with walls of {@code wall}. */
    protected static void pagoda(Chunk c, int cx, int base, int cz, int half, int tiers, int wall) {
        int reach = half + 4;
        if (!c.touches(cx - reach, cz - reach, cx + reach, cz + reach)) return;
        int y = base;
        int h = half;
        c.box(cx - h - 1, y - 3, cz - h - 1, cx + h + 1, y - 1, cz + h + 1, BRICKS);           // the stone platform
        for (int t = 0; t < tiers && h >= 2; t++) {
            int storey = t == 0 ? 6 : 5;
            // walls and posts
            c.shell(cx - h, y, cz - h, cx + h, y + storey - 1, cz + h, wall);
            for (int sx = -1; sx <= 1; sx += 2) {
                for (int sz = -1; sz <= 1; sz += 2) c.box(cx + sx * h, y, cz + sz * h, cx + sx * h, y + storey - 1, cz + sz * h, RED);
            }
            // a red band and glowing windows along each wall
            for (int i = -h + 2; i <= h - 2; i += 3) {
                for (int s = -1; s <= 1; s += 2) {
                    c.box(cx + i, y + 2, cz + s * h, cx + i, y + 3, cz + s * h, WINDOW);
                    c.box(cx + s * h, y + 2, cz + i, cx + s * h, y + 3, cz + i, WINDOW);
                }
            }
            c.box(cx - h, y + storey - 1, cz - h, cx + h, y + storey - 1, cz + h, RED);
            // the doors on the ground floor
            if (t == 0) {
                c.box(cx - 1, y, cz - h, cx + 1, y + 3, cz - h, RED_CLAY);
                c.box(cx - 1, y, cz + h, cx + 1, y + 3, cz + h, RED_CLAY);
            }
            // the roof: an overhanging tiled skirt, two blocks out, the corners lifted
            int ry = y + storey;
            int o = h + 2;
            c.box(cx - o, ry, cz - o, cx + o, ry, cz + o, ROOF);
            c.box(cx - o + 1, ry + 1, cz - o + 1, cx + o - 1, ry + 1, cz + o - 1, ROOF);
            for (int sx = -1; sx <= 1; sx += 2) {
                for (int sz = -1; sz <= 1; sz += 2) {
                    c.set(cx + sx * o, ry + 1, cz + sz * o, TRIM);
                    c.set(cx + sx * (o + 1), ry + 1, cz + sz * (o + 1), TRIM);
                }
            }
            // red trim under the eaves
            for (int i = -o; i <= o; i++) {
                c.set(cx + i, ry - 1, cz - o, TRIM);
                c.set(cx + i, ry - 1, cz + o, TRIM);
                c.set(cx - o, ry - 1, cz + i, TRIM);
                c.set(cx + o, ry - 1, cz + i, TRIM);
            }
            for (int i = -o + 1; i <= o - 1; i++) {                 // clear under the eaves (the trim hangs from the roof)
                for (int s = -1; s <= 1; s += 2) {
                    c.set(cx + i, ry - 1, cz + s * (o - 1), c.get(cx + i, ry - 1, cz + s * (o - 1)) == TRIM ? AIR : c.get(cx + i, ry - 1, cz + s * (o - 1)));
                }
            }
            y = ry + 2;
            h -= (tiers > 3 ? 1 : 2);
        }
        // the spire
        c.box(cx, y, cz, cx, y + 4, cz, TRIM);
        c.set(cx, y + 5, cz, LANTERN);
    }

    /** A torii gate facing along z (the opening runs along z), centred on (cx, cz), standing on y = base. */
    protected static void torii(Chunk c, int cx, int base, int cz, int half, int tall) {
        c.box(cx - half, base, cz, cx - half, base + tall, cz, RED);
        c.box(cx + half, base, cz, cx + half, base + tall, cz, RED);
        c.box(cx - half - 1, base + tall - 2, cz, cx + half + 1, base + tall - 2, cz, RED);       // the lower beam
        c.box(cx - half - 2, base + tall + 1, cz, cx + half + 2, base + tall + 1, cz, BLACK);     // the top beam
        c.box(cx - half - 2, base + tall + 1, cz - 1, cx + half + 2, base + tall + 1, cz + 1, BLACK);
        c.set(cx - half - 3, base + tall + 2, cz, BLACK);
        c.set(cx + half + 3, base + tall + 2, cz, BLACK);
        c.box(cx - half - 1, base + tall, cz, cx + half + 1, base + tall, cz, RED);
        c.box(cx, base + tall - 1, cz, cx, base + tall, cz, BLACK);                                // the plaque
    }

    /** A stone lantern post. */
    protected static void lanternPost(Chunk c, int x, int base, int z) {
        c.box(x, base, z, x, base + 1, z, POLISHED);
        c.set(x, base + 2, z, WINDOW);
        c.box(x - 1, base + 3, z - 1, x + 1, base + 3, z + 1, POLISHED);
        c.set(x, base + 4, z, POLISHED);
    }

    /**
     * An arched red bridge from (xa, za) to (xb, zb), its ends at height ya/yb, rising {@code rise} in the middle: a plank
     * deck three wide with red rails and posts.
     */
    protected static void bridge(Chunk c, int xa, int ya, int za, int xb, int yb, int zb, int rise) {
        double dx = xb - xa, dz = zb - za, len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1) return;
        int lx = Math.min(xa, xb) - 3, hx = Math.max(xa, xb) + 3, lz = Math.min(za, zb) - 3, hz = Math.max(za, zb) + 3;
        if (!c.touches(lx, lz, hx, hz)) return;
        double ux = dx / len, uz = dz / len, px = -uz, pz = ux;
        int steps = (int) Math.ceil(len * 2);
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            double x = xa + dx * t, z = za + dz * t;
            int y = (int) Math.round(ya + (yb - ya) * t + rise * Math.sin(Math.PI * t));
            for (int w = -1; w <= 1; w++) c.set((int) Math.floor(x + px * w), y, (int) Math.floor(z + pz * w), BRIDGE);
            for (int s = -1; s <= 1; s += 2) {
                int rx = (int) Math.floor(x + px * 2 * s), rz = (int) Math.floor(z + pz * 2 * s);
                c.set(rx, y, rz, BRIDGE);
                c.set(rx, y + 1, rz, i % 6 == 0 ? RED : TRIM);
                if (i % 6 == 0) c.set(rx, y + 2, rz, RED);
            }
            c.set((int) Math.floor(x), y - 1, (int) Math.floor(z), RED);                            // the red arch under it
        }
    }

    /** A conifer: a straight trunk and stacked, narrowing tiers of needles (spruce), standing on y = base. */
    protected static void conifer(Chunk c, int x, int base, int z, int tall, long seed) {
        c.box(x, base, z, x, base + tall - 1, z, SPRUCE_LOG);
        int top = base + tall;
        int r = Math.max(2, tall / 4);
        for (int y = base + tall / 3; y <= top; y++) {
            double t = (y - (base + tall / 3)) / (double) Math.max(1, top - (base + tall / 3));
            double rr = r * (1 - t) + 0.6;
            if (((y - base) & 1) == 1) rr *= 0.75;                   // the layered look
            int lr = (int) Math.ceil(rr);
            for (int dx = -lr; dx <= lr; dx++) {
                for (int dz = -lr; dz <= lr; dz++) {
                    if (dx * dx + dz * dz <= rr * rr && !(dx == 0 && dz == 0 && y < top)) c.setIfAir(x + dx, y, z + dz, SPRUCE_LEAVES);
                }
            }
        }
        c.setIfAir(x, top + 1, z, SPRUCE_LEAVES);
    }

    // ---------------------------------------------------------------- small helpers

    protected static int floorDiv(int a, int b) {
        return Math.floorDiv(a, b);
    }

    protected static double smooth(double t) {
        t = Math.max(0, Math.min(1, t));
        return t * t * (3 - 2 * t);
    }
}
