package com.shinobiarts.world;

import com.mojang.serialization.Codec;
import com.shinobiarts.ninja.KamuiDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * The Kamui dimension's blocks, laid down as part of world generation so they go on forever: every chunk gets the
 * pieces of whichever pillars (KamuiDimension.pillar) stand in it, as it's generated, wherever anyone goes, plus
 * hidden light blocks on the pillar tops so the place is dim but never pitch black. There is no floor: below is void.
 */
public class KamuiPillarsFeature extends Feature<NoneFeatureConfiguration> {
    public KamuiPillarsFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        int x0 = ctx.origin().getX() & ~15, z0 = ctx.origin().getZ() & ~15;
        int cell = KamuiDimension.CELL;
        BlockState block = KamuiDimension.block();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int cx = Math.floorDiv(x0, cell); cx <= Math.floorDiv(x0 + 15, cell); cx++) {
            for (int cz = Math.floorDiv(z0, cell); cz <= Math.floorDiv(z0 + 15, cell); cz++) {
                int[] p = KamuiDimension.pillar(cx, cz);
                if (p == null) continue;
                // only the part of this pillar that's inside this chunk
                int ax = Math.max(p[0], x0), bx = Math.min(p[0] + p[2], x0 + 16);
                int az = Math.max(p[1], z0), bz = Math.min(p[1] + p[2], z0 + 16);
                for (int x = ax; x < bx; x++) {
                    for (int z = az; z < bz; z++) {
                        for (int y = 1; y <= p[3]; y++) {
                            level.setBlock(m.set(x, y, z), block, Block.UPDATE_CLIENTS);
                        }
                    }
                }
            }
        }
        // invisible light blocks so people can see where they're standing: a grid over every pillar's top (light blocks can't be seen or hit, and anything placed there simply replaces them)
        for (int cx = Math.floorDiv(x0, cell); cx <= Math.floorDiv(x0 + 15, cell); cx++) {
            for (int cz = Math.floorDiv(z0, cell); cz <= Math.floorDiv(z0 + 15, cell); cz++) {
                int[] p = KamuiDimension.pillar(cx, cz);
                if (p == null) continue;
                for (int x = p[0] + 1; x < p[0] + p[2]; x += TOP_SPACING) {
                    for (int z = p[1] + 1; z < p[1] + p[2]; z += TOP_SPACING) {
                        if (x >= x0 && x < x0 + 16 && z >= z0 && z < z0 + 16) light(level, m.set(x, p[3] + 1, z), TOP_LIGHT);
                    }
                }
            }
        }
        return true;
    }

    /** Light level and spacing of the hidden lights on pillar tops. */
    private static final int TOP_LIGHT = 15, TOP_SPACING = 3;

    private static void light(WorldGenLevel level, BlockPos pos, int strength) {
        if (!level.getBlockState(pos).isAir()) return;          // inside a pillar
        level.setBlock(pos, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, strength), Block.UPDATE_CLIENTS);
    }
}
