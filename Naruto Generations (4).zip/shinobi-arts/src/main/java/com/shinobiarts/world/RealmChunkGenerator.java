package com.shinobiarts.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.shinobiarts.world.realm.MyobokuShape;
import com.shinobiarts.world.realm.RealmShape;
import com.shinobiarts.world.realm.RyuchiShape;
import com.shinobiarts.world.realm.ShikkotsuShape;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Supplier;

/**
 * The Sage realms' world generator (type "shinobiarts:realm" in data/shinobiarts/dimension): it builds each chunk
 * straight from the realm's {@link RealmShape} as the chunk's terrain, the same way the game's own generators fill a
 * chunk, so the realm is there the moment anything loads it. "realm" picks which one: myoboku, ryuchi or shikkotsu.
 */
public class RealmChunkGenerator extends ChunkGenerator {
    public static final Codec<RealmChunkGenerator> CODEC = RecordCodecBuilder.create(i -> i.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(ChunkGenerator::getBiomeSource),
            Codec.STRING.fieldOf("realm").forGetter(g -> g.realm)
    ).apply(i, RealmChunkGenerator::new));

    private final String realm;
    private final Supplier<RealmShape> factory;
    private final ThreadLocal<RealmShape> shape;
    private final ThreadLocal<RealmShape.Chunk> buffer;
    private final int height;

    public RealmChunkGenerator(BiomeSource biomes, String realm) {
        super(biomes);
        this.realm = realm;
        this.factory = switch (realm) {
            case "ryuchi" -> RyuchiShape::new;
            case "shikkotsu" -> ShikkotsuShape::new;
            default -> MyobokuShape::new;
        };
        this.height = factory.get().height;
        this.shape = ThreadLocal.withInitial(factory);
        this.buffer = ThreadLocal.withInitial(() -> new RealmShape.Chunk(height));
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    /** The chunk's blocks, laid down as its terrain. */
    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState random, StructureManager structures,
                                                        ChunkAccess chunk) {
        RealmShape.Chunk c = buffer.get();
        shape.get().fill(chunk.getPos().x, chunk.getPos().z, c);
        BlockState[] palette = RealmFeature.states();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int minY = Math.max(0, chunk.getMinBuildHeight()), maxY = Math.min(c.height, chunk.getMaxBuildHeight());
        byte[] b = c.blocks;
        for (int y = minY; y < maxY; y++) {
            for (int z = 0; z < 16; z++) {
                for (int x = 0; x < 16; x++) {
                    int id = b[((y << 4) | z) << 4 | x] & 0xFF;
                    if (id == 0 || id >= palette.length) continue;
                    chunk.setBlockState(m.set(c.x0 + x, y, c.z0 + z), palette[id], false);
                }
            }
        }
        return CompletableFuture.completedFuture(chunk);
    }

    /** The column at (x, z), as block states bottom to top. */
    private BlockState[] column(int x, int z) {
        RealmShape.Chunk c = buffer.get();
        shape.get().fill(x >> 4, z >> 4, c);
        BlockState[] palette = RealmFeature.states();
        BlockState[] out = new BlockState[height];
        for (int y = 0; y < height; y++) {
            int id = c.get(x, y, z);
            out[y] = id == 0 || id >= palette.length ? Blocks.AIR.defaultBlockState() : palette[id];
        }
        return out;
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState random) {
        BlockState[] col = column(x, z);
        for (int y = col.length - 1; y >= 0; y--) {
            if (type.isOpaque().test(col[y])) return y + 1;
        }
        return level.getMinBuildHeight();
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
        return new NoiseColumn(0, column(x, z));
    }

    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState random, BiomeManager biomes, StructureManager structures,
                             ChunkAccess chunk, GenerationStep.Carving step) {
    }

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager structures, RandomState random, ChunkAccess chunk) {
    }

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {
    }

    @Override
    public int getGenDepth() {
        return height;
    }

    @Override
    public int getSeaLevel() {
        return 61;
    }

    @Override
    public int getMinY() {
        return 0;
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) {
        info.add("Sage realm: " + realm);
    }
}
