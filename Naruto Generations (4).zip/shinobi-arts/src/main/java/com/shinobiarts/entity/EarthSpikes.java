package com.shinobiarts.entity;

import com.shinobiarts.registry.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * One cluster of Rising Spikes (the Earth Flow Spike Cluster model): bursts out of the ground, stands for two seconds,
 * then sinks back. Purely for show (Rising Spikes does its damage when cast); can't be hit or pushed, never saved.
 */
public class EarthSpikes extends Entity {
    public static final int RISE = 4, STAND = 40, SINK = 6;
    private static final EntityDataAccessor<Float> SCALE = SynchedEntityData.defineId(EarthSpikes.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> DELAY = SynchedEntityData.defineId(EarthSpikes.class, EntityDataSerializers.INT);

    public EarthSpikes(EntityType<? extends EarthSpikes> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    /** A cluster at {@code pos} (its base on the ground), turned {@code yaw}, {@code scale} times the model's size. */
    public static void spawn(ServerLevel level, Vec3 pos, float yaw, float scale, int delay) {
        EarthSpikes spikes = new EarthSpikes(ModEntities.EARTH_SPIKES.get(), level);
        spikes.setPos(pos.x, pos.y, pos.z);
        spikes.setYRot(yaw);
        spikes.yRotO = yaw;
        spikes.entityData.set(SCALE, scale);
        spikes.entityData.set(DELAY, delay);
        level.addFreshEntity(spikes);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(SCALE, 1f);
        this.entityData.define(DELAY, 0);
    }

    public float getScale() {
        return this.entityData.get(SCALE);
    }

    public int getDelay() {
        return this.entityData.get(DELAY);
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount > getDelay() + RISE + STAND + SINK + 2) discard();
    }

    /** Drawn whenever any of the spikes could be on screen, not just the base. */
    @Override
    public AABB getBoundingBoxForCulling() {
        float s = getScale();
        return new AABB(getX() - 1.1 * s, getY() - 0.1, getZ() - 1.1 * s, getX() + 1.1 * s, getY() + 2.0 * s, getZ() + 1.1 * s);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
