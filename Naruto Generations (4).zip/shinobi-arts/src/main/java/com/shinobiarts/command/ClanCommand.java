package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.shinobiarts.Config;
import com.shinobiarts.event.CommonEvents;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;

/**
 * /clan              your clan, its rarity and bonuses
 * /clan list         every clan by rarity, with its chance (click one for its bonuses)
 * /clan info &lt;clan&gt;  any clan's rarity and bonuses
 * /clanroll          rolls a new clan (a few uses per player: "clanRolls" in the config)
 * /clanroll claim    locks the current clan in for good
 */
public final class ClanCommand {
    private static final SuggestionProvider<CommandSourceStack> CLANS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(Clan.values()).filter(c -> c != Clan.NONE).map(Clan::id), builder);

    /** The clans a player has rolled (the ones /clanroll claim can keep). */
    private static final SuggestionProvider<CommandSourceStack> ROLLED = (ctx, builder) -> {
        ServerPlayer p = ctx.getSource().getPlayer();
        NinjaData d = p == null ? null : NinjaData.get(p);
        return SharedSuggestionProvider.suggest(d == null ? java.util.stream.Stream.empty() : d.rolledClanChoices().stream().map(Clan::id), builder);
    };

    private ClanCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("clan")
                .executes(ClanCommand::mine)
                .then(Commands.literal("list").executes(ClanCommand::list))
                .then(Commands.literal("info")
                        .then(Commands.argument("clan", StringArgumentType.word()).suggests(CLANS)
                                .executes(ctx -> {
                                    Clan clan = Clan.byId(StringArgumentType.getString(ctx, "clan").toLowerCase(java.util.Locale.ROOT));
                                    if (clan == null || clan == Clan.NONE) {
                                        ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.unknown_clan"));
                                        return 0;
                                    }
                                    show(ctx.getSource(), clan, "message.shinobiarts.clan_info");
                                    return 1;
                                }))));
        dispatcher.register(Commands.literal("clanroll")
                .executes(ClanCommand::roll)
                .then(Commands.literal("claim").executes(ctx -> claim(ctx, null))
                        .then(Commands.argument("clan", StringArgumentType.word()).suggests(ROLLED)
                                .executes(ctx -> claim(ctx, StringArgumentType.getString(ctx, "clan").toLowerCase(java.util.Locale.ROOT))))));
    }

    /** /clanroll: rolls a new clan, unless the player claimed theirs or used every roll. */
    private static int roll(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (d.isClanClaimed()) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_claimed"));
            return 0;
        }
        int max = Config.i(Config.CLAN_ROLLS);
        if (d.getClanRolls() >= max) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_none_left"));
            return 0;
        }
        Clan clan = Clan.random(player.getRandom());
        if (d.rolledClanChoices().isEmpty() && d.getClan() != Clan.NONE) d.addRolledClan(d.getClan()); // older saves
        d.setClanRolls(d.getClanRolls() + 1);
        d.addRolledClan(clan);
        d.applyRolledClan(clan);
        PlayerDataManager.applyStatEffects(player);
        ModNetwork.sync(player);
        SharinganManager.broadcastEyes(player);
        CommonEvents.announceClan(player, d, true);

        int left = max - d.getClanRolls();
        if (left > 0) {
            MutableComponent line = Component.translatable("message.shinobiarts.clanroll_left", left).withStyle(ChatFormatting.YELLOW)
                    .append(button("message.shinobiarts.clanroll_claim_button", "/clanroll claim", ChatFormatting.GREEN))
                    .append(" ")
                    .append(button("message.shinobiarts.clanroll_again_button", "/clanroll", ChatFormatting.AQUA));
            player.sendSystemMessage(line);
        } else if (d.rolledClanChoices().size() <= 1) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_last", clan.displayName()).withStyle(ChatFormatting.YELLOW));
        } else {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_pick").withStyle(ChatFormatting.YELLOW));
        }
        // every clan rolled so far, each a button that claims it
        if (d.rolledClanChoices().size() > 1) player.sendSystemMessage(choices(d));
        if (!d.availableDojutsu().isEmpty()) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.dojutsu",
                    d.dojutsuName(d.availableDojutsu().get(0))).withStyle(ChatFormatting.GOLD));
        }
        return 1;
    }

    /**
     * /clanroll claim [clan]: keeps a clan for good: the current one, or any clan this player rolled before (they don't
     * have to keep their last roll).
     */
    private static int claim(CommandContext<CommandSourceStack> ctx, @javax.annotation.Nullable String id) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (d.isClanClaimed() || (d.isClanFinal() && id != null && !id.equals(d.getClan().id()))) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_claimed"));
            return 0;
        }
        if (d.getClan() == Clan.NONE) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_claim_first"));
            return 0;
        }
        if (id != null && !id.equals(d.getClan().id())) {
            Clan chosen = Clan.byId(id);
            if (chosen == null || !d.rolledClanChoices().contains(chosen)) {
                ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_not_rolled"));
                return 0;
            }
            d.applyRolledClan(chosen);                        // born-with eyes and affinity follow the clan
            PlayerDataManager.applyStatEffects(player);
            SharinganManager.broadcastEyes(player);
        }
        d.setClanClaimed(true);
        com.shinobiarts.ninja.ChakraPoints.rollMedical(player, d, true);
        ModNetwork.sync(player);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_claim_done", d.getClan().displayName())
                .withStyle(ChatFormatting.GREEN));
        player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_nature", com.shinobiarts.ninja.ChakraPoints.natureLine(d))
                .withStyle(ChatFormatting.GRAY));
        return 1;
    }

    /** "Your clans: [Nara] [Uchiha]": each one a button that claims it (the current one marked). */
    private static MutableComponent choices(NinjaData d) {
        MutableComponent line = Component.translatable("message.shinobiarts.clanroll_choices").withStyle(ChatFormatting.GOLD);
        for (Clan c : d.rolledClanChoices()) {
            line.append(" ");
            MutableComponent name = Component.literal("[").append(c.displayName()).append("]");
            if (c == d.getClan()) name.append(Component.literal("*").withStyle(ChatFormatting.WHITE));
            line.append(name.withStyle(Style.EMPTY.withColor(c.color()).withBold(true)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/clanroll claim " + c.id()))
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                            Component.translatable("message.shinobiarts.clanroll_claim_hover", c.displayName())))));
        }
        return line;
    }

    /** A clickable chat button that runs a command. */
    public static MutableComponent button(String key, String command, ChatFormatting color) {
        return Component.translatable(key).withStyle(Style.EMPTY.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(command))));
    }

    private static int mine(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (d.getClan() == Clan.NONE) {
            ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.clan_none").withStyle(ChatFormatting.YELLOW), false);
            return 1;
        }
        show(ctx.getSource(), d.getClan(), "message.shinobiarts.clan_yours");
        return 1;
    }

    private static void show(CommandSourceStack source, Clan clan, String headerKey) {
        MutableComponent msg = Component.translatable(headerKey, clan.displayName(), clan.rarityText()).withStyle(ChatFormatting.GOLD);
        for (Component line : clan.describe()) msg.append(Component.literal("\n - ").withStyle(ChatFormatting.DARK_GRAY)).append(line);
        source.sendSuccess(() -> msg, false);
    }

    /** One line per rarity tier, rarest first; each clan name runs /clan info when clicked. */
    private static int list(CommandContext<CommandSourceStack> ctx) {
        MutableComponent msg = Component.translatable("message.shinobiarts.clan_list").withStyle(ChatFormatting.GOLD);
        Clan.Rarity[] tiers = Clan.Rarity.values();
        for (int t = tiers.length - 1; t >= 0; t--) {
            Clan.Rarity tier = tiers[t];
            if (tier == Clan.Rarity.CLANLESS) continue;
            MutableComponent line = Component.literal("\n").append(tier.displayName()).append(Component.literal(": ").withStyle(ChatFormatting.GRAY));
            boolean first = true;
            double each = 0;
            for (Clan clan : Clan.values()) {
                if (clan.rarity() != tier) continue;
                if (!first) line.append(Component.literal(", ").withStyle(ChatFormatting.GRAY));
                first = false;
                each = clan.chance();
                line.append(clan.displayName().withStyle(Style.EMPTY.withColor(clan.color())
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/clan info " + clan.id()))
                        .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.translatable("message.shinobiarts.clan_click")))));
            }
            line.append(Component.translatable("message.shinobiarts.clan_each", Clan.formatChance(each)).withStyle(ChatFormatting.DARK_GRAY));
            msg.append(line);
        }
        ctx.getSource().sendSuccess(() -> msg, false);
        return 1;
    }
}
