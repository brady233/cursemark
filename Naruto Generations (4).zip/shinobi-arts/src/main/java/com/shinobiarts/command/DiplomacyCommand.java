package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.shinobiarts.village.Diplomacy;
import com.shinobiarts.village.Villages;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * Operators decide what Kages propose: /diplomacy pending lists the requests, /diplomacy accept|deny &lt;id&gt; settles
 * one. /diplomacy (anyone) shows every alliance and war.
 */
public final class DiplomacyCommand {
    private DiplomacyCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("diplomacy")
                .executes(ctx -> overview(ctx.getSource()))
                .then(Commands.literal("pending").requires(s -> s.hasPermission(2)).executes(ctx -> pending(ctx.getSource())))
                .then(Commands.literal("accept").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", IntegerArgumentType.integer(1))
                                .executes(ctx -> decide(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "id"), true))))
                .then(Commands.literal("deny").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", IntegerArgumentType.integer(1))
                                .executes(ctx -> decide(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "id"), false)))));
    }

    private static int overview(CommandSourceStack source) {
        Diplomacy dip = Diplomacy.get(source.getServer());
        List<Villages.Village> all = Villages.all();
        int shown = 0;
        source.sendSuccess(() -> Component.translatable("message.shinobiarts.diplomacy_title").withStyle(ChatFormatting.GOLD), false);
        for (int i = 0; i < all.size(); i++) {
            for (int j = i + 1; j < all.size(); j++) {
                Diplomacy.Relation r = dip.relation(all.get(i).id(), all.get(j).id());
                if (r == Diplomacy.Relation.NEUTRAL) continue;
                String a = all.get(i).name(), b = all.get(j).name();
                source.sendSuccess(() -> Component.translatable("message.shinobiarts.diplomacy_line_" + r.name().toLowerCase(java.util.Locale.ROOT), a, b)
                        .withStyle(r == Diplomacy.Relation.WAR ? ChatFormatting.RED : ChatFormatting.GREEN), false);
                shown++;
            }
        }
        if (shown == 0) source.sendSuccess(() -> Component.translatable("message.shinobiarts.diplomacy_none").withStyle(ChatFormatting.GRAY), false);
        return shown;
    }

    private static int pending(CommandSourceStack source) {
        List<Diplomacy.Request> list = Diplomacy.get(source.getServer()).pending();
        if (list.isEmpty()) {
            source.sendSuccess(() -> Component.translatable("message.shinobiarts.diplomacy_no_pending").withStyle(ChatFormatting.GRAY), false);
            return 0;
        }
        for (Diplomacy.Request r : list) {
            source.sendSuccess(() -> Component.translatable("message.shinobiarts.diplomacy_op_notice", r.id, Villages.name(r.from),
                    r.kind.displayName(), Villages.name(r.to), r.by).withStyle(ChatFormatting.YELLOW), false);
        }
        return list.size();
    }

    private static int decide(CommandSourceStack source, int id, boolean accept) {
        if (!Diplomacy.decide(source.getServer(), id, accept)) {
            source.sendFailure(Component.translatable("message.shinobiarts.diplomacy_no_request", id));
            return 0;
        }
        source.sendSuccess(() -> Component.translatable(accept ? "message.shinobiarts.diplomacy_op_accepted" : "message.shinobiarts.diplomacy_op_denied", id), true);
        return 1;
    }
}
