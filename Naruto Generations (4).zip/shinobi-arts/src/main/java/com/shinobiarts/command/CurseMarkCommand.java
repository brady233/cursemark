package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.shinobiarts.ninja.CurseMark;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Operators: /cursemark give &lt;player&gt; [level 1|2] (the Heaven curse mark), /cursemark remove &lt;player&gt;,
 * /cursemark info &lt;player&gt;.
 */
public final class CurseMarkCommand {
    private CurseMarkCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("cursemark").requires(s -> s.hasPermission(2))
                .then(Commands.literal("give").then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> give(ctx, 1))
                        .then(Commands.argument("level", IntegerArgumentType.integer(1, 2))
                                .executes(ctx -> give(ctx, IntegerArgumentType.getInteger(ctx, "level"))))))
                .then(Commands.literal("remove").then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> {
                            ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                            CurseMark.remove(p);
                            ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.curse_cmd_removed", p.getDisplayName()), true);
                            return 1;
                        })))
                .then(Commands.literal("info").then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> {
                            ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                            NinjaData d = NinjaData.get(p);
                            if (d == null || d.curseType == CurseMark.NONE) {
                                ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.curse_cmd_none", p.getDisplayName()), false);
                                return 0;
                            }
                            ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.curse_cmd_info", p.getDisplayName(),
                                    d.curseLevel, d.curseStage, d.curseStrain, CurseMark.MAX_STRAIN, d.curseMastery), false);
                            return 1;
                        }))));
    }

    private static int give(CommandContext<CommandSourceStack> ctx, int level) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
        CurseMark.give(p, CurseMark.HEAVEN, level);
        ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.curse_cmd_given", p.getDisplayName(), level), true);
        return 1;
    }
}
