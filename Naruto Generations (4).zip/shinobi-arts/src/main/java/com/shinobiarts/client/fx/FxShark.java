package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Shark Jaw (entityA = the one bitten, entityB = the biter, size = how big): a huge jaw of blue chakra, upper and lower,
 * lined with white teeth, opens wide around the target, snaps shut, holds, and fades as they're flung.
 */
final class FxShark {
    private FxShark() {}

    static void jaw(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Entity biter = c.fx().entityB();
        float age = c.age();
        float s = c.fx().size;
        Vec3 mid = e.getPosition(c.partial()).add(0, e.getBbHeight() * 0.55, 0);
        Vec3 fwd = biter == null ? new Vec3(0, 0, 1) : mid.subtract(biter.getEyePosition(c.partial()));
        fwd = new Vec3(fwd.x, 0, fwd.z);
        fwd = fwd.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : fwd.normalize();
        Vec3 side = new Vec3(-fwd.z, 0, fwd.x);
        // open over the first 6 ticks, snap shut by tick 9, hold, fade from tick 38
        float open = age < 6 ? FxDraw.smooth(age / 6f) : age < 9 ? 1f - FxDraw.smooth((age - 6) / 3f) : 0.04f;
        float fade = 1f - Mth.clamp((age - 38f) / 8f, 0f, 1f);
        if (fade <= 0) return;
        float gape = (0.15f + 1.15f * open) * s;
        float R = 1.5f * s;
        Vec3 hinge = mid.subtract(fwd.scale(R * 0.85));
        VertexConsumer glow = FxDraw.glow(c.buffers());
        FxDraw.Paint gum = FxDraw.color(0x2E6FB0, 0.55f * fade), tooth = FxDraw.color(0xF4F8FF, 0.95f * fade);
        for (int jaw = -1; jaw <= 1; jaw += 2) {
            // each jaw: a curved band (the gum line) from hinge round the front, with a row of triangular teeth
            int n = 16;
            Vec3 prev = null;
            for (int i = 0; i <= n; i++) {
                float u = i / (float) n;
                double a = (u - 0.5) * Math.PI;                       // left end .. front .. right end
                Vec3 p = hinge.add(fwd.scale(Math.cos(a) * R * 1.6)).add(side.scale(Math.sin(a) * R))
                        .add(0, jaw * gape * Math.cos(a * 0.6) * 0.9, 0);
                if (prev != null) {
                    Vec3 lip = new Vec3(0, jaw * 0.25 * s, 0);
                    FxDraw.quad(glow, c.ps(), prev, p, p.add(lip), prev.add(lip), gum, FxDraw.FULL);
                    // a tooth between prev and p, pointing at the other jaw
                    Vec3 base0 = prev, base1 = p, tip = prev.lerp(p, 0.5).add(0, -jaw * (0.42 * s), 0).add(fwd.scale(-0.05));
                    FxDraw.quad(glow, c.ps(), base0, base1, tip, tip, tooth, FxDraw.FULL);
                }
                prev = p;
            }
        }
        // the bite: a flash of spray when the jaws meet
        if (age >= 8 && age < 14) {
            float f = 1f - (age - 8) / 6f;
            FxDraw.billboard(FxDraw.additive(c.buffers()), c.ps(), c.camera(), mid, 2.4f * s * f + 0.2f, 2.4f * s * f + 0.2f, 0,
                    FxDraw.addColor(0x9CD8FF, 0.6f * f), FxDraw.FULL);
        }
    }
}
