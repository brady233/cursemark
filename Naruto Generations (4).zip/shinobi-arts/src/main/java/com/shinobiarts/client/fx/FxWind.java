package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Wind Release: a palm-blast of spiralling gusts (Gale Palm), a crescent blade of compressed air flying out (Vacuum
 * Blade), and a huge rolling gale (Great Breakthrough). The air is drawn as pale streaks and wavefronts.
 */
final class FxWind {
    private FxWind() {}

    /** Gale Palm: five gusts spiral forward out of the palms in a widening cone, with rings of pushed air. */
    static void galePalm(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 dir = b.subtract(a);
        double len = dir.length();
        if (len < 1e-3) return;
        dir = dir.normalize();
        Vec3 n = FxDraw.perpendicular(dir), m = dir.cross(n);
        float age = c.age();
        float front = (float) (len * FxDraw.smooth(age / 6f));
        float fade = 1f - Mth.clamp((age - 6f) / 6f, 0f, 1f);
        VertexConsumer vc = FxDraw.glow(c.buffers());
        for (int k = 0; k < 5; k++) {
            List<Vec3> pts = new ArrayList<>();
            float back = Math.max(0, front - 4.5f);
            for (int i = 0; i <= 18; i++) {
                float t = back + (front - back) * i / 18f;
                float r = 0.25f + t * 0.2f;
                float ang = k * Mth.TWO_PI / 5 + t * 1.3f + age * 0.5f;
                pts.add(a.add(dir.scale(t)).add(n.scale(Mth.cos(ang) * r)).add(m.scale(Mth.sin(ang) * r)));
            }
            FxDraw.ribbon(vc, c.ps(), c.cam(), pts, 0.14f, 0.2f, FxDraw.color(0xF2FAFF, 0f), FxDraw.color(0xDDEEFF, 0.75f * fade), FxDraw.FULL);
        }
        for (int k = 0; k < 3; k++) {
            float d = front - k * 1.8f;
            if (d < 0.5f) continue;
            float r = 0.35f + d * 0.22f;
            FxDraw.ring(vc, c.ps(), a.add(dir.scale(d)), dir, r, 0.12f + d * 0.02f, 24, FxDraw.color(0xFFFFFF, 0.5f * fade * (1 - k * 0.3f)),
                    FxDraw.color(0xCFE6FF, 0f), FxDraw.FULL);
        }
    }

    /** Vacuum Blade: a crescent of compressed air flies straight out, leaving fading after-images. */
    static void vacuumBlade(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 dir = b.subtract(a);
        double len = dir.length();
        if (len < 1e-3) return;
        dir = dir.normalize();
        Vec3 side = dir.cross(new Vec3(0, 1, 0));
        side = side.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : side.normalize();
        Vec3 up = side.cross(dir).normalize();
        float age = c.age();
        float travel = Math.min((float) len, age * 3f);
        float fade = 1f - Mth.clamp((age * 3f - (float) len) / 10f, 0f, 1f);
        VertexConsumer vc = FxDraw.glow(c.buffers());
        for (int ghost = 3; ghost >= 0; ghost--) {
            float d = travel - ghost * 0.9f;
            if (d < 0.3f) continue;
            float alpha = fade * (ghost == 0 ? 0.9f : 0.35f / ghost);
            crescent(vc, c, a.add(dir.scale(d)), dir, side, up, 1.6f, alpha);
        }
    }

    private static void crescent(VertexConsumer vc, FxClient.Ctx c, Vec3 head, Vec3 dir, Vec3 side, Vec3 up, float r, float alpha) {
        int seg = 16;
        Vec3 center = head.subtract(dir.scale(r));
        for (int i = 0; i < seg; i++) {
            float t0 = i / (float) seg, t1 = (i + 1) / (float) seg;
            float a0 = Mth.lerp(t0, -1.15f, 1.15f), a1 = Mth.lerp(t1, -1.15f, 1.15f);
            float th0 = 0.28f * Mth.sin(t0 * Mth.PI), th1 = 0.28f * Mth.sin(t1 * Mth.PI);       // thick in the middle, sharp ends
            Vec3 o0 = dir.scale(Mth.cos(a0)).add(side.scale(Mth.sin(a0))), o1 = dir.scale(Mth.cos(a1)).add(side.scale(Mth.sin(a1)));
            Vec3 p0 = center.add(o0.scale(r)), p1 = center.add(o1.scale(r));
            Vec3 q0 = center.add(o0.scale(r - th0)), q1 = center.add(o1.scale(r - th1));
            FxDraw.quad(vc, c.ps(), q0, p0, p1, q1, FxDraw.color(0xF4FBFF, alpha), FxDraw.FULL);
            // a faint glow above and below the edge
            Vec3 g = up.scale(0.12f);
            FxDraw.quad(vc, c.ps(), p0.add(g), p0.subtract(g), p1.subtract(g), p1.add(g), FxDraw.color(0xBFE0FF, alpha * 0.35f), FxDraw.FULL);
        }
    }

    /** Great Breakthrough: dozens of gusts tear forward in a widening cone behind a rolling wavefront of air. */
    static void breakthrough(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 dir = b.subtract(a);
        double len = dir.length();
        if (len < 1e-3) return;
        dir = dir.normalize();
        Vec3 n = FxDraw.perpendicular(dir), m = dir.cross(n);
        float age = c.age();
        float fade = 1f - Mth.clamp((age - 9f) / 7f, 0f, 1f);
        VertexConsumer vc = FxDraw.glow(c.buffers());
        RandomSource r = FxDraw.rng(c.fx().seed, 1);
        double spread = Math.tan(Math.toRadians(38));
        for (int k = 0; k < 30; k++) {
            float delay = r.nextFloat() * 4f, speed = 1.4f + r.nextFloat() * 0.6f, streak = 2.5f + r.nextFloat() * 2.5f;
            float ox = (float) r.nextGaussian() * 0.5f, oy = (float) r.nextGaussian() * 0.5f;
            float head = (age - delay) * speed;
            if (head <= 0) continue;
            head = Math.min(head, (float) len + 2);
            float tail = Math.max(0, head - streak);
            List<Vec3> pts = new ArrayList<>();
            for (int i = 0; i <= 8; i++) {
                float t = tail + (head - tail) * i / 8f;
                double w = t * spread;
                pts.add(a.add(dir.scale(t)).add(n.scale(ox * w)).add(m.scale(oy * w * 0.7)));
            }
            FxDraw.ribbon(vc, c.ps(), c.cam(), pts, 0.18f + head * 0.012f, 0f, FxDraw.color(0xFFFFFF, 0f), FxDraw.color(0xE6F2FF, 0.6f * fade), FxDraw.FULL);
        }
        float wave = Math.min((float) len, age * 1.6f);
        if (wave > 1f) {
            float rad = (float) (wave * spread);
            FxDraw.ring(vc, c.ps(), a.add(dir.scale(wave)), dir, rad * 0.7f, rad * 0.9f, 32, FxDraw.color(0xFFFFFF, 0f),
                    FxDraw.color(0xDDEEFF, 0.28f * fade), FxDraw.FULL);
        }
    }
}
