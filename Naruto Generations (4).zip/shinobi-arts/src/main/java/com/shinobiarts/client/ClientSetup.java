package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    /** The switched-on eye in the dojutsu slot picks its picture (stage, pattern or Byakugan) from its "Eye" tag. */
    @SubscribeEvent
    public static void clientSetup(net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent event) {
        event.enqueueWork(() -> net.minecraft.client.renderer.item.ItemProperties.register(
                com.shinobiarts.registry.ModItems.ACTIVE_EYE.get(), ShinobiArts.id("eye"),
                (stack, level, entity, seed) -> com.shinobiarts.item.ActiveEyeItem.variant(stack) / 10f + 0.05f));
        // the forehead protector's icon shows the village on its plate
        event.enqueueWork(() -> net.minecraft.client.renderer.item.ItemProperties.register(
                com.shinobiarts.registry.ModItems.FOREHEAD_PROTECTOR.get(), ShinobiArts.id("village"),
                (stack, level, entity, seed) -> HeadbandLayer.iconValue(com.shinobiarts.item.ForeheadProtectorItem.village(stack))));
        // the Gunbai switches to its raised model while you guard with it
        event.enqueueWork(() -> net.minecraft.client.renderer.item.ItemProperties.register(
                com.shinobiarts.registry.ModItems.GUNBAI.get(), ShinobiArts.id("guarding"),
                (stack, level, entity, seed) -> entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1f : 0f));
        // you can't target your own Susanoo (you stand inside it)
        com.shinobiarts.entity.SusanooEntity.isLocalPlayer = id -> {
            net.minecraft.client.player.LocalPlayer p = net.minecraft.client.Minecraft.getInstance().player;
            return p != null && p.getId() == id;
        };
        // eye tooltips name the keys the player actually has bound
        com.shinobiarts.ninja.EyeTechniques.keyName = id -> switch (id) {
            case "jutsu_1" -> KeyBinds.JUTSU_1.getTranslatedKeyMessage();
            case "jutsu_2" -> KeyBinds.JUTSU_2.getTranslatedKeyMessage();
            case "jutsu_3" -> KeyBinds.JUTSU_3.getTranslatedKeyMessage();
            case "dojutsu" -> KeyBinds.DOJUTSU.getTranslatedKeyMessage();
            case "byakugan" -> KeyBinds.BYAKUGAN.getTranslatedKeyMessage();
            case "susanoo" -> KeyBinds.SUSANOO.getTranslatedKeyMessage();
            case "sneak" -> net.minecraft.client.Minecraft.getInstance().options.keyShift.getTranslatedKeyMessage();
            default -> net.minecraft.network.chat.Component.literal(id);
        };
    }

    /** The forehead protector's band takes its dye colour (layer 0); the plate (layer 1) isn't tinted. */
    @SubscribeEvent
    public static void itemColors(net.minecraftforge.client.event.RegisterColorHandlersEvent.Item event) {
        event.register((stack, tint) -> tint == 0 && stack.getItem() instanceof com.shinobiarts.item.ForeheadProtectorItem item
                ? item.getColor(stack) : -1, com.shinobiarts.registry.ModItems.FOREHEAD_PROTECTOR.get());
    }

    /** The Susanoo models are read when first drawn; a resource reload drops them so packs can replace them. */
    @SubscribeEvent
    public static void reloadListeners(net.minecraftforge.client.event.RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener) rm -> SusanooModel.clear());
        event.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener) rm -> JutsuMesh.clear());
    }

    /** The models drawn in the off hand for dual-wield weapons aren't any item's own model, so they're baked here. */
    @SubscribeEvent
    public static void registerModels(net.minecraftforge.client.event.ModelEvent.RegisterAdditional event) {
        event.register(DualWieldRender.modelId("kiba"));
        event.register(DualWieldRender.modelId("kabutowari_hammer"));
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        for (KeyMapping key : KeyBinds.ALL) event.register(key);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "shinobi_hud", ShinobiHud.OVERLAY);
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "combat_tag", CombatHud.OVERLAY);
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "team", TeamHud.OVERLAY);
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "jutsu_charge", ChargeHud.OVERLAY);
        event.registerAbove(VanillaGuiOverlay.BOSS_EVENT_PROGRESS.id(), "susanoo", SusanooHud.OVERLAY);
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "jinchuriki", JinchurikiHud.OVERLAY);
        event.registerAboveAll("eye_effects", EyeEffectsHud.OVERLAY);
        event.registerAboveAll("sharingan_flash", SharinganFlash.OVERLAY);
    }

    /** Sharingan eyes on players' faces while their Sharingan is on. */
    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new SharinganEyesLayer<>(renderer, event.getEntityModels()));
        }
        // Forehead protectors: the band round the head and the plate with the village on it.
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new HeadbandLayer<>(renderer));
        }
        // The Rasengan on the fist, and dual-wield weapons' second half in the empty off hand.
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) {
                renderer.addLayer(new RasenganLayer(renderer));
                renderer.addLayer(new OffhandWeaponLayer(renderer));
            }
        }
        // Lightning Armor's crackling glow, on anyone who has it up.
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new LightningArmorLayer<>(renderer, event.getEntityModels()));
        }
        // Jutsu that change the body: Rock Armor, Dance of the Willow, Vitality Surge's seal marks.
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) {
                renderer.addLayer(new BodyJutsuLayers.RockLayer(renderer, event.getEntityModels()));
                renderer.addLayer(new BodyJutsuLayers.BoneLayer(renderer));
                renderer.addLayer(new BodyJutsuLayers.SealLayer(renderer, event.getEntityModels()));
            }
        }
        // A jinchuriki's tailed beast chakra: the rage shrouds and the chakra cloak, with tails, ears or horns.
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new JinchurikiLayer<>(renderer, event.getEntityModels()));
        }
        // The Eight Gates: the aura in each gate's colour, flushed skin and veins.
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new GatesLayer(renderer, event.getEntityModels()));
        }
        // The Hoshigaki shark form: grey-blue shark skin, fins, claws and a tail.
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new SharkLayer(renderer));
            if (renderer != null) renderer.addLayer(new ScalpelLayer(renderer));
            if (renderer != null) renderer.addLayer(new CurseMarkLayer(renderer, event.getEntityModels()));
        }
    }

    /** The eyes' model: just the head, sitting right over the skin's hat layer, so the eyes hug the face. */
    public static final ModelLayerLocation SHARINGAN_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "sharingan"), "main");
    /** Lightning Armor's shell: the body, a little bigger than the skin's outer layer. */
    public static final ModelLayerLocation LIGHTNING_ARMOR_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "lightning_armor"), "main");
    /** The Eight Gates' aura: the body, a good deal bigger than the skin, so it glows around it. */
    /** The Eight Gates' veins, raised off the skin: the same vein pattern on three shells a little apart, so they stand out in 3D. */
    public static final ModelLayerLocation[] GATES_VEIN_LAYERS = {
            new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "gates_veins_0"), "main"),
            new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "gates_veins_1"), "main"),
            new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "gates_veins_2"), "main")};
    public static final ModelLayerLocation GATES_AURA_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "gates_aura"), "main");
    /** Rock Armor's stone shell: the body, a little bigger than the skin. */
    public static final ModelLayerLocation ROCK_ARMOR_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "rock_armor"), "main");
    /** Vitality Surge's seal marks: the player's own shape, a hair bigger, with the skin's texture layout. */
    /** Edo Tensei's cracks: a player body just outside a skin's outer layer, so the cracks show over clothes and all. */
    public static final ModelLayerLocation EDO_CRACKS_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "edo_cracks"), "main");
    public static final ModelLayerLocation EDO_CRACKS_SLIM_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "edo_cracks_slim"), "main");
    /** The curse mark: a body just outside a skin's outer layer (so the marks show over clothes), wide and slim; and its Level 2 form. */
    public static final ModelLayerLocation CURSE_MARKS_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "curse_marks"), "main");
    public static final ModelLayerLocation CURSE_MARKS_SLIM_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "curse_marks_slim"), "main");
    public static final ModelLayerLocation CURSE_FORM_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "curse_form"), "main");
    public static final ModelLayerLocation SEAL_MARKS_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "seal_marks"), "main");

    /** The Kamui dimension's look: no sky at all, just the pale haze it's lit by (see ninja/KamuiDimension). */
    @SubscribeEvent
    public static void registerDimensionEffects(net.minecraftforge.client.event.RegisterDimensionSpecialEffectsEvent event) {
        event.register(new ResourceLocation(ShinobiArts.MODID, "kamui"), new KamuiSky());
        event.register(new ResourceLocation(ShinobiArts.MODID, "mist"), new MistSky());
    }

    /** A jinchuriki's shroud: a hugging layer and a bigger one the chakra boils off. */
    public static final ModelLayerLocation SHROUD_INNER_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "shroud_inner"), "main");
    public static final ModelLayerLocation SHROUD_OUTER_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "shroud_outer"), "main");

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(SHARINGAN_LAYER, () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(0.6F), 0.0F), 64, 32));
        event.registerLayerDefinition(LIGHTNING_ARMOR_LAYER, () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(0.45F), 0.0F), 64, 32));
        for (int i = 0; i < GATES_VEIN_LAYERS.length; i++) {
            float lift = 0.05f + 0.06f * i;
            event.registerLayerDefinition(GATES_VEIN_LAYERS[i], () -> LayerDefinition.create(
                    net.minecraft.client.model.PlayerModel.createMesh(new CubeDeformation(lift), false), 64, 64));
        }
        event.registerLayerDefinition(GATES_AURA_LAYER, () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(0.85F), 0.0F), 64, 32));
        event.registerLayerDefinition(SHROUD_INNER_LAYER, () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(0.7F), 0.0F), 64, 32));
        event.registerLayerDefinition(SHROUD_OUTER_LAYER, () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(1.25F), 0.0F), 64, 32));
        event.registerLayerDefinition(ROCK_ARMOR_LAYER, () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(0.62F), 0.0F), 64, 32));
        event.registerLayerDefinition(EDO_CRACKS_LAYER, () -> LayerDefinition.create(
                net.minecraft.client.model.PlayerModel.createMesh(new CubeDeformation(0.3F), false), 64, 64));
        event.registerLayerDefinition(EDO_CRACKS_SLIM_LAYER, () -> LayerDefinition.create(
                net.minecraft.client.model.PlayerModel.createMesh(new CubeDeformation(0.3F), true), 64, 64));
        event.registerLayerDefinition(CURSE_MARKS_LAYER, () -> LayerDefinition.create(
                net.minecraft.client.model.PlayerModel.createMesh(new CubeDeformation(0.28F), false), 64, 64));
        event.registerLayerDefinition(CURSE_MARKS_SLIM_LAYER, () -> LayerDefinition.create(
                net.minecraft.client.model.PlayerModel.createMesh(new CubeDeformation(0.28F), true), 64, 64));
        event.registerLayerDefinition(CURSE_FORM_LAYER, CurseFormModel::createLayer);
        event.registerLayerDefinition(SEAL_MARKS_LAYER, () -> LayerDefinition.create(
                net.minecraft.client.model.PlayerModel.createMesh(new CubeDeformation(0.03F), false), 64, 64));
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.JUTSU_PROJECTILE.get(), JutsuProjectileRenderer::new);
        event.registerEntityRenderer(ModEntities.SUSANOO.get(), SusanooRenderer::new);
        event.registerEntityRenderer(ModEntities.SUBSTITUTION_LOG.get(), SubstitutionLogRenderer::new);
        event.registerEntityRenderer(ModEntities.EARTH_SPIKES.get(), EarthSpikesRenderer::new);
        event.registerEntityRenderer(ModEntities.MAJESTIC_FLAME.get(), MajesticFlameRenderer::new);
        event.registerEntityRenderer(ModEntities.THROWN_TOOL.get(), ThrownToolRenderer::new);
        event.registerEntityRenderer(ModEntities.FTG_KUNAI.get(), FtgKunaiRenderer::new);
        event.registerEntityRenderer(ModEntities.EXPLOSIVE_KUNAI.get(), NinjaToolRenderers.ExplosiveKunai::new);
        event.registerEntityRenderer(ModEntities.SMOKE_BOMB.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.WIRE_TRAP.get(), NinjaToolRenderers.Wire::new);
        event.registerEntityRenderer(ModEntities.EXPLOSIVE_TAG.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.SHADOW_CLONE.get(), ShadowCloneRenderer::new);
        event.registerEntityRenderer(ModEntities.EDO_TENSEI.get(), EdoTenseiRenderer::new);
        event.registerEntityRenderer(ModEntities.NINJA_BANDIT.get(), NinjaBanditRenderer::new);
    }
}
