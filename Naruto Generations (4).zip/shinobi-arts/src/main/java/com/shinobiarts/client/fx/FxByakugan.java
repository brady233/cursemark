package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.JutsuMesh;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * The Hyuga's Byakugan techniques, drawn the way they look in the show: palms of pale blue chakra (the chakra_palm
 * model), the Eight Trigrams field on the ground, Palm Rotation's spinning dome, Air Palm's pressure wave and the
 * Byakugan's sight spreading out.
 */
final class FxByakugan {
    private FxByakugan() {}

    static final int CHAKRA = 0x9ED4FF, CORE = 0xE8F6FF, SIGHT = 0xC8B8F0;
    private static final ResourceLocation TRIGRAMS = new ResourceLocation(ShinobiArts.MODID, "textures/entity/byakugan/trigrams.png");
    private static final ResourceLocation SWIRL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/byakugan/swirl.png");

    // ---------------------------------------------------------------- a palm of chakra

    /**
     * A chakra palm at {@code at}, its palm facing {@code dir}, fingers toward {@code up}, {@code size} blocks tall:
     * a glowing see-through hand with a soft halo round it.
     */
    static void palm(FxClient.Ctx c, Vec3 at, Vec3 dir, Vec3 up, float size, float alpha) {
        if (alpha <= 0.01f) return;
        List<JutsuMesh.Group> mesh = JutsuMesh.get("chakra_palm");
        if (mesh.isEmpty()) return;
        Vec3 z = dir.normalize();
        Vec3 x = up.cross(z);
        if (x.lengthSqr() < 1e-6) x = FxDraw.perpendicular(z);
        x = x.normalize();
        Vec3 y = z.cross(x).normalize();
        PoseStack ps = c.ps();
        ps.pushPose();
        ps.translate(at.x, at.y, at.z);
        Matrix4f basis = new Matrix4f((float) x.x, (float) x.y, (float) x.z, 0, (float) y.x, (float) y.y, (float) y.z, 0,
                (float) z.x, (float) z.y, (float) z.z, 0, 0, 0, 0, 1);
        ps.last().pose().mul(basis);
        ps.last().normal().mul(new Matrix3f(basis));
        ps.translate(0, -size * 0.35f, 0);                  // so the hand is centred on the spot, not its wrist
        ps.scale(size, size, size);
        float[] col = rgb(CHAKRA), core = rgb(CORE);
        VertexConsumer body = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(FxDraw.WHITE));
        for (JutsuMesh.Group g : mesh) {
            JutsuMesh.draw(g, ps.last(), body, core[0], core[1], core[2], 0.55f * alpha, FxDraw.FULL, OverlayTexture.NO_OVERLAY);
        }
        ps.scale(1.18f, 1.1f, 1.6f);
        ps.translate(0, -0.03f, 0);
        VertexConsumer halo = FxDraw.additive(c.buffers());
        for (JutsuMesh.Group g : mesh) {
            JutsuMesh.draw(g, ps.last(), halo, col[0] * 0.45f * alpha, col[1] * 0.45f * alpha, col[2] * 0.45f * alpha, 1f, FxDraw.FULL,
                    OverlayTexture.NO_OVERLAY);
        }
        ps.popPose();
    }

    // ---------------------------------------------------------------- the Byakugan

    /** The Byakugan switching on: rings of chakra pulse out of the eyes and a faint sphere of sight spreads. */
    static void awaken(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        float age = c.age(), p = c.progress();
        Vec3 eye = e.getEyePosition(c.partial());
        Vec3 look = e.getViewVector(c.partial());
        Vec3 side = look.cross(new Vec3(0, 1, 0));
        side = side.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : side.normalize();
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int s = -1; s <= 1; s += 2) {
            Vec3 o = eye.add(side.scale(s * 0.11)).add(look.scale(0.28));
            for (int k = 0; k < 3; k++) {
                float t = Mth.clamp((age - k * 2.5f) / 9f, 0f, 1f);
                if (t <= 0 || t >= 1) continue;
                float a = (1 - t) * 0.9f;
                FxDraw.ring(add, c.ps(), o.add(look.scale(t * 1.1)), look, 0.05f + t * 0.45f, 0.03f + 0.02f * (1 - t), 24,
                        FxDraw.addColor(SIGHT, a), FxDraw.addColor(SIGHT, 0f), FxDraw.FULL);
            }
        }
        float r = 0.4f + 5f * FxDraw.smooth(p);
        float a = 0.35f * (1 - p);
        for (int k = 0; k < 3; k++) {
            Vec3 axis = k == 0 ? new Vec3(0, 1, 0) : k == 1 ? look : side;
            FxDraw.ring(add, c.ps(), eye, axis, r, 0.05f, 48, FxDraw.addColor(SIGHT, a), FxDraw.addColor(SIGHT, a * 0.3f), FxDraw.FULL);
        }
    }

    /**
     * The Byakugan's sight (the All-Seeing Eye): a sphere of fine lines spreads from the eyes out to its range, the
     * chakra network of everything inside it showing for a moment as it passes.
     */
    static void sight(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 eye = e == null ? c.fx().a : e.getEyePosition(c.partial());
        float p = c.progress();
        float r = 0.5f + c.fx().size * FxDraw.smooth(Math.min(1f, p * 1.4f));
        float a = 0.55f * (1 - p);
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int k = 0; k < 6; k++) {                            // meridians
            float ang = k * Mth.PI / 6;
            FxDraw.ring(add, c.ps(), eye, new Vec3(Mth.cos(ang), 0, Mth.sin(ang)), r, 0.06f + r * 0.004f, 64,
                    FxDraw.addColor(SIGHT, a), FxDraw.addColor(SIGHT, a * 0.2f), FxDraw.FULL);
        }
        for (int k = -2; k <= 2; k++) {                          // parallels
            float lat = k * 0.45f;
            FxDraw.ring(add, c.ps(), eye.add(0, Mth.sin(lat) * r, 0), new Vec3(0, 1, 0), Mth.cos(lat) * r, 0.06f + r * 0.004f, 64,
                    FxDraw.addColor(SIGHT, a), FxDraw.addColor(SIGHT, a * 0.2f), FxDraw.FULL);
        }
    }

    // ---------------------------------------------------------------- Gentle Fist

    /**
     * A Gentle Fist strike: a palm of chakra lands on the body (a = where, b = where the striker stands) and its chakra
     * drives in, lighting up the chakra pathways around the point in thin blue lines.
     */
    static void gentleFist(FxClient.Ctx c) {
        Vec3 at = c.fx().a;
        Vec3 dir = at.subtract(c.fx().b);
        dir = new Vec3(dir.x, dir.y * 0.3, dir.z);
        if (dir.lengthSqr() < 1e-6) return;
        dir = dir.normalize();
        float p = c.progress();
        float in = Mth.clamp(c.age() / 2f, 0f, 1f);
        palm(c, at.subtract(dir.scale(0.35 - 0.2 * in)), dir.scale(-1), new Vec3(0, 1, 0), 0.62f, (1 - p) * 0.9f);
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int k = 0; k < 2; k++) {
            float t = Mth.clamp(p * 1.4f - k * 0.25f, 0f, 1f);
            if (t <= 0 || t >= 1) continue;
            FxDraw.ring(add, c.ps(), at.subtract(dir.scale(0.1)), dir, 0.15f + t * 0.8f, 0.06f, 24, FxDraw.addColor(CORE, 0.8f * (1 - t)),
                    FxDraw.addColor(CHAKRA, 0f), FxDraw.FULL);
        }
        RandomSource r = FxDraw.rng(c.fx().seed, 3);
        for (int k = 0; k < 5; k++) {                            // chakra pathways lighting up inside
            Vec3 to = at.add(dir.scale(0.25)).add((r.nextFloat() - 0.5) * 0.9, (r.nextFloat() - 0.5) * 1.1, (r.nextFloat() - 0.5) * 0.9);
            FxDraw.bolt(c.buffers(), c.ps(), c.cam(), at, to, c.fx().seed + k, 0.12f, 0.012f, CHAKRA, 0.8f * (1 - p), 1);
        }
    }

    // ---------------------------------------------------------------- Eight Trigrams 64 Palms

    /**
     * The Eight Trigrams field: the circle of trigrams round the yin-yang glows out across the ground under the user
     * and their target (a = its centre, size = its radius), turning slowly, for as long as the strikes go on.
     */
    static void trigramField(FxClient.Ctx c) {
        Vec3 a = c.fx().a;
        double y = FxDraw.groundY(a) + 0.04;
        float age = c.age(), ticks = c.fx().ticks;
        float grow = FxDraw.smooth(age / 6f);
        float fade = 1f - Mth.clamp((age - (ticks - 10)) / 10f, 0f, 1f);
        float r = c.fx().size * (0.3f + 0.7f * grow);
        float spin = age * 0.4f * Mth.DEG_TO_RAD;
        Vec3 u = new Vec3(Mth.cos(spin), 0, Mth.sin(spin)).scale(r), v = new Vec3(-Mth.sin(spin), 0, Mth.cos(spin)).scale(r);
        Vec3 o = new Vec3(a.x, y, a.z);
        FxDraw.Paint field = new FxDraw.Paint(0, 0, 1, 1, 200, 232, 255, Math.round(230 * fade));
        VertexConsumer vc = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(TRIGRAMS));
        FxDraw.quad(vc, c.ps(), o.subtract(u).subtract(v), o.add(u).subtract(v), o.add(u).add(v), o.subtract(u).add(v), field, FxDraw.FULL);
        float pulse = 0.55f + 0.25f * Mth.sin(age * 0.5f);
        FxDraw.Paint glow = new FxDraw.Paint(0, 0, 1, 1, Math.round(110 * pulse * fade), Math.round(170 * pulse * fade),
                Math.round(255 * pulse * fade), 255);
        VertexConsumer add = c.buffers().getBuffer(RenderType.eyes(TRIGRAMS));
        Vec3 o2 = o.add(0, 0.02, 0);
        FxDraw.quad(add, c.ps(), o2.subtract(u).subtract(v), o2.add(u).subtract(v), o2.add(u).add(v), o2.subtract(u).add(v), glow, FxDraw.FULL);
        Vec3 up = new Vec3(0, 1, 0);                             // and its other side, mapped the same way
        FxDraw.vertex(add, c.ps(), o2.subtract(u).subtract(v), glow, 0, 0, FxDraw.FULL, up);
        FxDraw.vertex(add, c.ps(), o2.subtract(u).add(v), glow, 1, 0, FxDraw.FULL, up);
        FxDraw.vertex(add, c.ps(), o2.add(u).add(v), glow, 1, 1, FxDraw.FULL, up);
        FxDraw.vertex(add, c.ps(), o2.add(u).subtract(v), glow, 0, 1, FxDraw.FULL, up);
        // chakra rising off the circle's edge
        VertexConsumer g = FxDraw.additive(c.buffers());
        FxDraw.ring(g, c.ps(), o.add(0, 0.05, 0), new Vec3(0, 1, 0), r * 0.97f, 0.12f, 64, FxDraw.addColor(CHAKRA, 0.6f * fade),
                FxDraw.addColor(CHAKRA, 0f), FxDraw.FULL);
    }

    /**
     * A flurry of the 64 Palms (entityA strikes entityB; size = how many palms this flurry is): palms of chakra flash
     * onto the target's chakra points one after another from every angle in front, each trailing a streak back to
     * the striker's shoulders, faster and denser with every doubling.
     */
    static void palmFlurry(FxClient.Ctx c) {
        Entity from = c.fx().entityA(), to = c.fx().entityB();
        if (from == null || to == null) return;
        float pt = c.partial();
        Vec3 chest = from.getPosition(pt).add(0, from.getBbHeight() * 0.72, 0);
        Vec3 body = to.getPosition(pt).add(0, to.getBbHeight() * 0.55, 0);
        Vec3 dir = body.subtract(chest);
        dir = new Vec3(dir.x, 0, dir.z);
        if (dir.lengthSqr() < 1e-6) return;
        dir = dir.normalize();
        Vec3 side = dir.cross(new Vec3(0, 1, 0)).normalize();
        int n = Math.max(1, Math.round(c.fx().size));
        int shown = Math.min(n, 18);
        float ticks = c.fx().ticks, age = c.age();
        RandomSource r = FxDraw.rng(c.fx().seed, 64);
        float half = to.getBbWidth() * 0.5f + 0.05f;
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int i = 0; i < shown; i++) {
            float x = (r.nextFloat() - 0.5f) * to.getBbWidth() * 1.2f;
            float y = (r.nextFloat() - 0.4f) * to.getBbHeight() * 0.7f;
            float when = ticks * 0.8f * i / shown;
            float life = Mth.clamp((age - when) / 3.5f, 0f, 1f);
            if (life <= 0 || life >= 1) continue;
            Vec3 hit = body.add(side.scale(x)).add(0, y, 0).subtract(dir.scale(half));
            boolean right = i % 2 == 0;
            Vec3 shoulder = chest.add(side.scale(right ? -0.3 : 0.3));
            float jab = Mth.sin(Mth.PI * Math.min(1f, life * 1.8f));
            palm(c, hit.subtract(dir.scale(0.12 * (1 - jab))), dir.scale(-1), new Vec3(0, 1, 0).add(side.scale(right ? -0.25 : 0.25)),
                    0.42f, (1 - life) * 1.1f);
            List<Vec3> streak = new ArrayList<>();
            for (int k = 0; k <= 6; k++) {
                float s = k / 6f;
                streak.add(shoulder.lerp(hit, s).add(0, Mth.sin(Mth.PI * s) * 0.12, 0));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), streak, 0.16f, 0.4f, FxDraw.addColor(CHAKRA, 0.05f), FxDraw.addColor(CORE, 0.6f * (1 - life)), FxDraw.FULL);
            FxDraw.ring(add, c.ps(), hit.subtract(dir.scale(0.02)), dir, 0.08f + life * 0.4f, 0.05f, 16, FxDraw.addColor(CORE, 0.7f * (1 - life)),
                    FxDraw.addColor(CHAKRA, 0f), FxDraw.FULL);
        }
        // the extra hands of a big flurry: a blur of palms all at once
        if (n > 18) {
            float a = 0.5f * (1 - c.progress());
            for (int i = 0; i < 6; i++) {
                float ang = (age * 1.7f + i * 1.05f);
                Vec3 hit = body.add(side.scale(Mth.cos(ang) * to.getBbWidth() * 0.45)).add(0, Mth.sin(ang * 1.3f) * to.getBbHeight() * 0.25, 0)
                        .subtract(dir.scale(half + 0.25));
                palm(c, hit, dir.scale(-1), new Vec3(0, 1, 0), 0.4f, a);
            }
        }
    }

    /** The 64th palm: one great palm of chakra drives the target back, a burst of rings blowing out behind it. */
    static void palmFinish(FxClient.Ctx c) {
        Vec3 at = c.fx().a, dir = c.fx().b.subtract(at);
        if (dir.lengthSqr() < 1e-6) return;
        dir = dir.normalize();
        float p = c.progress();
        float jab = FxDraw.smooth(Math.min(1f, c.age() / 3f));
        palm(c, at.subtract(dir.scale(0.6 - 0.4 * jab)), dir.scale(-1), new Vec3(0, 1, 0), 1.3f, (1 - p) * 1.2f);
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int k = 0; k < 4; k++) {
            float t = Mth.clamp(p * 1.6f - k * 0.15f, 0f, 1f);
            if (t <= 0 || t >= 1) continue;
            FxDraw.ring(add, c.ps(), at.add(dir.scale(t * 3.5)), dir, 0.4f + t * 1.6f, 0.15f * (1 - t) + 0.03f, 32,
                    FxDraw.addColor(CORE, 0.9f * (1 - t)), FxDraw.addColor(CHAKRA, 0f), FxDraw.FULL);
        }
    }

    // ---------------------------------------------------------------- Air Palm

    /**
     * Air Palm: a thrust of the palm sends a pressure wave of air (a = the palm, b = where it lands): a ghostly palm
     * shape rides at its front inside a ripple of rings, the air behind it shimmering; it bursts where it lands.
     */
    static void airPalm(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 dir = b.subtract(a);
        double len = dir.length();
        if (len < 1e-3) return;
        dir = dir.normalize();
        float age = c.age();
        float travel = Math.max(1f, c.fx().ticks - 8f);
        float t = Math.min(1f, age / travel);
        double front = len * t;
        float after = Math.max(0f, age - travel);
        float fade = 1f - Mth.clamp(after / 8f, 0f, 1f);
        Vec3 n = FxDraw.perpendicular(dir), m = dir.cross(n);
        VertexConsumer add = FxDraw.additive(c.buffers());
        if (t < 1f) {
            Vec3 head = a.add(dir.scale(front));
            palm(c, head, dir, new Vec3(0, 1, 0), 0.9f + (float) front * 0.04f, 0.45f);
            for (int k = 0; k < 4; k++) {                        // the pressure wave's ripples riding with it
                double d = front - k * 0.55;
                if (d < 0) continue;
                float rr = 0.45f + (float) d * 0.03f + k * 0.12f;
                FxDraw.ring(add, c.ps(), a.add(dir.scale(d)), dir, rr, 0.07f, 28, FxDraw.addColor(0xFFFFFF, 0.55f * (1 - k * 0.22f)),
                        FxDraw.addColor(0xCFE8FF, 0f), FxDraw.FULL);
            }
        }
        for (int k = 0; k < 6; k++) {                            // the air streaming behind it
            List<Vec3> pts = new ArrayList<>();
            double back = Math.max(0, front - 6);
            for (int i = 0; i <= 14; i++) {
                double s = back + (front - back) * i / 14.0;
                float r = 0.32f + (float) s * 0.02f;
                float ang = k * Mth.TWO_PI / 6 + (float) s * 0.6f;
                pts.add(a.add(dir.scale(s)).add(n.scale(Mth.cos(ang) * r)).add(m.scale(Mth.sin(ang) * r)));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), pts, 0.07f, 0.2f, FxDraw.addColor(0xDDEEFF, 0f), FxDraw.addColor(0xFFFFFF, 0.5f * fade), FxDraw.FULL);
        }
        if (after > 0) {                                         // the burst where it lands
            float s = Mth.clamp(after / 8f, 0f, 1f);
            for (int k = 0; k < 3; k++) {
                Vec3 axis = k == 0 ? dir : k == 1 ? n : m;
                FxDraw.ring(add, c.ps(), b, axis, 0.3f + s * 2.4f, 0.12f * (1 - s) + 0.02f, 32, FxDraw.addColor(0xFFFFFF, 0.8f * (1 - s)),
                        FxDraw.addColor(0xCFE8FF, 0f), FxDraw.FULL);
            }
        }
    }

    // ---------------------------------------------------------------- Palm Rotation

    /**
     * Eight Trigrams Palm Rotation: the user spins, letting chakra out of every point at once, and it becomes a whirling
     * dome round them (size = its radius), streaked with spinning chakra; the ground is scored in a ring at its foot.
     */
    static void rotation(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 base = e == null ? c.fx().a : e.getPosition(c.partial());
        double ground = FxDraw.groundY(base);
        Vec3 o = new Vec3(base.x, ground, base.z);
        float age = c.age(), ticks = c.fx().ticks;
        float grow = FxDraw.smooth(age / 4f);
        float fade = 1f - Mth.clamp((age - (ticks - 6)) / 6f, 0f, 1f);
        float R = c.fx().size * (0.35f + 0.65f * grow);
        float spin = age * 0.09f;
        VertexConsumer swirl = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(SWIRL));
        VertexConsumer addSwirl = c.buffers().getBuffer(RenderType.eyes(SWIRL));
        dome(swirl, c.ps(), o, R, spin, 2f, new FxDraw.Paint(0, 0, 1, 1, 225, 242, 255, Math.round(190 * fade)), false);
        dome(addSwirl, c.ps(), o, R * 1.04f, -spin * 0.7f + 0.3f, 3f,
                new FxDraw.Paint(0, 0, 1, 1, Math.round(120 * fade), Math.round(180 * fade), Math.round(255 * fade), 255), false);
        dome(addSwirl, c.ps(), o, R * 0.9f, spin * 1.3f, 1f,
                new FxDraw.Paint(0, 0, 1, 1, Math.round(90 * fade), Math.round(130 * fade), Math.round(200 * fade), 255), true);
        VertexConsumer add = FxDraw.additive(c.buffers());
        // the bright band where the dome meets the ground, and the groove it cuts
        FxDraw.ring(add, c.ps(), o.add(0, 0.05, 0), new Vec3(0, 1, 0), R, 0.5f, 64, FxDraw.addColor(CORE, 0.8f * fade),
                FxDraw.addColor(CHAKRA, 0f), FxDraw.FULL);
        FxDraw.ring(FxDraw.lit(c.buffers()), c.ps(), o.add(0, 0.03, 0), new Vec3(0, 1, 0), R + 0.05f, 0.35f, 64,
                FxDraw.color(0x2A2420, 0.6f * fade), FxDraw.color(0x2A2420, 0f), FxDraw.lightAt(o.add(0, 0.5, 0)));
    }

    /** A dome (a sphere cut at the ground) textured with spinning streaks: {@code turns} copies of the texture round it. */
    private static void dome(VertexConsumer vc, PoseStack ps, Vec3 o, float r, float spin, float turns, FxDraw.Paint paint, boolean inside) {
        int lat = 10, lon = 32;
        float top = ((float) (Math.PI / 2)) * 0.98f;
        for (int i = 0; i < lat; i++) {
            float a0 = -0.15f + (top + 0.15f) * i / lat, a1 = -0.15f + (top + 0.15f) * (i + 1) / lat;
            float v0 = i / (float) lat, v1 = (i + 1) / (float) lat;
            for (int j = 0; j < lon; j++) {
                float p0 = Mth.TWO_PI * j / lon, p1 = Mth.TWO_PI * (j + 1) / lon;
                Vec3 d00 = dir(a0, p0), d01 = dir(a0, p1), d10 = dir(a1, p0), d11 = dir(a1, p1);
                float u0 = turns * j / lon + spin, u1 = turns * (j + 1) / lon + spin;
                Vec3 q00 = o.add(d00.scale(r)), q01 = o.add(d01.scale(r)), q10 = o.add(d10.scale(r)), q11 = o.add(d11.scale(r));
                if (inside) {
                    FxDraw.vertex(vc, ps, q00, paint, u0, v0, FxDraw.FULL, d00.scale(-1));
                    FxDraw.vertex(vc, ps, q01, paint, u1, v0, FxDraw.FULL, d01.scale(-1));
                    FxDraw.vertex(vc, ps, q11, paint, u1, v1, FxDraw.FULL, d11.scale(-1));
                    FxDraw.vertex(vc, ps, q10, paint, u0, v1, FxDraw.FULL, d10.scale(-1));
                } else {
                    FxDraw.vertex(vc, ps, q00, paint, u0, v0, FxDraw.FULL, d00);
                    FxDraw.vertex(vc, ps, q10, paint, u0, v1, FxDraw.FULL, d10);
                    FxDraw.vertex(vc, ps, q11, paint, u1, v1, FxDraw.FULL, d11);
                    FxDraw.vertex(vc, ps, q01, paint, u1, v0, FxDraw.FULL, d01);
                }
            }
        }
    }

    private static Vec3 dir(float elevation, float azimuth) {
        float c = Mth.cos(elevation);
        return new Vec3(c * Mth.cos(azimuth), Math.max(-0.2f, Mth.sin(elevation)), c * Mth.sin(azimuth));
    }

    private static float[] rgb(int c) {
        return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
    }
}
