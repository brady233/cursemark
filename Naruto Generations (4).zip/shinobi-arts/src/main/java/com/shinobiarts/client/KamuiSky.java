package com.shinobiarts.client;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.world.phys.Vec3;

/**
 * The Kamui dimension's sky: there isn't one. No sun, moon, stars or clouds, and no horizon, only an even,
 * near-black haze in every direction (the biome's fog colour), the same at any time.
 */
public class KamuiSky extends DimensionSpecialEffects {
    public KamuiSky() {
        super(Float.NaN, false, SkyType.NONE, false, true);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 fogColor, float brightness) {
        return fogColor;
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return false;
    }
}
