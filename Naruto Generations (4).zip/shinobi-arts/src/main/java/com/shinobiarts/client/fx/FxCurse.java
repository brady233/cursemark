package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.CameraShake;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * The curse mark breaking loose (entityA = the user).
 * <ul>
 *   <li>CURSE_RELEASE (Level 1): the seal flares, a ring of dark purple chakra tears outward along the ground, black
 *       flame bursts up round the body and crackling dark arcs leap off it; the ground shudders.</li>
 *   <li>CURSE_TRANSFORM (Level 2): the dark chakra first drags inward into a black sphere round the body, then it
 *       detonates: a dome of black-violet chakra, three shockwave rings racing out over the ground, a pillar of black
 *       fog roaring into the sky and black lightning all round; everyone near feels the ground shake.</li>
 * </ul>
 */
final class FxCurse {
    private FxCurse() {}

    private static final ResourceLocation FOG = new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/fog.png");
    private static final int VIOLET = 0x8A3CFF, DEEP = 0x3A0E6A, BLACKFIRE = 0x14061E, EMBER = 0xFF4A1E;

    static void release(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 feet = e.getPosition(c.partial());
        float h = e.getBbHeight();
        float t = c.progress(), age = c.age();
        float fade = 1f - FxDraw.smooth(t);
        if (age < 1.5f) CameraShake.from(feet, 1.6f, 14, 12);
        VertexConsumer add = FxDraw.additive(c.buffers());
        // the ring tearing out along the ground
        FxDraw.ring(add, c.ps(), feet.add(0, 0.06, 0), new Vec3(0, 1, 0), 0.5f + t * 5.5f, 0.9f * fade + 0.1f, 48,
                FxDraw.addColor(VIOLET, 0.8f * fade), FxDraw.addColor(DEEP, 0f), FxDraw.FULL);
        FxDraw.ring(add, c.ps(), feet.add(0, 0.07, 0), new Vec3(0, 1, 0), 0.3f + t * 3.2f, 0.35f, 40,
                FxDraw.addColor(EMBER, 0.6f * fade), FxDraw.addColor(VIOLET, 0f), FxDraw.FULL);
        // black flame bursting up round the body
        VertexConsumer fog = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(FOG));
        RandomSource r = RandomSource.create(c.fx().seed);
        for (int k = 0; k < 26; k++) {
            float ang = r.nextFloat() * Mth.TWO_PI, y0 = r.nextFloat() * h;
            float life = Mth.clamp(t * 1.4f - r.nextFloat() * 0.3f, 0f, 1f);
            double rad = 0.35 + life * 1.3;
            Vec3 at = feet.add(Math.cos(ang) * rad, y0 + life * 1.8f, Math.sin(ang) * rad);
            float size = 0.6f + life * 1.4f;
            int col = k % 3 == 0 ? VIOLET : BLACKFIRE;
            float a = Mth.sin(life * Mth.PI) * (col == VIOLET ? 0.5f : 0.75f);
            FxDraw.billboard(fog, c.ps(), c.camera(), at, size, size, ang + age * 0.05f,
                    new FxDraw.Paint(0f, 0f, 1f, 1f, (col >> 16) & 255, (col >> 8) & 255, col & 255, Math.round(255 * a)), FxDraw.FULL);
        }
        // crackling arcs leaping off the body
        if (t < 0.6f) {
            for (int k = 0; k < 4; k++) {
                float ang = k * 1.57f + (int) (age / 2) * 0.9f;
                Vec3 from = feet.add(0, h * (0.4 + 0.15 * k), 0);
                Vec3 to = from.add(Math.cos(ang) * 1.6, 0.4 + 0.3 * Math.sin(age + k), Math.sin(ang) * 1.6);
                FxDraw.bolt(c.buffers(), c.ps(), c.cam(), from, to, c.fx().seed * 31L + k * 7L + (long) (age / 2), 0.25f, 0.035f, VIOLET, 0.9f * fade, 1);
            }
        }
    }

    static void transform(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 feet = e.getPosition(c.partial());
        Vec3 mid = feet.add(0, e.getBbHeight() * 0.55, 0);
        float t = c.progress(), age = c.age();
        VertexConsumer add = FxDraw.additive(c.buffers());
        VertexConsumer fog = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(FOG));
        VertexConsumer solid = FxDraw.glow(c.buffers());
        RandomSource r = RandomSource.create(c.fx().seed);
        float pull = Mth.clamp(t / 0.3f, 0f, 1f);                     // 0 .. 0.3: dark chakra dragged inward
        float blast = Mth.clamp((t - 0.3f) / 0.7f, 0f, 1f);           // 0.3 .. 1: the detonation
        if (blast > 0f && blast < 0.06f) CameraShake.from(feet, 4.5f, 40, 30);
        if (blast <= 0f) {
            // the gathering: wisps sucked in from all round, a black core swelling
            for (int k = 0; k < 30; k++) {
                float ang = r.nextFloat() * Mth.TWO_PI, el = (r.nextFloat() - 0.4f) * 2f;
                double rad = 4.5 * (1 - pull) + 0.6;
                Vec3 at = mid.add(Math.cos(ang) * rad, el * rad * 0.5, Math.sin(ang) * rad);
                FxDraw.billboard(fog, c.ps(), c.camera(), at, 0.7f, 0.7f, ang, new FxDraw.Paint(0f, 0f, 1f, 1f, 30, 8, 50, Math.round(200 * pull)), FxDraw.FULL);
            }
            FxDraw.sphere(solid, c.ps(), mid, 0.5f + pull * 1.1f, 10, 14, FxDraw.color(BLACKFIRE, 0.55f + pull * 0.35f), FxDraw.FULL);
            FxDraw.sphere(add, c.ps(), mid, 0.7f + pull * 1.3f, 10, 14, FxDraw.addColor(VIOLET, 0.35f * pull), FxDraw.FULL);
            return;
        }
        float fade = 1f - FxDraw.smooth(blast);
        // the dome of dark chakra
        FxDraw.sphere(solid, c.ps(), mid, 1.6f + blast * 5.5f, 12, 18, FxDraw.color(BLACKFIRE, 0.6f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), mid, 1.8f + blast * 6.2f, 12, 18, FxDraw.addColor(VIOLET, 0.45f * fade), FxDraw.FULL);
        // three shockwaves racing out over the ground
        for (int k = 0; k < 3; k++) {
            float b = Mth.clamp(blast * 1.3f - k * 0.15f, 0f, 1f);
            if (b <= 0f) continue;
            FxDraw.ring(add, c.ps(), feet.add(0, 0.06 + k * 0.01, 0), new Vec3(0, 1, 0), 1f + b * (12f - k * 2.5f), 1.4f * (1 - b) + 0.2f, 56,
                    FxDraw.addColor(k == 1 ? EMBER : VIOLET, 0.85f * (1 - b)), FxDraw.addColor(DEEP, 0f), FxDraw.FULL);
        }
        // the pillar of black fog roaring up
        for (int k = 0; k < 40; k++) {
            float ang = r.nextFloat() * Mth.TWO_PI, off = r.nextFloat();
            float life = Mth.clamp(blast * 1.2f - off * 0.2f, 0f, 1f);
            double rad = 0.4 + r.nextFloat() * 1.2 + life * 0.8;
            Vec3 at = feet.add(Math.cos(ang) * rad, off * 2 + life * (9 + off * 6), Math.sin(ang) * rad);
            float size = 1.2f + life * 2.6f;
            int col = k % 4 == 0 ? VIOLET : BLACKFIRE;
            float a = Mth.sin(life * Mth.PI) * (col == VIOLET ? 0.45f : 0.8f);
            FxDraw.billboard(fog, c.ps(), c.camera(), at, size, size, ang + age * 0.03f,
                    new FxDraw.Paint(0f, 0f, 1f, 1f, (col >> 16) & 255, (col >> 8) & 255, col & 255, Math.round(255 * a)), FxDraw.FULL);
        }
        // black lightning
        if (blast < 0.7f) {
            for (int k = 0; k < 6; k++) {
                float ang = k * 1.05f + (int) (age / 2) * 1.3f;
                Vec3 from = mid.add(0, 0.5, 0);
                Vec3 to = feet.add(Math.cos(ang) * (3 + 4 * blast), 0.1, Math.sin(ang) * (3 + 4 * blast));
                FxDraw.bolt(c.buffers(), c.ps(), c.cam(), from, to, c.fx().seed * 13L + k * 5L + (long) (age / 2), 0.5f, 0.05f, VIOLET, 0.95f * fade, 2);
            }
        }
    }
}
