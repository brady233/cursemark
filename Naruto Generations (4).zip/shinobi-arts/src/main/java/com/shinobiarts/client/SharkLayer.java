package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * The Hoshigaki shark form (an original design): the skin goes grey-blue with a pale belly and gill slits on the neck,
 * a tall dorsal fin rises from the back, swept fins grow from the forearms, the fingers end in hooked claws, and a
 * shark's tail sways behind. Rough Skin hardened shows as a rough, pale sheen over the body.
 */
public class SharkLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SKIN = new ResourceLocation(ShinobiArts.MODID, "textures/entity/shark/skin.png");
    private static final ResourceLocation ROUGH = new ResourceLocation(ShinobiArts.MODID, "textures/entity/shark/rough.png");
    private static final int FIN = 0x51708A, FIN_EDGE = 0x2F4A60, CLAW = 0xE9EEF2;

    public SharkLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbAmount,
                       float partial, float age, float headYaw, float headPitch) {
        if (player.isInvisible()) return;
        int look = ClientEyes.look(player);
        boolean shark = (look & SharinganManager.LOOK_SHARK) != 0, rough = (look & SharinganManager.LOOK_ROUGH_SKIN) != 0;
        if (!shark && !rough) return;
        PlayerModel<AbstractClientPlayer> model = getParentModel();
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0f);
        if (shark) {
            model.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(SKIN)), light, overlay, 1f, 1f, 1f, 0.92f);
        }
        if (rough) {
            model.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(ROUGH)), light, overlay, 1f, 1f, 1f, 0.6f);
        }
        if (!shark) return;
        VertexConsumer vc = FxDraw.lit(buffers);
        FxDraw.Paint fin = FxDraw.color(FIN, 1f), edge = FxDraw.color(FIN_EDGE, 1f), claw = FxDraw.color(CLAW, 1f);

        // the dorsal fin, out of the upper back (body space: +z is the back, -y is up, 1 unit = 16 pixels)
        ps.pushPose();
        model.body.translateAndRotate(ps);
        Vec3 f0 = new Vec3(0, 0.12, 0.13), f1 = new Vec3(0, 0.5, 0.13), tip = new Vec3(0, -0.12, 0.62);
        FxDraw.quad(vc, ps, f0, f1, tip, tip, fin, light);
        FxDraw.quad(vc, ps, f1, f0, tip, tip, edge, light);
        // the tail, from the base of the spine, swaying
        float sway = Mth.sin(age * 0.18f) * 0.35f + limbAmount * Mth.sin(limbSwing * 0.6f) * 0.25f;
        List<Vec3> spine = new ArrayList<>();
        int n = 7;
        float[] radii = new float[n + 1];
        for (int i = 0; i <= n; i++) {
            float s = i / (float) n;
            spine.add(new Vec3(Mth.sin(sway * s * 2f) * 0.45f * s, 0.72f + 0.12f * s, 0.14f + 0.85f * s));
            radii[i] = 0.11f * (1f - 0.8f * s) + 0.015f;
        }
        FxDraw.tube(vc, ps, spine, radii, 6, fin, 1f, light, true);
        // the tail's fluke: an upright crescent at the end
        Vec3 end = spine.get(n);
        FxDraw.quad(vc, ps, end.add(0, 0.02, -0.08), end.add(0, -0.38, 0.22), end.add(0, -0.05, 0.12), end.add(0, 0.02, -0.08), fin, light);
        FxDraw.quad(vc, ps, end.add(0, 0.02, -0.08), end.add(0, 0.3, 0.2), end.add(0, 0.05, 0.1), end.add(0, 0.02, -0.08), fin, light);
        FxDraw.quad(vc, ps, end.add(0, -0.38, 0.22), end.add(0, 0.02, -0.08), end.add(0, 0.02, -0.08), end.add(0, -0.05, 0.12), edge, light);
        FxDraw.quad(vc, ps, end.add(0, 0.3, 0.2), end.add(0, 0.02, -0.08), end.add(0, 0.02, -0.08), end.add(0, 0.05, 0.1), edge, light);
        ps.popPose();

        // forearm fins and claws on both arms (arm space: the hand is at +y, about 0.6 down)
        for (int side = -1; side <= 1; side += 2) {
            ps.pushPose();
            (side < 0 ? model.leftArm : model.rightArm).translateAndRotate(ps);
            float out = side * 0.14f;
            Vec3 a = new Vec3(out, 0.25, 0.1), b = new Vec3(out, 0.55, 0.1), t2 = new Vec3(out + side * 0.05f, 0.12, 0.42);
            FxDraw.quad(vc, ps, a, b, t2, t2, fin, light);
            FxDraw.quad(vc, ps, b, a, t2, t2, edge, light);
            for (int k = 0; k < 3; k++) {                             // three hooked claws past the fingertips
                float x = (k - 1) * 0.07f;
                FxDraw.cone(vc, ps, new Vec3(x, 0.68, -0.06), new Vec3(x, 0.86, -0.13), 0.025f, 5, claw, light);
            }
            ps.popPose();
        }
        // gills: three dark slits each side of the neck are on the skin texture
    }
}
