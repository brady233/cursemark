package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderArmEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * In first person, the curse mark shows on your own bare arm too: the arm is drawn as the game draws it (skin, then
 * sleeve), then the mark over it (the spreading flames at Level 1, grey skin and flames at Level 2).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CurseMarkArm {
    private CurseMarkArm() {}

    @SubscribeEvent
    public static void onRenderArm(RenderArmEvent event) {
        AbstractClientPlayer player = event.getPlayer();
        int look2 = ClientEyes.look2(player);
        int stage = SharinganManager.lookCurseStage(look2);
        if (SharinganManager.lookCurse(look2) == 0 || stage == 0) return;
        EntityRenderer<? super AbstractClientPlayer> r = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(player);
        if (!(r instanceof PlayerRenderer renderer)) return;
        PlayerModel<AbstractClientPlayer> model = renderer.getModel();
        boolean right = event.getArm() == HumanoidArm.RIGHT;
        ModelPart arm = right ? model.rightArm : model.leftArm, sleeve = right ? model.rightSleeve : model.leftSleeve;
        model.attackTime = 0f;
        model.crouching = false;
        model.swimAmount = 0f;
        model.setupAnim(player, 0f, 0f, 0f, 0f, 0f);
        arm.xRot = 0f;
        sleeve.xRot = 0f;
        arm.visible = true;
        sleeve.visible = player.isModelPartShown(right ? PlayerModelPart.RIGHT_SLEEVE : PlayerModelPart.LEFT_SLEEVE);
        var skin = player.getSkinTextureLocation();
        int light = event.getPackedLight();
        arm.render(event.getPoseStack(), event.getMultiBufferSource().getBuffer(RenderType.entitySolid(skin)), light, OverlayTexture.NO_OVERLAY);
        sleeve.render(event.getPoseStack(), event.getMultiBufferSource().getBuffer(RenderType.entityTranslucent(skin)), light, OverlayTexture.NO_OVERLAY);
        arm.render(event.getPoseStack(), event.getMultiBufferSource().getBuffer(RenderType.entityTranslucent(CurseMarkLayer.texture(player, stage))),
                light, OverlayTexture.NO_OVERLAY);
        if (stage > 0)      // the seal is its own texture once the marks are out
            arm.render(event.getPoseStack(), event.getMultiBufferSource().getBuffer(RenderType.entityTranslucent(CurseMarkLayer.SEAL)),
                    light, OverlayTexture.NO_OVERLAY);
        event.setCanceled(true);
    }
}
