package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.HashMap;
import java.util.Map;

/**
 * The Heaven curse mark, in pixel art like the rest of the game (textures from tools/make_curse_mark.py):
 * <ul>
 *   <li>Always: the seal on the outside of the left shoulder, three black commas inside a cracked ring.</li>
 *   <li>Level 1: jagged black strokes with flame barbs branch out of the seal over the shoulder, arm, chest, back,
 *       ribs and up the neck over the left of the face, spreading in about a second; the left eye turns black with a
 *       glowing gold iris (drawn on the dojutsu eye model, so it matches them); the seal and the marks' edges burn.</li>
 *   <li>Level 2: grey skin, black eyes with glowing amber irises, a dark band across the nose, the marks sunk into the
 *       grey; long grey hair; and two great wings shaped like hands (a blocky model, see CurseFormModel), unfurling
 *       out of the back, beating in the air and folded up behind on the ground.</li>
 * </ul>
 * The marks are drawn on a body just bigger than a skin's outer layer, so they show over jackets and sleeves too, and
 * slim-armed skins get their own fit.
 */
public class CurseMarkLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation[] SPREAD = new ResourceLocation[4];
    private static final ResourceLocation[] GLOW = new ResourceLocation[4];
    static final ResourceLocation SEAL = tex("curse_seal");
    private static final ResourceLocation SEAL_GLOW = tex("curse_seal_glow"), LEVEL2 = tex("curse_l2"),
            LEVEL2_GLOW = tex("curse_l2_glow"), FORM = tex("form"), FORM_GLOW = tex("form_glow");

    static {
        for (int i = 0; i < 4; i++) {
            SPREAD[i] = tex("curse_l1_" + i);
            GLOW[i] = tex("curse_glow_" + i);
        }
    }

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(ShinobiArts.MODID, "textures/entity/curse/" + name + ".png");
    }

    /** When each player's mark last changed level (client game time), to play the spreading and the wings unfurling. */
    private static final Map<Integer, long[]> CHANGED = new HashMap<>();

    private static final ResourceLocation EYE = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/curse_eye.png"),
            EYE_GLOW = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/curse_eye_glow.png");

    private final PlayerModel<AbstractClientPlayer> marks, marksSlim;
    /** The eye model the dojutsu are drawn on, for the cursed eye (so it's the same shape and place as theirs). */
    private final HumanoidModel<AbstractClientPlayer> eyes;
    private final CurseFormModel form;

    public CurseMarkLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
        super(parent);
        this.marks = new PlayerModel<>(models.bakeLayer(ClientSetup.CURSE_MARKS_LAYER), false);
        this.marksSlim = new PlayerModel<>(models.bakeLayer(ClientSetup.CURSE_MARKS_SLIM_LAYER), true);
        this.form = new CurseFormModel(models.bakeLayer(ClientSetup.CURSE_FORM_LAYER));
        this.eyes = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHARINGAN_LAYER));
    }

    /** Which spread texture to show now (0..3), and records the change of level. */
    static int spread(AbstractClientPlayer player, int stage) {
        long now = player.level().getGameTime();
        long[] c = CHANGED.computeIfAbsent(player.getId(), k -> new long[]{-1, now});
        if (c[0] != stage) {
            c[0] = stage;
            c[1] = now;
        }
        long e = now - c[1];
        return e < 5 ? 0 : e < 11 ? 1 : e < 18 ? 2 : 3;
    }

    /** The mark's texture on the skin at this level (the seal alone while it's sealed). */
    static ResourceLocation texture(AbstractClientPlayer player, int stage) {
        return stage >= 2 ? LEVEL2 : stage == 1 ? SPREAD[spread(player, stage)] : SEAL;
    }

    /** Each player's wing shield: [shielding now (1/0), game time it last switched]. */
    private static final Map<Integer, long[]> SHIELD = new HashMap<>();

    /** How far the wings are into the shield pose (0..1): they swing round in about 4 ticks, and back out again. */
    static float shield(AbstractClientPlayer player, boolean on, float partial) {
        long now = player.level().getGameTime();
        long[] st = SHIELD.computeIfAbsent(player.getId(), k -> new long[]{0, now - 100});
        if ((st[0] == 1) != on) {
            st[0] = on ? 1 : 0;
            st[1] = now;
        }
        float t = Mth.clamp((now - st[1] + partial) / 4f, 0f, 1f);
        t = t * t * (3f - 2f * t);
        return on ? t : 1f - t;
    }

    static float sinceChange(AbstractClientPlayer player, float partial) {
        long[] c = CHANGED.get(player.getId());
        return c == null ? 999f : player.level().getGameTime() - c[1] + partial;
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbAmount,
                       float partial, float age, float headYaw, float headPitch) {
        if (player.isInvisible()) return;
        int look2 = ClientEyes.look2(player);
        if (SharinganManager.lookCurse(look2) == 0) {
            CHANGED.remove(player.getId());
            return;
        }
        int stage = SharinganManager.lookCurseStage(look2);
        spread(player, stage);
        PlayerModel<AbstractClientPlayer> body = "slim".equals(player.getModelName()) ? marksSlim : marks;
        getParentModel().copyPropertiesTo(body);
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0f);

        // the mark on the skin
        body.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(texture(player, stage))), light, overlay, 1f, 1f, 1f, 1f);
        if (stage > 0) {
            // the seal is a texture of its own (drawn finer than the marks), laid on top of them
            body.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(SEAL)), light, overlay, 1f, 1f, 1f, 1f);
            // it burns: the seal blazes orange-red, the marks' edges glow violet, pulsing (faster at Level 2)
            float pulse = 0.65f + 0.35f * Mth.sin(age * (stage == 2 ? 0.45f : 0.25f));
            ResourceLocation glow = stage >= 2 ? LEVEL2_GLOW : GLOW[spread(player, stage)];
            body.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(glow)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, pulse);
            body.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(SEAL_GLOW)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 0.8f + 0.2f * pulse);
        }
        if (stage == 1) {
            // Level 1: the left eye turns black with a burning gold iris; the right keeps its dojutsu, or the skin's eye
            getParentModel().copyPropertiesTo(eyes);
            eyes.setAllVisible(false);
            eyes.head.visible = true;
            eyes.renderToBuffer(ps, buffers.getBuffer(RenderType.entityCutoutNoCull(EYE)), light, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
            eyes.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(EYE_GLOW)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 0.75f + 0.25f * Mth.sin(age * 0.25f));
        }
        if (stage < 2) return;

        // Level 2: the hair and the wings
        boolean airborne = !player.onGround() || player.getAbilities().flying;
        form.pose(airborne, CurseFormModel.beat(age), shield(player, SharinganManager.lookCurseShield(look2), partial));
        float unfurl = Mth.clamp(sinceChange(player, partial) / 14f, 0f, 1f);
        unfurl = unfurl * unfurl * (3f - 2f * unfurl);
        float pulse = 0.55f + 0.3f * Mth.sin(age * 0.45f);

        ps.pushPose();
        getParentModel().head.translateAndRotate(ps);
        form.hair.render(ps, buffers.getBuffer(RenderType.entityCutoutNoCull(FORM)), light, overlay);
        ps.popPose();

        if (unfurl > 0.02f) {
            ps.pushPose();
            getParentModel().body.translateAndRotate(ps);
            for (var wing : new net.minecraft.client.model.geom.ModelPart[]{form.leftWing, form.rightWing}) {
                ps.pushPose();
                ps.translate(wing.x / 16f, wing.y / 16f, wing.z / 16f);       // the wing grows out from its root
                ps.scale(unfurl, unfurl, unfurl);
                ps.translate(-wing.x / 16f, -wing.y / 16f, -wing.z / 16f);
                wing.render(ps, buffers.getBuffer(RenderType.entityCutoutNoCull(FORM)), light, overlay);
                wing.render(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(FORM_GLOW)), LightTexture.FULL_BRIGHT,
                        OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, pulse);
                ps.popPose();
            }
            ps.popPose();
        }
    }
}
