package com.shinobiarts.client;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * The curse mark's Level 2 form as a blocky model, like a Blockbench model, with a pixel-art texture
 * (textures/entity/curse/form.png, made by tools/make_curse_form.py; the texture's layout is set here):
 * <ul>
 *   <li>Two wings shaped like great clawed hands, out of the shoulder blades: a stubby upper arm and forearm (each
 *       bone is boxes crossed over each other so it looks rounded), knobs at the shoulder and elbow, a bony spur at the
 *       elbow, a huge thick rounded palm, and four big fat fingers and a thumb that taper and curl forward into
 *       hooked black claws.</li>
 *   <li>Long hair: a mane falling down the back, a cap over the crown, jagged bangs and locks by the face.</li>
 * </ul>
 * Units are pixels (1/16 block), y down; the wings are drawn in the body's space, the hair in the head's.
 */
public final class CurseFormModel {
    public static final int TEX_W = 128, TEX_H = 64;
    /** The fingers' fan: their angles from the hand's line, and where they leave the palm. */
    public static final float[] FINGER_ANGLE = {-0.45f, -0.15f, 0.15f, 0.45f};
    public static final float[] FINGER_Y = {-4.5f, -1.5f, 1.5f, 4.5f};
    /** Bone lengths, and how far each finger joint curls forward (the hands look like they're about to grab). */
    public static final float UPPER = 4f, FORE = 5f, SEG1 = 7f, SEG2 = 5.5f, CLAW = 4f, CURL = 0.4f;

    public final ModelPart leftWing, rightWing, hair;
    private final ModelPart[] fore = new ModelPart[2], hand = new ModelPart[2];
    private final ModelPart[][] joint = new ModelPart[2][4], claw = new ModelPart[2][4];

    public CurseFormModel(ModelPart root) {
        this.leftWing = root.getChild("left_wing");
        this.rightWing = root.getChild("right_wing");
        this.hair = root.getChild("hair");
        ModelPart[] wings = {leftWing, rightWing};
        for (int i = 0; i < 2; i++) {
            fore[i] = wings[i].getChild("upper").getChild("fore");
            hand[i] = fore[i].getChild("hand");
            for (int f = 0; f < 4; f++) {
                joint[i][f] = hand[i].getChild("finger" + f).getChild("joint");
                claw[i][f] = joint[i][f].getChild("claw");
            }
        }
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        wing(root.addOrReplaceChild("left_wing", CubeListBuilder.create(), PartPose.offset(2.5f, 3f, 2.2f)), 1);
        wing(root.addOrReplaceChild("right_wing", CubeListBuilder.create(), PartPose.offset(-2.5f, 3f, 2.2f)), -1);

        PartDefinition hair = root.addOrReplaceChild("hair", CubeListBuilder.create()
                .texOffs(0, 26).addBox(-4.5f, -8.5f, 4.05f, 9f, 18f, 1f)          // the mane down the back
                .texOffs(20, 26).addBox(-4.5f, -8.6f, -4.5f, 9f, 1f, 9f)         // the cap over the crown
                .texOffs(20, 36).addBox(-4.5f, -8.5f, -4.55f, 9f, 4f, 0f)        // the bangs
                .texOffs(40, 36).addBox(4.55f, -8f, -3.5f, 0f, 10f, 6f)          // the locks by the face
                .texOffs(40, 36).mirror().addBox(-4.55f, -8f, -3.5f, 0f, 10f, 6f),
                PartPose.ZERO);
        return LayerDefinition.create(mesh, TEX_W, TEX_H);
    }

    /** One wing; {@code s} = 1 for the left (reaching out along +x), -1 for the right. */
    private static void wing(PartDefinition wing, int s) {
        // each bone is boxes crossed over each other, so it looks rounded rather than square
        PartDefinition upper = wing.addOrReplaceChild("upper", CubeListBuilder.create()
                .texOffs(0, 0).addBox(x(s, 0f, UPPER), -1.75f, -1.75f, UPPER, 3.5f, 3.5f)
                .texOffs(0, 7).addBox(x(s, 0f, UPPER), -2f, -1.5f, UPPER, 4f, 3f)
                .texOffs(0, 14).addBox(x(s, 0f, UPPER), -1.5f, -2f, UPPER, 3f, 4f)
                .texOffs(100, 16).addBox(-2f, -2f, -2f, 4f, 4f, 4f),                         // the shoulder knob
                PartPose.ZERO);
        PartDefinition fore = upper.addOrReplaceChild("fore", CubeListBuilder.create()
                .texOffs(30, 0).addBox(x(s, 0f, FORE), -1.5f, -1.25f, FORE, 3f, 2.5f)
                .texOffs(30, 6).addBox(x(s, 0f, FORE), -1.25f, -1.5f, FORE, 2.5f, 3f)
                .texOffs(100, 16).addBox(-1.75f, -1.75f, -1.75f, 3.5f, 3.5f, 3.5f)           // the elbow
                .texOffs(30, 12).addBox(-0.5f, -0.5f, 1.5f, 1f, 1f, 4f),                    // a bony spur off it
                PartPose.offset(s * UPPER, 0f, 0f));
        PartDefinition hand = fore.addOrReplaceChild("hand", CubeListBuilder.create()
                .texOffs(64, 0).addBox(x(s, 0f, 10f), -6f, -1.75f, 10f, 12f, 3.5f)          // a huge thick palm,
                .texOffs(94, 0).addBox(x(s, -0.5f, 11f), -4.5f, -2f, 11f, 9f, 4f),          // rounded off
                PartPose.offset(s * FORE, 0f, 0f));
        for (int f = 0; f < 4; f++) {
            PartDefinition seg1 = hand.addOrReplaceChild("finger" + f, CubeListBuilder.create()
                    .texOffs(64, 16).addBox(x(s, 0f, SEG1), -2f, -1.5f, SEG1, 4f, 3f)
                    .texOffs(64, 24).addBox(x(s, 0f, SEG1), -1.5f, -2f, SEG1, 3f, 4f),
                    PartPose.offsetAndRotation(s * 10f, FINGER_Y[f], 0f, 0f, 0f, s * FINGER_ANGLE[f]));
            PartDefinition seg2 = seg1.addOrReplaceChild("joint", CubeListBuilder.create()
                    .texOffs(86, 24).addBox(x(s, -0.3f, SEG2), -1.25f, -1.25f, SEG2, 2.5f, 2.5f),
                    PartPose.offsetAndRotation(s * SEG1, 0f, 0f, 0f, s * CURL, 0f));
            seg2.addOrReplaceChild("claw", CubeListBuilder.create()
                    .texOffs(86, 16).addBox(x(s, -0.3f, CLAW), -1f, -1f, CLAW, 2f, 2f)
                    .texOffs(86, 16).addBox(x(s, CLAW - 0.6f, 2.5f), -0.5f, -0.5f, 2.5f, 1f, 1f),   // the hooked tip
                    PartPose.offsetAndRotation(s * SEG2, 0f, 0f, 0f, s * CURL * 1.4f, 0f));
        }
        PartDefinition thumb = hand.addOrReplaceChild("thumb", CubeListBuilder.create()
                .texOffs(64, 32).addBox(x(s, 0f, 7f), -1.75f, -1.75f, 7f, 3.5f, 3.5f),
                PartPose.offsetAndRotation(s * 2.5f, -6f, 0f, 0f, 0f, s * -1.1f));
        thumb.addOrReplaceChild("claw", CubeListBuilder.create()
                .texOffs(86, 16).addBox(x(s, -0.3f, CLAW), -1f, -1f, CLAW, 2f, 2f)
                .texOffs(86, 16).addBox(x(s, CLAW - 0.6f, 2.5f), -0.5f, -0.5f, 2.5f, 1f, 1f),
                PartPose.offsetAndRotation(s * 7f, 0f, 0f, 0f, s * CURL, 0f));
    }

    /** Where a box {@code len} long starts along x, {@code from} out from the joint, for either side. */
    private static float x(int s, float from, float len) {
        return s > 0 ? from : -from - len;
    }

    /**
     * Poses the wings: sweeping out to the sides and back in while in the air, folded up behind on the ground. {@code beat} 0..1 is where the
     * wingbeat is.
     */
    public void pose(boolean airborne, float beat) {
        pose(airborne, beat, 0f);
    }

    /**
     * As above, blended towards the wing shield by {@code shield} (0..1): the wings wrap round the body like a cocoon,
     * palms over the sides and fingers locked across the front.
     */
    public void pose(boolean airborne, float beat, float shield) {
        ModelPart[] wings = {leftWing, rightWing};
        for (int i = 0; i < 2; i++) {
            float s = i == 0 ? 1f : -1f;
            float raise, back, bend, wrist, foreBack, handBack;
            if (airborne) {
                // a sideways sweep, not a flap: the wings stay level, reaching straight out to the sides (beat 0),
                // then sweep back in behind the shoulders (beat 1), the elbow and wrist folding back as they come in
                raise = 0.06f;
                back = 0.05f + 0.45f * beat;
                bend = 0.05f;
                wrist = 0f;
                foreBack = 0.1f + 0.25f * beat;
                handBack = 0.05f + 0.15f * beat;
            } else {
                raise = 0.45f;
                back = 1.25f;
                bend = 1.3f;
                wrist = 0.5f;
                foreBack = 0f;
                handBack = 0f;
            }
            float hx = 0f, hy = -s * handBack, hz = -s * wrist, curl = CURL;
            if (shield > 0f) {
                // the shield is a cocoon: the arms reach out round the sides, the palms cover the flanks, and the
                // fingers curl across the front, the claws meeting in the middle, thumbs up over the shoulders
                // (hand angles worked out for that)
                raise = Mth.lerp(shield, raise, 0.15f);
                back = Mth.lerp(shield, back, 0.1f);
                bend = Mth.lerp(shield, bend, 0f);
                foreBack = Mth.lerp(shield, foreBack, 0.7f);
                hx = Mth.lerp(shield, hx, -0.1323f);
                hy = Mth.lerp(shield, hy, s * 2.5193f);
                hz = Mth.lerp(shield, hz, s * 0.0275f);
                curl = Mth.lerp(shield, CURL, 1.0f);
            }
            wings[i].zRot = -s * raise;
            wings[i].yRot = -s * back;
            fore[i].zRot = -s * bend;
            fore[i].yRot = -s * foreBack;
            hand[i].xRot = hx;
            hand[i].yRot = hy;
            hand[i].zRot = hz;
            for (int f = 0; f < 4; f++) {
                joint[i][f].yRot = s * curl;
                claw[i][f].yRot = s * curl * 1.4f;
            }
        }
    }

    public static float beat(float age) {
        return 0.5f + 0.5f * Mth.sin(age * 0.35f);
    }
}
