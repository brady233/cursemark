package com.shinobiarts.client;

import com.shinobiarts.ninja.Jinchuriki;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.TailedBeast;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * A jinchuriki's bar at the top of the screen while their beast's chakra is out: the form, how long a rage form has
 * left, and the EXP toward the next form. The screen's edges burn with the beast's colour while it's in control.
 * Out of form, only the cooldown shows.
 */
public final class JinchurikiHud {
    private JinchurikiHud() {}

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height);

    private static void render(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized()) return;
        Jinchuriki.State s = d.jin;
        TailedBeast b = s.beast();
        if (b == null) return;
        Font font = mc.font;
        long now = player.level().getGameTime();
        int color = b.color & 0xFFFFFF;
        if (s.form == Jinchuriki.NONE) {
            if (s.cooldownUntil > now) {
                Component text = Component.translatable("hud.shinobiarts.jin_cooldown", b.displayName(), (s.cooldownUntil - now + 19) / 20);
                g.drawString(font, text, (width - font.width(text)) / 2, 6, 0xFF9A9AB0, true);
            }
            return;
        }
        if (s.rage()) {                                    // the beast's chakra creeping in at the edges
            int c = (s.form >= 4 ? b.dark : b.color) & 0xFFFFFF;
            int band = Math.max(10, Math.min(width, height) / 5);
            int a = (int) (0x50 + 0x20 * Math.sin(now * 0.3)) << 24;
            g.fillGradient(0, 0, width, band, a | c, c);
            g.fillGradient(0, height - band, width, height, c, a | c);
        }
        int w = 182, x = (width - w) / 2, y = 16;
        Component title = s.rage()
                ? Component.translatable("hud.shinobiarts.jin_rage", b.displayName(), s.form)
                : Component.translatable("hud.shinobiarts.jin_cloak", b.displayName());
        g.drawString(font, title, (width - font.width(title)) / 2, y - 11, 0xFF000000 | brighten(color), true);
        float need = s.needed();
        g.fill(x - 1, y - 1, x + w + 1, y + 5, 0xC0000000);
        if (need > 0) {
            int fill = Math.round(w * Math.min(1f, s.exp / need));
            g.fillGradient(x, y, x + fill, y + 4, 0xFF000000 | brighten(color), 0xFF000000 | color);
            String nums = Component.translatable("hud.shinobiarts.jin_exp", (int) s.exp, (int) need).getString();
            g.drawString(font, nums, (width - font.width(nums)) / 2, y + 7, 0xFFE8E8F0, true);
        } else {
            g.fill(x, y, x + w, y + 4, 0xFF000000 | color);
            String nums = Component.translatable("hud.shinobiarts.jin_mastered").getString();
            g.drawString(font, nums, (width - font.width(nums)) / 2, y + 7, 0xFFE8E8F0, true);
        }
        if (s.rage()) {
            long left = Math.max(0, s.until - now);
            String tag = Component.translatable("hud.shinobiarts.jin_left", (left + 19) / 20).getString();
            g.drawString(font, tag, (width - font.width(tag)) / 2, y + 18, 0xFFFF7070, true);
        } else {
            long cd = d.cooldownRemaining("beast_bomb", now);
            String tag = cd > 0 ? Component.translatable("hud.shinobiarts.jin_bomb_cd", String.format("%.1f", cd / 20.0)).getString()
                    : Component.translatable("hud.shinobiarts.jin_bomb_ready").getString();
            g.drawString(font, tag, (width - font.width(tag)) / 2, y + 18, 0xFFB0B0C8, true);
        }
    }

    private static int brighten(int c) {
        int r = (c >> 16) & 255, gr = (c >> 8) & 255, b = c & 255;
        return (Math.min(255, r + (255 - r) / 3) << 16) | (Math.min(255, gr + (255 - gr) / 3) << 8) | Math.min(255, b + (255 - b) / 3);
    }
}
