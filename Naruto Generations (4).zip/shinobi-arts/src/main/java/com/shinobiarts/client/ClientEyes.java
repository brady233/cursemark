package com.shinobiarts.client;

import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

import java.util.HashMap;
import java.util.Map;

/**
 * How each visible player looks (sent by the server, packed as in SharinganManager.look): the Sharingan stage and
 * Mangekyou pattern on their face, Lightning Armor's glow, Kamui. Clones carry their own eyes.
 */
public final class ClientEyes {
    private static final Map<Integer, Integer> LOOKS = new HashMap<>();
    private static final Map<Integer, Integer> LOOKS2 = new HashMap<>();

    private ClientEyes() {}

    public static void set(int entityId, int look) {
        if (look == 0) LOOKS.remove(entityId);
        else LOOKS.put(entityId, look);
    }

    public static void set(int entityId, int look, int look2) {
        set(entityId, look);
        if (look2 == 0) LOOKS2.remove(entityId);
        else LOOKS2.put(entityId, look2);
    }

    /** The second word of an entity's look (the curse mark; see SharinganManager.look2). */
    public static int look2(Entity entity) {
        if (entity instanceof ShadowClone) return 0;
        Minecraft mc = Minecraft.getInstance();
        if (entity == mc.player) return SharinganManager.look2(mc.player, ClientNinjaData.get());
        return LOOKS2.getOrDefault(entity.getId(), 0);
    }

    /** The packed look of an entity (0 = nothing special). */
    public static int look(Entity entity) {
        if (entity instanceof ShadowClone clone) return clone.getEyesLook();
        Minecraft mc = Minecraft.getInstance();
        if (entity == mc.player && mc.level != null) {
            return SharinganManager.look(mc.player, ClientNinjaData.get(), mc.level.getGameTime());
        }
        return LOOKS.getOrDefault(entity.getId(), 0);
    }

    /** Sharingan stage drawn on this entity's face, or 0. */
    public static int stage(Entity entity) {
        return SharinganManager.lookStage(look(entity));
    }

    public static void clear() {
        LOOKS.clear();
        LOOKS2.clear();
    }
}
