package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Dead Bone Pulse (Kimimaro): Dance of the Seedling Fern, a forest of huge, slightly curved bone spikes erupting from
 * the ground round the caster in four waves, then sinking back.
 */
final class FxBone {
    private FxBone() {}

    static Paint bone() {
        return FxDraw.block("minecraft:block/bone_block_side", 0xFFFFFF, 1f);
    }

    static void forest(FxClient.Ctx c) {
        Vec3 centre = c.fx().a;
        float age = c.age();
        int ticks = c.fx().ticks;
        float sink = Mth.clamp((age - (ticks - 12)) / 12f, 0f, 1f);
        VertexConsumer vc = FxDraw.blocks(c.buffers());
        Paint bone = bone();
        int light = FxDraw.lightAt(centre.add(0, 1, 0));
        for (int wave = 0; wave < 4; wave++) {
            float rise = FxDraw.smooth((age - wave * 3f) / 3f);
            if (rise <= 0) continue;
            RandomSource r = FxDraw.rng(c.fx().seed, 20 + wave);
            float inner = 1.5f + wave * 2f;
            int spikes = 6 + wave * 5;
            for (int k = 0; k < spikes; k++) {
                float ang = r.nextFloat() * Mth.TWO_PI, dist = inner + r.nextFloat() * 2f;
                double x = centre.x + Mth.cos(ang) * dist, z = centre.z + Mth.sin(ang) * dist;
                double ground = FxDraw.groundY(new Vec3(x, centre.y, z));
                float height = (2.2f + r.nextFloat() * 2.6f) * rise * (1f - sink);
                if (height <= 0.05f) continue;
                float lean = 0.25f + r.nextFloat() * 0.35f;           // leaning outward, curving up
                List<Vec3> spine = new ArrayList<>();
                float[] radii = new float[7];
                float rad = 0.28f + r.nextFloat() * 0.15f;
                for (int i = 0; i < 7; i++) {
                    float t = i / 6f;
                    spine.add(new Vec3(x + Mth.cos(ang) * lean * t * t * height * 0.4f, ground - 0.3 + t * height,
                            z + Mth.sin(ang) * lean * t * t * height * 0.4f));
                    radii[i] = rad * (1f - t * 0.85f) * (i == 2 ? 1.15f : 1f);   // a knuckle part way up
                }
                FxDraw.tube(vc, c.ps(), spine, radii, 7, bone, 0.5f, light, false);
                Vec3 top = spine.get(6), dir = top.subtract(spine.get(5)).normalize();
                FxDraw.cone(vc, c.ps(), top, top.add(dir.scale(0.45f * rise)), radii[6], 7, bone, light);
            }
        }
    }
}
