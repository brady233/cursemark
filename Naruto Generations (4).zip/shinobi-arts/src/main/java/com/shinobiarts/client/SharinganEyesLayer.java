package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.MangekyouDesign;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.entity.LivingEntity;

/**
 * Draws the eyes on the face of a player (or shadow clone): their Sharingan stage while it's on (the Mangekyou in its
 * pattern), the Byakugan while that's on, or 3 tomoe for a Sharingan worn in the dojutsu slot.
 */
public class SharinganEyesLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation[] TOMOE = new ResourceLocation[4];
    private static final ResourceLocation[] MANGEKYOU = new ResourceLocation[MangekyouDesign.values().length];
    private static final ResourceLocation BYAKUGAN = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/byakugan.png");
    private static final ResourceLocation RINNEGAN = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/rinnegan.png");

    static {
        for (int i = 1; i <= 3; i++) TOMOE[i] = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/sharingan_" + i + ".png");
        for (MangekyouDesign d : MangekyouDesign.values()) MANGEKYOU[d.ordinal()] = mangekyouTexture(d);
    }

    private final HumanoidModel<T> eyes;

    public SharinganEyesLayer(RenderLayerParent<T, M> parent, EntityModelSet models) {
        super(parent);
        this.eyes = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHARINGAN_LAYER));
    }

    /** Itachi's pattern keeps the original file name (sharingan_4.png). */
    private static ResourceLocation mangekyouTexture(MangekyouDesign d) {
        String name = d == MangekyouDesign.ITACHI ? "sharingan_4" : "sharingan_4_" + d.id();
        return new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/" + name + ".png");
    }

    public static ResourceLocation texture(int look) {
        int stage = SharinganManager.lookStage(look);
        if (stage == SharinganManager.LOOK_BYAKUGAN) return BYAKUGAN;
        if (stage == SharinganManager.LOOK_RINNEGAN) return RINNEGAN;
        return stage >= 4 ? MANGEKYOU[SharinganManager.lookDesign(look).ordinal()] : TOMOE[Math.max(1, stage)];
    }

    private static final ResourceLocation[] REGULAR = new ResourceLocation[16];

    /** Ordinary eyes in eye colour {@code c} (textures/models/eyes/eye_regular_c.png, made by tools/make_one_eye.py). */
    static ResourceLocation regular(int c) {
        if (REGULAR[c] == null) REGULAR[c] = new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/eye_regular_" + c + ".png");
        return REGULAR[c];
    }

    /** The same eyes with only the right one (made by tools/make_one_eye.py): the curse mark has taken the left. */
    private static final Map<ResourceLocation, ResourceLocation> ONE_EYE = new HashMap<>();

    static ResourceLocation oneEye(ResourceLocation both) {
        return ONE_EYE.computeIfAbsent(both, b -> new ResourceLocation(b.getNamespace(), b.getPath().replace(".png", "_one.png")));
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible()) return;
        int look = ClientEyes.look(entity), look2 = ClientEyes.look2(entity);
        int curse = SharinganManager.lookCurse(look2) != 0 ? SharinganManager.lookCurseStage(look2) : 0;
        ResourceLocation tex;
        if (SharinganManager.lookStage(look) > 0) {
            tex = texture(look);
        } else {
            // no dojutsu: ordinary eyes in the player's own eye colour, drawn the same way so they match the dojutsu.
            // Not while something else has taken over the face (a tailed beast form, the shark form, curse Level 2).
            int colour = SharinganManager.lookEyeColor(look2);
            if (colour <= 0 || curse >= 2 || SharinganManager.lookBeastForm(look) != 0 || (look & SharinganManager.LOOK_SHARK) != 0) return;
            tex = regular(colour);
        }
        // Level 1 curse mark: its black-and-gold eye is the left one (drawn by CurseMarkLayer), these keep the right
        if (curse == 1) tex = oneEye(tex);
        getParentModel().copyPropertiesTo(eyes);
        eyes.setAllVisible(false);
        eyes.head.visible = true;
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(tex));
        eyes.renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
    }
}
