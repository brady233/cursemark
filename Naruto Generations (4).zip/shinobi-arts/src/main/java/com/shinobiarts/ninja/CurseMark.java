package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The curse mark. The Heaven curse mark sits on the left of the neck as a seal of three commas; the Curse Mark key
 * releases it.
 * <ul>
 *   <li>Level 1: black flame markings crawl out from the seal over the whole body. Strength, speed and chakra pour in
 *       (Strength II, Speed 4, Jump Boost II, +2 chakra a second, jutsu +25%).</li>
 *   <li>Level 2 (unlocked by mastering Level 1: {@code curseMarkLevel2Seconds} of use, or given by an operator):
 *       the skin turns grey, the hair grows long and grey, the eyes go dark, and two giant hand-shaped wings burst from
 *       the back and let the user fly. Far stronger (Strength IV, Speed 8, Resistance II, +5 chakra a second, jutsu
 *       +50%).</li>
 * </ul>
 * It strains the body: strain builds while it's out (1 a second at Level 1, 3 at Level 2) and fades while it's sealed.
 * Sealing it again leaves the user exhausted for a while (slow and weak, it can't be released again until it passes).
 * If strain reaches the limit the mark overwhelms them: it seals itself, their chakra is gone and the exhaustion is
 * far worse. All server side; others see it through look2 (bits 0-1 the mark, 2-3 the active level).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CurseMark {
    private CurseMark() {}

    public static final int NONE = 0, HEAVEN = 1;
    public static final int MAX_STRAIN = 90;

    public static String typeName(int type) {
        return type == HEAVEN ? "heaven" : "none";
    }

    /** Jutsu damage while the mark is out. */
    public static float jutsuMultiplier(NinjaData d) {
        return d.curseStage == 2 ? 1.5f : d.curseStage == 1 ? 1.25f : 1f;
    }

    // ---------------------------------------------------------------- giving and taking

    /** Gives the player a curse mark (level 1 or 2 unlocked). */
    public static void give(ServerPlayer p, int type, int level) {
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        boolean had = d.curseType != NONE;
        d.curseType = type;
        d.curseLevel = Math.max(1, Math.min(2, level));
        if (!had) {
            d.curseStage = 0;
            d.curseStrain = 0;
        }
        p.sendSystemMessage(Component.translatable(had ? "message.shinobiarts.curse_level" : "message.shinobiarts.curse_given", d.curseLevel)
                .withStyle(ChatFormatting.DARK_PURPLE));
        if (!had) JutsuUtil.sound(p.serverLevel(), p.position(), SoundEvents.WITHER_AMBIENT, 0.6f, 0.6f);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    public static void remove(ServerPlayer p) {
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        if (d.curseStage > 0) seal(p, d, false, false);
        d.curseType = NONE;
        d.curseLevel = 0;
        d.curseStrain = 0;
        d.curseMastery = 0;
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    // ---------------------------------------------------------------- the key

    /** The Curse Mark key: seal -> Level 1 -> Level 2 (if unlocked) -> seal. Sneak + key: seal it at once. */
    public static void key(ServerPlayer p, NinjaData d, boolean sneaking) {
        if (d.curseType == NONE) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.curse_none").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        long now = p.level().getGameTime();
        if (d.curseStage > 0 && (sneaking || d.curseStage >= d.curseLevel)) {
            seal(p, d, true, false);
            return;
        }
        if (d.curseStage == 0 && now < d.curseExhaustUntil) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.curse_exhausted", (d.curseExhaustUntil - now + 19) / 20)
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        if (d.curseStage == 0 && d.curseStrain >= MAX_STRAIN * 2 / 3) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.curse_strained").withStyle(ChatFormatting.RED), true);
            return;
        }
        release(p, d, d.curseStage + 1);
    }

    private static void release(ServerPlayer p, NinjaData d, int stage) {
        ServerLevel level = p.serverLevel();
        d.curseStage = stage;
        d.curseSince = level.getGameTime();
        if (stage == 2) {
            // the transformation: dark chakra drags inward, then detonates, hurling everything near away
            Fx.on(level, Fx.Visual.CURSE_TRANSFORM, p, null, 1f, 34);
            JutsuUtil.sound(level, p.position(), SoundEvents.WARDEN_SONIC_CHARGE, 1.2f, 0.7f);
            com.shinobiarts.util.Scheduler.later(10, () -> {
                if (!p.isAlive() || d.curseStage != 2) return;
                JutsuUtil.sound(level, p.position(), SoundEvents.ENDER_DRAGON_GROWL, 1.0f, 1.3f);
                JutsuUtil.sound(level, p.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.9f, 0.6f);
                JutsuUtil.sound(level, p.position(), SoundEvents.ENDER_DRAGON_FLAP, 1.5f, 0.5f);
                for (net.minecraft.world.entity.LivingEntity e : JutsuUtil.inRadius(level, p, p.position(), 6.0)) {
                    net.minecraft.world.phys.Vec3 away = e.position().subtract(p.position()).normalize();
                    e.push(away.x * 1.6, 0.6, away.z * 1.6);
                    e.hurtMarked = true;
                }
            });
            p.displayClientMessage(Component.translatable("message.shinobiarts.curse_level2").withStyle(ChatFormatting.DARK_PURPLE), true);
        } else {
            Fx.on(level, Fx.Visual.CURSE_RELEASE, p, null, 1f, 24);
            JutsuUtil.sound(level, p.position(), SoundEvents.WITHER_AMBIENT, 0.8f, 0.7f);
            JutsuUtil.sound(level, p.position(), SoundEvents.WARDEN_HEARTBEAT, 1.5f, 0.8f);
            p.displayClientMessage(Component.translatable("message.shinobiarts.curse_level1").withStyle(ChatFormatting.DARK_PURPLE), true);
        }
        aura(p, d);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    /**
     * Seals the mark again. {@code exhaust}: the body pays for it (longer after Level 2); {@code overwhelmed}: strain
     * hit the limit, so chakra is drained to nothing and the exhaustion is far worse.
     */
    public static void seal(ServerPlayer p, NinjaData d, boolean exhaust, boolean overwhelmed) {
        int was = d.curseStage;
        if (was == 0) return;
        d.curseStage = 0;
        takeFlight(p, d);
        if (exhaust) {
            int secs = overwhelmed ? 45 : was == 2 ? 25 : 10;
            d.curseExhaustUntil = p.level().getGameTime() + secs * 20L;
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, secs * 20, overwhelmed ? 2 : was == 2 ? 1 : 0));
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, secs * 20, overwhelmed ? 1 : 0));
            if (was == 2 || overwhelmed) p.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, secs * 20, 0));
            if (overwhelmed) {
                d.setChakra(0);
                p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0));
                p.sendSystemMessage(Component.translatable("message.shinobiarts.curse_overwhelmed").withStyle(ChatFormatting.DARK_RED));
            } else {
                if (was == 2) d.setChakra(d.getChakra() * 0.7f);
                p.displayClientMessage(Component.translatable("message.shinobiarts.curse_sealed", secs).withStyle(ChatFormatting.GRAY), true);
            }
        }
        JutsuUtil.sound(p.serverLevel(), p.position(), SoundEvents.FIRE_EXTINGUISH, 0.6f, 0.5f);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    // ---------------------------------------------------------------- every tick

    public static void tick(ServerPlayer p, NinjaData d) {
        if (d.curseType == NONE) {
            if (d.curseFlight) takeFlight(p, d);
            return;
        }
        int stage = d.curseStage;
        if (stage == 2 && !p.getAbilities().instabuild && !p.isSpectator() && !p.getAbilities().mayfly) {
            p.getAbilities().mayfly = true;                     // the wings: and they're fast
            p.getAbilities().setFlyingSpeed(0.09f);
            d.curseFlight = true;
            p.onUpdateAbilities();
        } else if (stage < 2 && d.curseFlight) {
            takeFlight(p, d);
        }
        if (p.tickCount % 10 == 0 && stage > 0) aura(p, d);
        // the curse's heartbeat, heavy and slow at Level 1, pounding at Level 2
        if (stage > 0 && p.tickCount % (stage == 2 ? 16 : 28) == 0) {
            JutsuUtil.sound(p.serverLevel(), p.position(), SoundEvents.WARDEN_HEARTBEAT, stage == 2 ? 1.2f : 0.8f, stage == 2 ? 1.1f : 0.85f);
        }
        if (stage == 2 && shielding(p, d)) {                    // hunkered behind the wings: slow
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 2, true, false, false));
        }
        // the wings beat as they fly
        if (stage == 2 && p.getAbilities().flying && !shielding(p, d) && p.tickCount % 14 == 0) {
            JutsuUtil.sound(p.serverLevel(), p.position(), SoundEvents.ENDER_DRAGON_FLAP, 0.5f, 1.3f);
        }
        if (p.tickCount % 20 != 0) return;
        if (stage == 0) {
            if (d.curseStrain > 0 && p.tickCount % 40 == 0) d.curseStrain--;   // the body recovers while it's sealed
            return;
        }
        // the power
        if (stage == 1) {
            buff(p, MobEffects.DAMAGE_BOOST, 1);
            buff(p, MobEffects.MOVEMENT_SPEED, 3);
            buff(p, MobEffects.JUMP, 1);
            d.addChakra(2f);
        } else {
            buff(p, MobEffects.DAMAGE_BOOST, 3);
            buff(p, MobEffects.MOVEMENT_SPEED, 7);
            buff(p, MobEffects.DAMAGE_RESISTANCE, 1);
            buff(p, MobEffects.JUMP, 2);
            d.addChakra(5f);
        }
        // mastering Level 1 opens Level 2
        if (stage == 1 && d.curseLevel < 2) {
            d.curseMastery++;
            if (d.curseMastery >= Config.i(Config.CURSE_LEVEL2_SECONDS)) {
                d.curseLevel = 2;
                p.sendSystemMessage(Component.translatable("message.shinobiarts.curse_level2_unlocked").withStyle(ChatFormatting.DARK_PURPLE));
                JutsuUtil.sound(p.serverLevel(), p.position(), SoundEvents.WITHER_SPAWN, 0.5f, 1.2f);
            }
        }
        // the strain (holding the wing shield wears on the body too)
        int add = stage == 2 ? (shielding(p, d) ? 5 : 3) : 1;
        d.curseStrain += add;
        if (d.curseStrain >= MAX_STRAIN) {
            d.curseStrain = MAX_STRAIN;
            seal(p, d, true, true);
        } else if (d.curseStrain >= MAX_STRAIN - 15 && d.curseStrain - add < MAX_STRAIN - 15) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.curse_warning").withStyle(ChatFormatting.RED), true);
        }
        ModNetwork.sync(p);
    }

    private static void aura(ServerPlayer p, NinjaData d) {
        int rgb = d.curseStage == 2 ? 0x3A1450 : 0x5A2A7A;
        Fx.on(p.serverLevel(), Fx.Visual.CHAKRA_AURA, p, null, rgb, 10);
    }

    private static void buff(ServerPlayer p, MobEffect effect, int amp) {
        p.addEffect(new MobEffectInstance(effect, 40, amp, true, false, true));
    }

    /** Takes back the wings' flight, if it was the curse mark that gave it. */
    private static void takeFlight(ServerPlayer p, NinjaData d) {
        if (!d.curseFlight) return;
        d.curseFlight = false;
        if (!p.getAbilities().instabuild && !p.isSpectator()) {
            p.getAbilities().mayfly = false;
            p.getAbilities().flying = false;
        }
        p.getAbilities().setFlyingSpeed(0.05f);                // the normal speed
        p.onUpdateAbilities();
    }

    // ---------------------------------------------------------------- events

    /** Death seals it (no exhaustion: they respawn clean). */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            NinjaData d = NinjaData.get(p);
            if (d != null && d.curseStage > 0) seal(p, d, false, false);
        }
    }

    /** Logging out seals it; logging in clears any flight left over from a crash. */
    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            NinjaData d = NinjaData.get(p);
            if (d != null && d.curseStage > 0) seal(p, d, false, false);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            NinjaData d = NinjaData.get(p);
            if (d == null) return;
            if (d.curseStage > 0) d.curseStage = 0;
            takeFlight(p, d);
        }
    }

    /**
     * Hits with the mark out carry cursed chakra: a burst of violet sparks on impact, and at Level 2 they hurl the
     * target back.
     */
    @SubscribeEvent
    public static void onHit(net.minecraftforge.event.entity.living.LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer p) || event.getSource().getDirectEntity() != p) return;
        NinjaData d = NinjaData.get(p);
        if (d == null || d.curseStage == 0) return;
        net.minecraft.world.entity.LivingEntity target = event.getEntity();
        net.minecraft.world.phys.Vec3 at = target.getBoundingBox().getCenter();
        p.serverLevel().sendParticles(new net.minecraft.core.particles.DustParticleOptions(new org.joml.Vector3f(0.55f, 0.2f, 1f), 1.4f),
                at.x, at.y, at.z, d.curseStage == 2 ? 24 : 12, 0.35, 0.4, 0.35, 0.0);
        p.serverLevel().sendParticles(net.minecraft.core.particles.ParticleTypes.SQUID_INK, at.x, at.y, at.z, d.curseStage == 2 ? 8 : 4, 0.2, 0.3, 0.2, 0.05);
        if (d.curseStage == 2) {
            net.minecraft.world.phys.Vec3 away = target.position().subtract(p.position()).normalize();
            target.push(away.x * 0.9, 0.3, away.z * 0.9);
            target.hurtMarked = true;
            JutsuUtil.sound(p.serverLevel(), at, SoundEvents.PLAYER_ATTACK_CRIT, 1f, 0.6f);
        }
    }

    // ---------------------------------------------------------------- the wing shield

    /**
     * Level 2: right-click with an empty hand and the hand-wings swing round in front, palms out, over the chest and
     * face. The client sends this every few ticks while right-click is held, so the shield lasts while it's held. It
     * stops 85% of the damage of hits (and all of arrows and other projectiles), but slows the user and strains the
     * body faster.
     */
    public static void shield(ServerPlayer p, NinjaData d) {
        if (d.curseStage != 2) return;
        long now = p.level().getGameTime();
        boolean starting = d.curseShieldUntil < now;
        d.curseShieldUntil = now + 7;
        if (starting) {
            JutsuUtil.sound(p.serverLevel(), p.position(), SoundEvents.ENDER_DRAGON_FLAP, 0.9f, 0.7f);
            JutsuUtil.sound(p.serverLevel(), p.position(), SoundEvents.ARMOR_EQUIP_NETHERITE, 1f, 0.6f);
            SharinganManager.updateLook(p);
        }
    }

    public static boolean shielding(ServerPlayer p, NinjaData d) {
        return d.curseStage == 2 && d.curseShieldUntil > p.level().getGameTime();
    }

    /** Arrows and other projectiles glance off the wings. */
    @SubscribeEvent
    public static void onShieldAttack(net.minecraftforge.event.entity.living.LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        NinjaData d = NinjaData.get(p);
        if (d == null || !shielding(p, d)) return;
        if (event.getSource().getDirectEntity() instanceof net.minecraft.world.entity.projectile.Projectile) {
            event.setCanceled(true);
            blocked(p, event.getSource().getDirectEntity().position());
        }
    }

    /** Blows the wings take: 85% stopped, and whoever struck is shoved back. */
    @SubscribeEvent
    public static void onShieldHurt(net.minecraftforge.event.entity.living.LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        NinjaData d = NinjaData.get(p);
        if (d == null || !shielding(p, d) || event.getSource().is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
        net.minecraft.world.entity.Entity by = event.getSource().getEntity();
        if (by == null && !event.getSource().is(net.minecraft.tags.DamageTypeTags.IS_EXPLOSION)) return;   // not fire, poison, falling...
        event.setAmount(event.getAmount() * 0.15f);
        blocked(p, by != null ? by.position() : p.position().add(p.getLookAngle()));
        if (by instanceof net.minecraft.world.entity.LivingEntity l && by.distanceTo(p) < 5) {
            net.minecraft.world.phys.Vec3 away = l.position().subtract(p.position()).normalize();
            l.push(away.x * 0.6, 0.15, away.z * 0.6);
            l.hurtMarked = true;
        }
    }

    private static void blocked(ServerPlayer p, net.minecraft.world.phys.Vec3 from) {
        net.minecraft.world.phys.Vec3 at = p.getEyePosition().add(from.subtract(p.position()).normalize().scale(0.8)).add(0, -0.3, 0);
        p.serverLevel().sendParticles(new net.minecraft.core.particles.DustParticleOptions(new org.joml.Vector3f(0.55f, 0.2f, 1f), 1.3f),
                at.x, at.y, at.z, 14, 0.3, 0.3, 0.3, 0.0);
        p.serverLevel().sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT, at.x, at.y, at.z, 8, 0.2, 0.2, 0.2, 0.2);
        JutsuUtil.sound(p.serverLevel(), at, SoundEvents.SHIELD_BLOCK, 1f, 0.55f);
    }

    /** No fall damage while the wings are out. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            NinjaData d = NinjaData.get(p);
            if (d != null && d.curseStage == 2) event.setCanceled(true);
        }
    }
}
