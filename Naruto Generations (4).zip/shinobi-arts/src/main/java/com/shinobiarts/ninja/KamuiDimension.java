package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.Set;

/**
 * Obito's Kamui dimension: an endless dark void with no sky and no daylight, its silence broken only by huge square
 * blocks of light blue terracotta rising out of the dark at every height (shinobiarts:kamui, see data/shinobiarts/dimension). The Kamui
 * Mangekyou reaches it two ways:
 * <ul>
 *   <li><b>Kamui warp</b> (Jutsu 1): the user is sucked into a vortex from their eye and appears on a block in the
 *       Kamui dimension; again to go back to exactly where they left.</li>
 *   <li><b>Kamui abduction</b> (Sneak + Jutsu 1): whatever the user looks at twists into the vortex and is gone,
 *       into the Kamui dimension. Creatures stay there; a player is trapped for a while (30 seconds by default) and
 *       then thrown back where they were taken from. Bosses can't be taken.</li>
 * </ul>
 * The blocks are laid out on a grid as places in it are first visited, so it goes on as far as anyone explores.
 */
public final class KamuiDimension {
    private KamuiDimension() {}

    public static final ResourceKey<Level> KAMUI = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(ShinobiArts.MODID, "kamui"));

    /** The grid the blocks stand on (one block at most per cell). */
    public static final int CELL = 20;

    // ---------------------------------------------------------------- per player: where to send them back

    public static final class State {
        public String returnDim = "";
        public double rx, ry, rz;
        public float ryaw;
        /** Trapped by someone else's Kamui: when they're thrown back out (game time); 0 if not trapped. */
        public long releaseAt;

        public CompoundTag save() {
            CompoundTag t = new CompoundTag();
            if (!returnDim.isEmpty()) {
                t.putString("Dim", returnDim);
                t.putDouble("X", rx);
                t.putDouble("Y", ry);
                t.putDouble("Z", rz);
                t.putFloat("Yaw", ryaw);
            }
            if (releaseAt > 0) t.putLong("Release", releaseAt);
            return t;
        }

        public void load(CompoundTag t) {
            returnDim = t.getString("Dim");
            rx = t.getDouble("X");
            ry = t.getDouble("Y");
            rz = t.getDouble("Z");
            ryaw = t.getFloat("Yaw");
            releaseAt = t.getLong("Release");
        }

        void remember(ServerPlayer p) {
            returnDim = p.level().dimension().location().toString();
            rx = p.getX();
            ry = p.getY();
            rz = p.getZ();
            ryaw = p.getYRot();
        }

        public void clear() {
            returnDim = "";
            releaseAt = 0;
        }
    }

    public static boolean inKamui(Entity e) {
        return e.level().dimension() == KAMUI;
    }

    @Nullable
    private static ServerLevel level(MinecraftServer server) {
        return server.getLevel(KAMUI);
    }

    // ---------------------------------------------------------------- the techniques

    /** Kamui warp: into the Kamui dimension, or back out to where you came from. */
    /** The Kamui swirl's size: small and tight round whoever's being taken. */
    private static final float SWIRL = 0.65f;

    /**
     * Kamui warp, one technique for both: look down (or be in Kamui already) to take yourself in and out; aim at
     * someone to take them instead.
     */
    public static boolean warp(ServerPlayer p, NinjaData d) {
        ServerLevel kamui = level(p.server);
        if (kamui == null) return false;
        boolean lookingDown = p.getXRot() > 50f;
        // inside Kamui, aiming at someone who's in here too: twist them back out to the world
        if (inKamui(p) && !lookingDown) {
            LivingEntity inside = JutsuUtil.rayTarget(p, 24);
            if (inside != null && inKamui(inside)) return release(p, inside);
        }
        boolean self = inKamui(p) || lookingDown;
        if (!self) {
            if (JutsuUtil.rayTarget(p, 24) == null) {
                p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_aim").withStyle(ChatFormatting.GRAY), true);
                return false;
            }
            return abduct(p, d);
        }
        if (inKamui(p)) {
            Fx.on(p.serverLevel(), Fx.Visual.KAMUI_SWIRL, p, null, SWIRL, 14);
            JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.5f);
            Scheduler.later(12, () -> {
                if (p.isAlive() && inKamui(p)) sendBack(p, d);
            });
            return true;
        }
        d.kamui.remember(p);
        d.kamui.releaseAt = 0;
        Fx.on(p.serverLevel(), Fx.Visual.KAMUI_SWIRL, p, null, SWIRL, 14);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.5f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.WARDEN_SONIC_CHARGE, 0.6f, 1.8f);
        Scheduler.later(12, () -> {
            if (!p.isAlive() || inKamui(p)) return;
            Vec3 at = arrival(kamui, p.getUUID().getLeastSignificantBits(), 3);
            enter(p, kamui, at);
            p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_in").withStyle(ChatFormatting.DARK_PURPLE), true);
        });
        ModNetwork.sync(p);
        return true;
    }

    /** Kamui warp on someone already inside Kamui: they're twisted out again, back where they came from. */
    private static boolean release(ServerPlayer p, LivingEntity target) {
        ServerLevel kamui = p.serverLevel();
        Fx.on(kamui, Fx.Visual.KAMUI_SWIRL, target, null, SWIRL * Math.max(1f, target.getBbHeight() / 1.8f), 20);
        JutsuUtil.sound(kamui, target.position(), SoundEvents.ENDERMAN_TELEPORT, 1.0f, 0.5f);
        Scheduler.later(18, () -> {
            if (!target.isAlive() || !inKamui(target)) return;
            if (target instanceof ServerPlayer victim) {
                NinjaData vd = NinjaData.get(victim);
                if (vd != null) sendBack(victim, vd);
            } else {
                // a creature has no way home of its own: it comes out where the caster entered Kamui (or at spawn)
                NinjaData d = NinjaData.get(p);
                ServerLevel to = null;
                Vec3 at = null;
                if (d != null && !d.kamui.returnDim.isEmpty()) {
                    to = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(d.kamui.returnDim)));
                    at = new Vec3(d.kamui.rx, d.kamui.ry, d.kamui.rz);
                }
                if (to == null || to == kamui) {
                    to = p.server.overworld();
                    at = Vec3.atBottomCenterOf(to.getSharedSpawnPos());
                }
                target.teleportTo(to, at.x, at.y, at.z, Set.of(), target.getYRot(), target.getXRot());
                target.setDeltaMovement(Vec3.ZERO);
                target.resetFallDistance();
                Fx.at(to, Fx.Visual.KAMUI_ARRIVE, at.add(0, 1, 0), SWIRL, 14);
            }
            p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_sent_out", target.getDisplayName())
                    .withStyle(ChatFormatting.DARK_PURPLE), true);
        });
        return true;
    }

    /** Kamui warp on someone else: the creature you aim at (24 blocks) is twisted away into the Kamui dimension. */
    private static boolean abduct(ServerPlayer p, NinjaData d) {
        ServerLevel kamui = level(p.server);
        if (kamui == null) return false;
        LivingEntity target = JutsuUtil.rayTarget(p, 24);
        if (target == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        if (target instanceof WitherBoss || target instanceof EnderDragon || target.getType().is(net.minecraft.tags.TagKey.create(
                Registries.ENTITY_TYPE, new ResourceLocation("forge", "bosses")))
                || (target instanceof ServerPlayer sp && (sp.isCreative() || sp.isSpectator()))) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_too_strong", target.getDisplayName()).withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        if (inKamui(target)) return release(p, target);
        ServerLevel here = p.serverLevel();
        Fx.on(here, Fx.Visual.KAMUI_SWIRL, target, null, SWIRL * Math.max(1f, target.getBbHeight() / 1.8f), 20);
        JutsuUtil.sound(here, target.position(), SoundEvents.WARDEN_SONIC_CHARGE, 1.0f, 1.6f);
        JutsuUtil.sound(here, target.position(), SoundEvents.ENDERMAN_TELEPORT, 1.0f, 0.4f);
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 22, 10, false, false));
        Scheduler.repeat(0, 1, 18, i -> {
            if (target.isAlive()) target.setDeltaMovement(0, 0, 0);
        });
        Scheduler.later(18, () -> {
            if (!target.isAlive() || target.level() != here) return;
            long seed = target.getUUID().getMostSignificantBits() ^ here.getGameTime();
            Vec3 at = arrival(kamui, seed, 2);
            target.stopRiding();
            target.ejectPassengers();
            if (target instanceof ServerPlayer victim) {
                if (victim.hasDisconnected()) return;
                NinjaData vd = NinjaData.get(victim);
                if (vd != null) {
                    if (!inKamui(victim)) vd.kamui.remember(victim);
                    vd.kamui.releaseAt = here.getGameTime() + Config.i(Config.KAMUI_TRAP_SECONDS) * 20L;
                    ModNetwork.sync(victim);
                }
                victim.sendSystemMessage(Component.translatable("message.shinobiarts.kamui_trapped", p.getDisplayName(),
                        Config.i(Config.KAMUI_TRAP_SECONDS)).withStyle(ChatFormatting.DARK_PURPLE));
                enter(victim, kamui, at);
            } else {
                target.teleportTo(kamui, at.x, at.y, at.z, Set.of(), target.getYRot(), target.getXRot());
                Fx.at(kamui, Fx.Visual.KAMUI_ARRIVE, at.add(0, 1, 0), SWIRL, 14);
            }
            p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_taken", target.getDisplayName())
                    .withStyle(ChatFormatting.DARK_PURPLE), true);
        });
        return true;
    }

    private static void enter(ServerPlayer p, ServerLevel kamui, Vec3 at) {
        p.stopRiding();
        p.teleportTo(kamui, at.x, at.y, at.z, p.getYRot(), 0f);
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();
        Fx.on(kamui, Fx.Visual.KAMUI_ARRIVE, p, null, SWIRL, 14);
        JutsuUtil.sound(kamui, at, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.6f);
    }

    /** Back to where they were before they went in (their spawn if that's gone). */
    public static void sendBack(ServerPlayer p, NinjaData d) {
        ServerLevel to = null;
        if (!d.kamui.returnDim.isEmpty()) {
            to = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(d.kamui.returnDim)));
        }
        Vec3 at;
        float yaw = p.getYRot();
        if (to == null || to == level(p.server)) {
            to = p.server.getLevel(p.getRespawnDimension());
            if (to == null) to = p.server.overworld();
            BlockPos spawn = p.getRespawnPosition() != null && to.dimension() == p.getRespawnDimension() ? p.getRespawnPosition() : to.getSharedSpawnPos();
            at = Vec3.atBottomCenterOf(spawn);
        } else {
            at = new Vec3(d.kamui.rx, d.kamui.ry, d.kamui.rz);
            yaw = d.kamui.ryaw;
        }
        d.kamui.clear();
        p.stopRiding();
        p.teleportTo(to, at.x, at.y, at.z, yaw, p.getXRot());
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();
        Fx.on(to, Fx.Visual.KAMUI_ARRIVE, p, null, 1f, 14);
        JutsuUtil.sound(to, at, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.6f);
        ModNetwork.sync(p);
    }

    /** Every second: a trapped player whose time is up is thrown back out. */
    public static void tick(ServerPlayer p, NinjaData d) {
        if (!inKamui(p)) {
            if (d.kamui.releaseAt > 0) {                         // got out some other way
                d.kamui.clear();
                ModNetwork.sync(p);
            }
            return;
        }
        ServerLevel kamui = p.serverLevel();
        if (p.getY() < -20 && !p.isCreative() && !p.isSpectator()) {    // fell into the void: caught on the nearest block
            int cx = Math.floorDiv(p.getBlockX(), CELL), cz = Math.floorDiv(p.getBlockZ(), CELL);
            int[] best = null;
            for (int r = 0; r <= 3 && best == null; r++) {
                for (int dx = -r; dx <= r && best == null; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        int[] q = pillar(cx + dx, cz + dz);
                        if (q != null) {
                            best = q;
                            break;
                        }
                    }
                }
            }
            if (best == null) best = pillar(0, 0);
            p.teleportTo(best[0] + best[2] / 2.0, best[3] + 1, best[1] + best[2] / 2.0);
            p.setDeltaMovement(Vec3.ZERO);
            p.resetFallDistance();
            Fx.on(kamui, Fx.Visual.KAMUI_ARRIVE, p, null, SWIRL, 14);
        }
        if (d.kamui.releaseAt > 0 && kamui.getGameTime() >= d.kamui.releaseAt) {
            p.sendSystemMessage(Component.translatable("message.shinobiarts.kamui_released").withStyle(ChatFormatting.GRAY));
            sendBack(p, d);
        }
    }

    // ---------------------------------------------------------------- the blocks

    /** A spot on top of a block near the middle of the dimension (its chunks generate with their pillars as they load). */
    private static Vec3 arrival(ServerLevel kamui, long seed, int spread) {
        java.util.Random r = new java.util.Random(seed);
        for (int tries = 0; tries < 40; tries++) {
            int cx = r.nextInt(spread * 2 + 1) - spread, cz = r.nextInt(spread * 2 + 1) - spread;
            int[] pillar = pillar(cx, cz);
            if (pillar == null) continue;
            return new Vec3(pillar[0] + pillar[2] / 2.0, pillar[3] + 1, pillar[1] + pillar[2] / 2.0);
        }
        int[] p = pillar(0, 0);
        return new Vec3(p[0] + p[2] / 2.0, p[3] + 1, p[1] + p[2] / 2.0);
    }

    /** The block standing in cell (cx, cz): {x, z, size, top y}, or null for an empty cell. The middle is never empty. */
    @Nullable
    public static int[] pillar(int cx, int cz) {
        long h = cx * 341873128712L + cz * 132897987541L;
        h ^= (h >>> 33);
        h *= 0xff51afd7ed558ccdL;
        h ^= (h >>> 33);
        int roll = (int) Math.floorMod(h, 100);
        boolean middle = Math.abs(cx) <= 1 && Math.abs(cz) <= 1;
        if (!middle && roll >= 72) return null;
        int size = 9 + (int) Math.floorMod(h >>> 8, 7);                 // 9 to 15 wide
        int ox = (int) Math.floorMod(h >>> 16, CELL - size), oz = (int) Math.floorMod(h >>> 24, CELL - size);
        int top = 10 + (int) Math.floorMod(h >>> 32, 30);               // 10 to 39 high
        return new int[]{cx * CELL + ox, cz * CELL + oz, size, top};
    }

    /** What the Kamui dimension is built of: the floor (see data/shinobiarts/dimension/kamui.json) and every pillar. */
    public static BlockState block() {
        return Blocks.LIGHT_BLUE_TERRACOTTA.defaultBlockState();
    }
}
